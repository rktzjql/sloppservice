package expo.modules.aiusage
import org.junit.Assert.*
import org.junit.Test
class ScreenDiagnosticTest {
  @Test fun delayDurationAndEventsHaveStrictBoundaries() {
    val d=ScreenDiagnostic();d.begin(1000)
    d.event(2000,true);assertEquals(0,d.snapshot(2000)["clickEvents"])
    assertFalse(d.tick(5999));assertTrue(d.tick(6000))
    d.event(6100,true);d.event(6200,false)
    assertEquals(1,d.snapshot(6300)["clickEvents"])
    assertEquals(1,d.snapshot(6300)["changeEvents"])
    assertFalse(d.tick(36000));assertFalse(d.pending())
    d.event(36001,true);assertEquals(1,d.snapshot(36001)["clickEvents"])
    assertEquals("complete",d.snapshot(36001)["state"])
  }
  @Test fun resultIsBoundedAndContainsOnlyAllowlistedMetadata() {
    val d=ScreenDiagnostic();d.begin(0);d.tick(5000)
    repeat(50){d.sample("ChatGPT",100,true,true,true,true,true,false,"none")}
    val snapshot=d.snapshot(6000)
    assertEquals(30,snapshot["editableSamples"]);assertEquals(30,snapshot["nonemptySamples"])
    assertEquals(30,snapshot["sendSamples"]);assertEquals(0,snapshot["stopSamples"])
    val samples=snapshot["samples"] as List<*>
    assertEquals(30,samples.size)
    assertEquals(setOf("provider","nodes","bounded","editable","readable","nonempty","send","stop","issue"),(samples[0] as Map<*,*>).keys)
    assertFalse(snapshot.containsKey("sendCount"));assertFalse(snapshot.containsKey("prompt"))
  }
  @Test fun cancellationStopsCollectionAndRestartClearsPreviousResults() {
    val d=ScreenDiagnostic();d.begin(0);d.tick(5000)
    d.sample("ChatGPT",10,false,true,false,false,false,false,"input_consent_off")
    val before=d.snapshot(5500)["samples"]
    d.cancel();d.event(6000,true);d.sample("Gemini",5,false,false,false,false,true,true,"none")
    assertEquals(before,d.snapshot(6000)["samples"]);assertEquals("cancelled",d.snapshot(6000)["state"])
    d.begin(7000);assertEquals(emptyList<Any>(),d.snapshot(7000)["samples"])
    assertEquals(0,d.snapshot(7000)["clickEvents"]);d.clear();assertEquals("idle",d.snapshot(7000)["state"])
  }
  @Test fun missingOrBackgroundScreenIsRecordedWithoutInventingSignals() {
    val d=ScreenDiagnostic();d.begin(0);d.tick(5000)
    d.sample("none",0,false,false,false,false,false,false,"root_missing")
    d.sample("none",0,false,false,false,false,false,false,"background")
    val s=d.snapshot(6000);assertEquals(0,s["readableSamples"]);assertEquals(0,s["sendSamples"])
    assertEquals(2,(s["samples"] as List<*>).size)
  }
}
