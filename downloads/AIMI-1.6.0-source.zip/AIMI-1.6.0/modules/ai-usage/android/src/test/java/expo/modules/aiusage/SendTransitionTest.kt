package expo.modules.aiusage

import org.junit.Assert.*
import org.junit.Test

class SendTransitionTest {
  @Test fun stateChangeCountsWithoutAnyClickButStreamingDoesNotRepeat() {
    val s=SendTransition()
    assertFalse(s.observe("ChatGPT:1",true,false,1000))
    assertTrue(s.observe("ChatGPT:1",false,true,1500))
    assertFalse(s.observe("ChatGPT:1",false,true,3000))
    assertFalse(s.observe("ChatGPT:1",false,true,9000))
    assertFalse(s.observe("ChatGPT:1",false,false,10000))
    assertFalse(s.observe("ChatGPT:1",false,true,11000)) // Regenerate without a Send baseline.
  }
  @Test fun openingOrScrollingAnExistingStreamNeverCreatesAReceipt() {
    val s=SendTransition()
    assertFalse(s.observe("ChatGPT:1",false,true,1000))
    assertFalse(s.observe("ChatGPT:1",false,true,2000))
    assertFalse(s.observe("ChatGPT:1",false,false,3000))
    assertFalse(s.observe("ChatGPT:1",false,true,4000))
  }
  @Test fun directClickAndLaterStateChangeCountOnlyTheDirectClick() {
    val s=SendTransition()
    s.observe("ChatGPT:1",true,false,1000)
    assertTrue(s.direct("ChatGPT:1",1200))
    s.observe("ChatGPT:1",true,false,20000) // Slow network must not expire suppression.
    assertFalse(s.observe("ChatGPT:1",false,true,21000))
    s.observe("ChatGPT:1",true,false,22000)
    assertTrue(s.observe("ChatGPT:1",false,true,23000)) // A new cycle can count.
  }
  @Test fun delayedClickAfterStateReceiptIsSuppressed() {
    val s=SendTransition()
    s.observe("ChatGPT:1",true,false,1000)
    assertTrue(s.observe("ChatGPT:1",false,true,2000))
    assertFalse(s.direct("ChatGPT:1",1500))
    assertFalse(s.direct("ChatGPT:1",2500))
    s.observe("ChatGPT:1",true,false,3000)
    assertTrue(s.direct("ChatGPT:1",3500))
  }
  @Test fun staleOtherWindowAndMissingSnapshotsDoNotCreateReceipts() {
    val s=SendTransition()
    s.observe("ChatGPT:1",true,false,1000)
    assertFalse(s.observe("ChatGPT:1",false,true,5000))
    s.observe("ChatGPT:1",true,false,6000)
    assertFalse(s.observe("ChatGPT:2",false,true,6500))
    s.observe("ChatGPT:2",true,false,7000)
    assertFalse(s.observe("Gemini:2",false,true,7500))
    s.observe("Gemini:2",true,false,8000)
    s.clear()
    assertFalse(s.observe("Gemini:2",false,true,8500))
  }
  @Test fun duplicateOrOlderSnapshotsCannotCreateASecondReceipt() {
    val s=SendTransition()
    s.observe("ChatGPT:1",true,false,1000)
    assertFalse(s.observe("ChatGPT:1",false,true,1000))
    assertFalse(s.observe("ChatGPT:1",false,true,900))
    assertTrue(s.observe("ChatGPT:1",false,true,1200))
  }
  @Test fun shortIntermediateNeutralFrameCanBridgeSendToStop() {
    val s=SendTransition()
    s.observe("Gemini:2",true,false,1000)
    assertFalse(s.observe("Gemini:2",false,false,1500))
    assertTrue(s.observe("Gemini:2",false,true,2000))
  }
  @Test fun onlyExplicitGenerationStopControlsMatch() {
    for (label in listOf("Stop generating","응답 생성 중지","생성 중지")) assertTrue(ExperimentRules.isStop(label))
    for (label in listOf("Stop", "Pause", "Stop recording", "음성 입력 중지", "다시 생성", "Copy", "stop generating is a phrase")) assertFalse(ExperimentRules.isStop(label))
  }
  @Test fun stateReceiptDoesNotPretendToBeAClickAndPauseIsRespected() {
    val c=ExperimentCounter()
    assertFalse(c.transition(1000,10000,"ChatGPT"))
    c.resume()
    assertTrue(c.transition(1000,10000,"ChatGPT"))
    assertEquals(0,c.seenClicks)
    assertEquals(1,c.sends)
    assertFalse(c.click(true,2000,11000,"ChatGPT",false))
    assertEquals(1,c.seenClicks)
    assertEquals(1,c.sends)
    c.stop()
    assertFalse(c.transition(3000,12000,"ChatGPT"))
  }
}
