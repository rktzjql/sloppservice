package expo.modules.aiusage

import org.junit.Assert.*
import org.junit.Test

class ExperimentRulesTest {
  @Test fun composeControlsDoNotNeedNativeButtonClass() {
    assertTrue(ExperimentRules.isControl("android.view.View",true,false))
    assertTrue(ExperimentRules.isControl("android.view.View",false,true))
    assertTrue(ExperimentRules.isControl("android.widget.ImageButton",false,false))
    assertFalse(ExperimentRules.isControl("android.widget.TextView",false,false))
    assertFalse(ExperimentRules.isSend("이 메시지를 전송해 주세요"))
    assertFalse(ExperimentRules.isStop("답변에 생성 중지라는 문구가 있어요"))
  }

  @Test fun requiresExplicitStart() {
    val c=ExperimentCounter();c.click(true,1000,10000);assertEquals(0,c.sends);assertEquals(0,c.seenClicks)
    c.start();c.click(true,1000,10000);assertEquals(1,c.sends)
  }
  @Test fun repeatedAndOutOfOrderEventsDoNotCountTwice() {
    val c=ExperimentCounter();c.start();c.click(true,1000,10000);c.click(true,1000,10000);c.click(true,900,10000);c.click(true,1100,10000);assertEquals(1,c.sends)
    c.click(true,3000,12000);assertEquals(2,c.sends)
  }
  @Test fun stoppedCounterIgnoresEventsAndClearRemovesStats() {
    val c=ExperimentCounter();c.start();c.click(true,1000,10000);c.stop();c.click(true,2000,11000);assertEquals(1,c.sends)
    c.clear();assertFalse(c.active);assertEquals(0,c.sends);assertEquals(0L,c.checkedAt)
  }
  @Test fun otherAndUnavailableControlsAreDiagnosticsOnly() {
    val c=ExperimentCounter();c.start();c.click(false,1000,10000);c.click(null,2000,11000)
    assertEquals(0,c.sends);assertEquals(2,c.seenClicks);assertEquals("unavailable",c.snapshot()["lastMatch"])
  }
  @Test fun sendLabelsAndIdsAreExact() {
    assertTrue(ExperimentRules.isSend(" Send prompt "));assertTrue(ExperimentRules.isSend("메시지 전송"))
    assertTrue(ExperimentRules.isSend("","com.openai.chatgpt:id/send_button"))
    for(label in listOf("Resend", "Stop generating", "Regenerate", "다시 생성", "Send feedback", "Copy", "Send a message to my friend"))assertFalse(ExperimentRules.isSend(label))
  }
  @Test fun providersStaySeparate() {
    val c=ExperimentCounter();c.start();c.click(true,1000,10000,"ChatGPT");c.click(true,1100,10100,"Gemini");c.click(true,1200,10200,"Other")
    assertEquals(2,c.sends);assertEquals(1,c.snapshot()["chatgptCount"]);assertEquals(1,c.snapshot()["geminiCount"])
    assertEquals("Gemini",ExperimentRules.providerFor("com.google.android.apps.bard"));assertNull(ExperimentRules.providerFor("com.google.android.googlequicksearchbox"))
  }
  @Test fun reconnectResumesWithoutResetAndAcceptedClickIsReported() {
    val c=ExperimentCounter();c.resume();assertTrue(c.click(true,1000,10000));c.stop();assertFalse(c.click(true,2000,11000));c.resume();assertTrue(c.click(true,3000,12000));assertEquals(2,c.sends)
  }
  @Test fun snapshotContainsNoAnswerOrMessageFields() {
    assertEquals(setOf("active","sendCount","chatgptCount","geminiCount","seenClicks","lastMatch","checkedAt"),ExperimentCounter().snapshot().keys)
  }
}
