package expo.modules.aiusage
import org.junit.Assert.*
import org.junit.Test
class ComposerLeaseTest {
 @Test fun rememberedSlotSurvivesFocusLossButExpiresAndCannotCrossWindows() {
  val lease=ComposerLease();lease.remember("ChatGPT:1",1000)
  assertTrue(lease.valid("ChatGPT:1",2000));assertFalse(lease.valid("ChatGPT:2",2000))
  assertFalse(lease.valid("Gemini:1",2000));assertFalse(lease.valid("ChatGPT:1",5000))
  assertFalse(lease.valid("ChatGPT:1",999));lease.clear();assertFalse(lease.valid("ChatGPT:1",2000))
 }
 @Test fun refreshExtendsOnlyTheValidatedWindow() {
  val lease=ComposerLease();lease.remember("ChatGPT:1",1000);lease.remember("ChatGPT:1",4000)
  assertTrue(lease.valid("ChatGPT:1",6000))
 }
 @Test fun smallSlotWorksDespiteUnrelatedLargeHistory() {
  data class N(val send:Boolean=false,val stop:Boolean=false,val children:List<N> = emptyList())
  val lease=ComposerLease();val transition=SendTransition()
  val scanner=ControlScanner<N>({ControlFacts(true,it.children.size,it.send,it.stop)},{n,i->n.children[i]},{},{0L})
  val initial=scanner.scan(N(children=listOf(N(send=true))),100,maxNodes=120)
  lease.remember("ChatGPT:1",1000)
  assertFalse(transition.observe("ChatGPT:1",initial.ready,initial.stopped,1000))
  // Focus disappears and the same short-lived button slot now contains Stop.
  assertTrue(lease.valid("ChatGPT:1",1500))
  val next=scanner.scan(N(children=listOf(N(stop=true))),100,maxNodes=120)
  assertTrue(transition.observe("ChatGPT:1",next.ready,next.stopped,1500))
  assertFalse(transition.observe("ChatGPT:1",next.ready,next.stopped,1800))
 }
}
