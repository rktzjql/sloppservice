package expo.modules.aiusage
import org.junit.Assert.*
import org.junit.Test
class PromptPreviewTest {
  @Test fun countsCodePointsIncludingWhitespaceAndDoesNotTreatTypingAsSend() {
    val p=PromptPreview();p.observe("ChatGPT:1","안녕 😀\n",100)
    val s=p.snapshot(100);assertEquals(5,s["characters"]);assertEquals("안녕 😀\n",s["text"])
    assertEquals("none",s["signal"]);assertEquals(false,s["truncated"])
  }
  @Test fun clearingKeepsLatestDraftWithoutInventingSendAndNewDraftResetsSignal() {
    val p=PromptPreview();p.observe("ChatGPT:1","질문",100);p.observe("ChatGPT:1","",200)
    assertEquals("질문",p.snapshot(201)["text"]);assertEquals("empty",p.snapshot(201)["inputState"])
    assertEquals("none",p.snapshot(201)["signal"])
    p.mark("ChatGPT:1","click",300);assertEquals("click",p.snapshot(300)["signal"])
    p.observe("ChatGPT:1","질문",400);assertEquals("none",p.snapshot(400)["signal"])
  }
  @Test fun signalAssociationRequiresSameWindowFreshDataAndAllowlistedEvidence() {
    val p=PromptPreview();p.observe("ChatGPT:1","질문",100)
    p.mark("ChatGPT:2","click",200);p.mark("ChatGPT:1","server-success",200)
    assertEquals("none",p.snapshot(200)["signal"])
    p.mark("ChatGPT:1","click",16000);assertEquals("none",p.snapshot(16000)["signal"])
    p.observe("ChatGPT:1","질문",17000);p.mark("ChatGPT:1","input-transition",18000)
    assertEquals("input-transition",p.snapshot(18000)["signal"])
  }
  @Test fun previewExpiresAndDeletionLeavesNoTextOrCounts() {
    val p=PromptPreview();p.observe("ChatGPT:1","private fixture",100)
    assertEquals("private fixture",p.snapshot(600099)["text"])
    assertEquals("",p.snapshot(600100)["text"]);assertEquals(0,p.snapshot(600100)["characters"])
    p.observe("ChatGPT:1","another fixture",700000);p.clear()
    assertEquals("",p.snapshot(700001)["text"]);assertEquals("none",p.snapshot(700001)["signal"])
  }
  @Test fun longTextIsExplicitlyTruncatedWithoutBrokenEmojiAndCountingIsBounded() {
    val p=PromptPreview();p.observe("ChatGPT:1","a".repeat(3999)+"😀tail",100)
    val s=p.snapshot(100);assertEquals("a".repeat(3999),s["text"])
    assertEquals(4004,s["characters"]);assertEquals(true,s["truncated"]);assertEquals(false,s["countLimited"])
    p.observe("ChatGPT:1","a".repeat(100001),200)
    assertEquals(100000,p.snapshot(200)["characters"]);assertEquals(true,p.snapshot(200)["countLimited"])
  }
  @Test fun composerRecognitionDoesNotTreatArbitraryEditorLabelsAsPrompts() {
    assertTrue(ExperimentRules.isComposerField("Ask anything"))
    assertTrue(ExperimentRules.isComposerField("", "com.openai.chatgpt:id/prompt_input"))
    for(label in listOf("Search", "검색", "Email", "Password", "이름", "Instructions")) assertFalse(ExperimentRules.isComposerField(label))
    assertFalse(ExperimentRules.isComposerField("prompt_input_contains_secret"))
  }
}
