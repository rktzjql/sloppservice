package expo.modules.aiusage
import org.junit.Assert.*
import org.junit.Test
class InputSignalTest {
  @Test fun fastPollingIsLimitedToFreshClearEvidence() {
    val s=draft();assertFalse(s.pendingInput(1150));s.input("ChatGPT:1",false,1200)
    assertTrue(s.pendingInput(1300));assertFalse(s.pendingInput(3800))
    s.input("ChatGPT:1",true,1400);assertFalse(s.pendingInput(1500))
  }

  @Test fun shortMissingWindowCanRecoverButNeverCountsByItself() {
    val s=draft();s.input("ChatGPT:1",false,1200)
    assertTrue(s.unavailable(1250))
    assertTrue(s.observe("ChatGPT:1",false,true,1500))
    assertFalse(s.observe("ChatGPT:1",false,true,1600))
  }
  @Test fun longMissingWindowOrDifferentWindowDiscardsEvidence() {
    val s=draft();s.input("ChatGPT:1",false,1200);s.unavailable(1250)
    assertFalse(s.observe("ChatGPT:1",false,true,2100))
    val t=draft();t.input("ChatGPT:1",false,1200);t.unavailable(1250)
    assertFalse(t.observe("ChatGPT:2",false,true,1500))
  }
  @Test fun diagnosticsSeparateInputChecksFromClearsAndKeepOnlyBoundedEnums() {
    val d=SignalDiagnostics();d.input(true);d.input(true);d.input(false);d.input(false)
    assertEquals(4,d.snapshot()["inputEvents"]);assertEquals(1,d.snapshot()["inputClearTransitions"])
    assertEquals(2,d.snapshot()["inputNonemptyChecks"])
    d.failure("root_missing");d.probe("unavailable")
    assertEquals("root_missing",d.snapshot()["probeFailure"])
    repeat(30){d.probe(if(it%2==0) "ready" else "generating")}
    assertTrue((d.snapshot()["recentStates"] as List<*>).size<=16)
    d.clear();assertEquals(0,d.snapshot()["inputClearTransitions"])
  }

  @Test fun backgroundPollingRequiresRecentKnownInputAndUsableScreen() {
    val d=SignalDiagnostics();d.event("ChatGPT",false,1000);d.probe("ready")
    assertFalse(d.shouldPoll(1100));d.input(true);assertTrue(d.shouldPoll(1100))
    assertFalse(d.shouldPoll(122000));d.probe("background");assertFalse(d.shouldPoll(1200))
    d.probe("bounded");assertFalse(d.shouldPoll(1200))
  }

  private fun draft(): SendTransition = SendTransition().also {
    it.observe("ChatGPT:1",false,false,1000)
    it.input("ChatGPT:1",true,1100)
  }
  @Test fun clearThenGenerationCountsWithoutClickOrSendButton() {
    val s=draft(); s.input("ChatGPT:1",false,1200)
    assertTrue(s.observe("ChatGPT:1",false,true,1400))
    assertEquals("input-transition",s.lastDetection)
    assertFalse(s.observe("ChatGPT:1",false,true,2000))
    assertFalse(s.direct("ChatGPT:1",2100))
  }
  @Test fun typingAndManualDeletionAloneNeverCount() {
    val s=draft();s.input("ChatGPT:1",false,1200)
    assertFalse(s.observe("ChatGPT:1",false,false,1500))
    assertFalse(s.observe("ChatGPT:1",false,true,5000))
  }
  @Test fun openingStreamOrEditingDuringGenerationDoesNotCount() {
    val s=SendTransition();assertFalse(s.observe("ChatGPT:1",false,true,1000))
    s.input("ChatGPT:1",true,1100);s.input("ChatGPT:1",false,1200)
    assertFalse(s.observe("ChatGPT:1",false,true,1500))
  }
  @Test fun windowChangeUnknownScanAndPauseDiscardDraftEvidence() {
    val s=draft();s.input("ChatGPT:1",false,1200)
    assertFalse(s.observe("ChatGPT:2",false,true,1400))
    val t=draft();t.input("ChatGPT:1",false,1200);t.clear()
    assertFalse(t.observe("ChatGPT:1",false,true,1400))
  }
  @Test fun retypingCancelsPendingClearAndDirectClickPreventsDuplicate() {
    val s=draft();s.input("ChatGPT:1",false,1200);s.input("ChatGPT:1",true,1250)
    assertFalse(s.observe("ChatGPT:1",false,true,1400))
    val t=draft();assertTrue(t.direct("ChatGPT:1",1150));t.input("ChatGPT:1",false,1200)
    assertFalse(t.observe("ChatGPT:1",false,true,1400))
  }
  @Test fun pollingSameDraftAfterDirectClickDoesNotResetDeduplication() {
    val s=draft();assertTrue(s.direct("ChatGPT:1",1150))
    s.input("ChatGPT:1",true,1160);s.input("ChatGPT:1",false,1200)
    assertFalse(s.observe("ChatGPT:1",false,true,1400))
  }
  @Test fun secondCompletedCycleCountsOnceWithoutSendButton() {
    val s=draft();s.input("ChatGPT:1",false,1200);assertTrue(s.observe("ChatGPT:1",false,true,1400))
    s.observe("ChatGPT:1",false,false,4000);s.input("ChatGPT:1",true,4100);s.input("ChatGPT:1",false,4200)
    assertTrue(s.observe("ChatGPT:1",false,true,4400))
  }
}
