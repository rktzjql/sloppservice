package expo.modules.aiusage
import org.junit.Assert.*
import org.junit.Test

class ControlScannerTest {
  private class Node(val send: Boolean = false, val stop: Boolean = false, val children: List<Node> = emptyList()) {
    var released = 0
  }
  private fun scanner(clock: () -> Long = { 0L }) = ControlScanner<Node>(
    facts = { ControlFacts(true,it.children.size,it.send,it.stop) },
    child = { node,index -> node.children[index] }, release = { it.released++ }, time = clock)
  @Test fun composerSubtreeDoesNotIncludeLongHistory() {
    val send = Node(send = true)
    val composer = Node(children = listOf(Node(),send))
    val root = Node(children = List(1000) { Node() } + composer)
    val scan = scanner().scan(composer,100)
    assertTrue(scan.ready); assertFalse(scan.bounded); assertEquals(3,scan.visited)
    assertEquals(0,root.released); assertEquals(1,composer.released); assertEquals(1,send.released)
  }
  @Test fun partialScanCannotArmEvenWhenSendWasSeen() {
    val send = Node(send = true)
    val root = Node(children = List(300) { Node() } + send)
    val result = scanner().scan(root,100,maxNodes=240)
    assertTrue(result.bounded); assertFalse(result.ready); assertEquals(240,result.visited)
    assertEquals(1,root.released); assertEquals(1,send.released)
  }
  @Test fun fullScanSupportsLargerWindowsAndExactStopState() {
    val root = Node(children = List(300) { Node() } + Node(stop=true))
    val result = scanner().scan(root,100)
    assertFalse(result.bounded); assertTrue(result.stopped); assertEquals(302,result.visited)
  }
  @Test fun deadlineAndDepthLimitReleaseNodesAndDiscardPartialResults() {
    val root = Node(send=true)
    assertTrue(scanner { 100 }.scan(root,100).bounded); assertEquals(1,root.released)
    val leaf = Node(); val middle = Node(children=listOf(leaf)); val top = Node(send=true,children=listOf(middle))
    val result = scanner().scan(top,100,maxDepth=1)
    assertTrue(result.bounded); assertFalse(result.ready)
    assertEquals(1,top.released); assertEquals(1,middle.released); assertEquals(0,leaf.released)
  }
  @Test fun exceptionsReleaseAcquiredNodes() {
    val root = Node()
    val scanner = ControlScanner<Node>({ throw IllegalStateException() },{_,_->null},{it.released++},{0L})
    try { scanner.scan(root,100); fail("Expected exception") } catch (_: IllegalStateException) {}
    assertEquals(1,root.released)
  }
}
