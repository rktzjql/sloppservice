package expo.modules.aiusage

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo

// Class name retained so existing Android accessibility grants survive an update.
class ChatGptExperimentService : AccessibilityService() {
  companion object {
    const val PREFS = "chatgpt_reading_experiment"
    @Volatile var instance: ChatGptExperimentService? = null
    val counter = ExperimentCounter()
    val diagnostics = SignalDiagnostics()
    val screenDiagnostic = ScreenDiagnostic()
    val promptPreview = PromptPreview()
  }
  private val handler = Handler(Looper.getMainLooper())
  private val previewExpiry = Runnable { promptPreview.expire(SystemClock.uptimeMillis()) }
  fun clearPromptPreview() { handler.removeCallbacks(previewExpiry); promptPreview.clear() }
  private val transition = SendTransition()
  private val composerLease = ComposerLease()
  private var composer: AccessibilityNodeInfo? = null
  private val composerExpiry = Runnable { clearComposer() }
  private fun clearComposer() { handler.removeCallbacks(composerExpiry); composer?.recycle(); composer = null; composerLease.clear() }
  private fun rememberComposer(key: String, now: Long) {
    composerLease.remember(key,now)
    handler.removeCallbacks(composerExpiry); handler.postDelayed(composerExpiry,3501L)
  }
  private var scheduled = false
  private var scheduledAt = 0L
  private var lastProbe = 0L
  private var retryRoot = false
  private var rootRetries = 0
  private val probeTask = object : Runnable {
    override fun run() {
      scheduled = false
      if (!allowed()) return
      probeButtons()
      // Keep the idle baseline fresh while a consented draft is on screen.
      // Stop on background/unknown scans or after two minutes without app events.
      if (retryRoot && rootRetries++ < 2) {
        scheduled = true; scheduledAt = SystemClock.uptimeMillis()+350L; handler.postDelayed(this,350L)
      } else if (inputConsent() && diagnostics.shouldPoll(System.currentTimeMillis())) {
        val delay = if (transition.pendingInput(SystemClock.uptimeMillis())) 150L else 1000L
        scheduled = true; scheduledAt = SystemClock.uptimeMillis()+delay; handler.postDelayed(this,delay)
      }
    }
  }
  override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
    diagnostics.lifecycle("connected",System.currentTimeMillis())
    // Refresh the live subscription too: an update can retain an old connected service.
    serviceInfo = serviceInfo.apply {
      eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
        AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
      packageNames = arrayOf("com.openai.chatgpt", "com.google.android.apps.bard")
      flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
      notificationTimeout = 0
    }
    resumeAutomatic()
  }
  fun resumeAutomatic() {
    val prefs=getSharedPreferences(PREFS,MODE_PRIVATE)
    if(prefs.getBoolean("automatic_v3_consent",false) && prefs.getBoolean("auto_send_enabled",false) && !prefs.getBoolean("storage_error",false)) counter.resume() else counter.stop()
  }
  override fun onInterrupt() { diagnostics.lifecycle("interrupted",System.currentTimeMillis()); stopReading() }
  override fun onUnbind(intent: Intent?): Boolean {
    diagnostics.lifecycle("unbound",System.currentTimeMillis()); stopReading()
    if (instance === this) instance = null
    return super.onUnbind(intent)
  }
  override fun onDestroy() {
    diagnostics.lifecycle("destroyed",System.currentTimeMillis()); stopReading()
    if (instance === this) instance = null
    super.onDestroy()
  }
  fun stopReading() {
    cancelScreenDiagnostic()
    clearPromptPreview()
    counter.stop(); transition.clear(); clearComposer(); retryRoot = false; rootRetries = 0
    handler.removeCallbacks(probeTask); scheduled = false
  }
  private fun allowed(): Boolean {
    resumeAutomatic()
    return counter.snapshot()["active"] == true
  }
  private fun usable(node: AccessibilityNodeInfo, target: String) = (node.packageName == null || node.packageName?.toString() == target) && !node.isEditable && !node.isPassword

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    if (event == null || !allowed()) return
    val target = event.packageName?.toString() ?: return
    val provider = ExperimentRules.providerFor(target) ?: return
    val click = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
    if (!click && event.eventType !in setOf(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
        AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED, AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED)) return
    screenDiagnostic.event(SystemClock.uptimeMillis(), click)
    diagnostics.event(provider, click, System.currentTimeMillis())
    if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && (inputConsent() || previewConsent())) {
      val source = event.source
      if (source != null) try { observeInput(source,target,"$provider:${event.windowId}",event.eventTime) }
      catch (_: Exception) { transition.clear() }
      finally { source.recycle() }
    }
    scheduleProbe()
    if (!click) return
    // Click path: event.text, editable fields and answer text are never accessed.
    var match: Boolean? = null
    val nodes = mutableListOf<AccessibilityNodeInfo>()
    try {
      var node = event.source
      var depth = 0
      while (node != null && depth++ < 4) {
        nodes.add(node)
        if (!usable(node,target)) break
        if (node.isClickable || node.className?.toString()?.contains("Button") == true || node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }) {
          // Stop at the nearest clickable control. Never search a parent screen's siblings.
          match = isSendControl(node,target)
          break
        }
        if (depth < 4) node = node.parent else break
      }
      if (match != true && event.className?.toString()?.contains("Button") == true) {
        // Some Android/Compose buttons emit click events without a retrievable source.
        // Consult only the button event's accessibility label, never event.text.
        if (ExperimentRules.isSend(event.contentDescription?.toString() ?: "")) match = true
      }
    } catch (_: Exception) { match = null }
    finally { nodes.forEach { it.recycle() } }
    val time=System.currentTimeMillis()
    val countAllowed = match != true || transition.direct("$provider:${event.windowId}", event.eventTime)
    if(counter.click(match, event.eventTime, time,provider,countAllowed)) save(provider,time,"click","$provider:${event.windowId}")
  }


  private fun save(provider: String, time: Long, method: String, key: String) {
    try {
      AutoSendStore.get(this).append(provider,time,method)
      if (previewConsent() && provider == "ChatGPT") promptPreview.mark(key,method,SystemClock.uptimeMillis())
    }
    catch (_: Exception) {
      stopReading()
      getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean("storage_error",true).apply()
    }
  }

  private fun inputConsent() = getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("input_signal_consent",false)
  private fun previewConsent() = getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("prompt_preview_consent",false)
  private fun observeInput(node: AccessibilityNodeInfo, target: String, key: String, time: Long) {
    if (!node.isEditable || !node.isFocused || !node.isVisibleToUser || node.isPassword || node.packageName?.toString() != target) return
    val preview = previewConsent() && target == "com.openai.chatgpt" && isComposerForPreview(node,target)
    if (!inputConsent() && !preview) return
    val content = if (android.os.Build.VERSION.SDK_INT >= 26 && node.isShowingHintText) "" else node.text ?: return
    if (preview) {
      promptPreview.observe(key,content,SystemClock.uptimeMillis())
      if (content.isNotEmpty()) {
        handler.removeCallbacks(previewExpiry); handler.postDelayed(previewExpiry,PromptPreview.TTL+1)
      }
    }
    if (inputConsent()) {
      val present = content.isNotEmpty()
      diagnostics.input(present)
      transition.input(key,present,time)
    }
  }
  private fun isComposerForPreview(node: AccessibilityNodeInfo, target: String): Boolean {
    // Ensure delayed events cannot capture a background window or another editor.
    val active = activeTargetRoot() ?: return false
    try { if (active.packageName?.toString() != target || active.windowId != node.windowId) return false }
    finally { active.recycle() }
    val hint = if (android.os.Build.VERSION.SDK_INT >= 26) node.hintText?.toString() ?: "" else ""
    if (ExperimentRules.isComposerField(hint,node.viewIdResourceName ?: "") ||
        ExperimentRules.isComposerField(node.contentDescription?.toString() ?: "")) return true
    // Unknown fields are accepted only beside a recognized send control in a small subtree.
    var parent = node.parent
    val deadline = SystemClock.uptimeMillis()+25L
    try {
      repeat(2) {
        val current = parent ?: return false
        parent = null
        try {
          if (current.packageName?.toString() != target || current.windowId != node.windowId || current.childCount !in 1..24) return false
          val scan = ControlScanner<AccessibilityNodeInfo>(facts = { child ->
            if (!usable(child,target) || !child.isVisibleToUser) ControlFacts(false,0)
            else ControlFacts(true,child.childCount,
              ExperimentRules.isControl(child.className?.toString() ?: "",child.isClickable,child.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }) && isSendControl(child,target))
          },child={item,index->item.getChild(index)},release={it.recycle()},time={SystemClock.uptimeMillis()})
            .scan(AccessibilityNodeInfo.obtain(current),deadline,maxNodes=80,maxDepth=5)
          if (scan.ready) return true
          parent = current.parent
        } finally { current.recycle() }
      }
    } finally { parent?.recycle() }
    return false
  }

  private fun scheduleProbe() {
    val now = SystemClock.uptimeMillis()
    val interval = if (transition.pendingInput(now)) 150L else 500L
    val due = maxOf(now,lastProbe+interval)
    // A delayed idle poll must not hold up fresh typing/clearing signals.
    if (scheduled && scheduledAt <= due) return
    handler.removeCallbacks(probeTask)
    scheduled = true; scheduledAt = due
    handler.postDelayed(probeTask,due-now)
  }

  private fun activeTargetRoot(): AccessibilityNodeInfo? {
    val primary = rootInActiveWindow
    // Keep a known application root (including our own app) so backgrounding clears state.
    if (primary != null && ExperimentRules.providerFor(primary.packageName?.toString() ?: "") != null) return primary
    var selected: AccessibilityNodeInfo? = null
    val available = windows
    try {
      for (window in available) {
        if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION || (!window.isActive && !window.isFocused)) continue
        val candidate = window.root ?: continue
        if (ExperimentRules.providerFor(candidate.packageName?.toString() ?: "") != null) { selected = candidate; break }
        candidate.recycle()
      }
    } finally { available.forEach { it.recycle() } }
    if (selected != null) { primary?.recycle(); return selected }
    return primary
  }

  private fun probeButtons() {
    retryRoot = false
    lastProbe = SystemClock.uptimeMillis()
    val deadline = lastProbe + 120L
    var root: AccessibilityNodeInfo? = null
    var ancestor: AccessibilityNodeInfo? = null
    var candidate: AccessibilityNodeInfo? = null
    var visited = 0
    var scope = "composer"
    try {
      val activeRoot = activeTargetRoot()
      root = activeRoot
      if (activeRoot == null) {
        diagnostics.failure("root_missing"); diagnostics.probe("unavailable")
        retryRoot = transition.unavailable(SystemClock.uptimeMillis()); return
      }
      rootRetries = 0
      val target = activeRoot.packageName?.toString() ?: ""
      val provider = ExperimentRules.providerFor(target)
      if (provider == null) { diagnostics.probe("background"); transition.clear(); clearComposer(); return }
      val key = "$provider:${activeRoot.windowId}"
      val scanner = ControlScanner<AccessibilityNodeInfo>(
        facts = { node ->
          if (!usable(node,target) || !node.isVisibleToUser) ControlFacts(false,0)
          else {
            val id = node.viewIdResourceName ?: ""
            var send = ExperimentRules.isSend("",id)
            var stop = ExperimentRules.isStop("",id)
            if (ExperimentRules.isControl(node.className?.toString() ?: "",node.isClickable,
                node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK })) {
              send = send || isSendControl(node,target)
              stop = stop || isSendControl(node,target,stopControl = true)
            }
            for (action in node.actionList) if (action.id == AccessibilityNodeInfo.ACTION_CLICK) {
              send = send || ExperimentRules.isSend(action.label?.toString() ?: "")
              stop = stop || ExperimentRules.isStop(action.label?.toString() ?: "")
            }
            // A confirmed Send control's immediate parent is usually the composer
            // button slot. Retain only its metadata handle, never the text content.
            if (send && node.isEnabled && candidate == null && scope != "cached_composer") {
              val parent = node.parent
              if (parent != null) {
                if (usable(parent,target) && parent.packageName?.toString() == target &&
                    parent.windowId == activeRoot.windowId && parent.childCount in 1..24)
                  candidate = parent
                else parent.recycle()
              }
            }
            ControlFacts(true,node.childCount,send && node.isEnabled,stop && node.isEnabled)
          }
        }, child = { node,index -> node.getChild(index) }, release = { it.recycle() },
        time = { SystemClock.uptimeMillis() })
      var result: ControlScan? = null
      val cached = composer
      if (cached != null) {
        if (composerLease.valid(key,SystemClock.uptimeMillis()) && cached.refresh() &&
            cached.isVisibleToUser && cached.packageName?.toString() == target && cached.windowId == activeRoot.windowId) {
          scope = "cached_composer"
          val local = scanner.scan(AccessibilityNodeInfo.obtain(cached),deadline,maxNodes=120)
          visited += local.visited
          if (!local.bounded && (local.ready || local.stopped)) {
            result = local
            if (local.ready) rememberComposer(key,SystemClock.uptimeMillis())
          } else clearComposer()
        } else clearComposer()
      }
      // Input state observation still runs when the cached slot supplies controls.
      val focus = activeRoot.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
      if (focus != null) try {
        if (focus.isEditable && !focus.isPassword && focus.packageName?.toString() == target && focus.windowId == activeRoot.windowId) {
          observeInput(focus,target,key,SystemClock.uptimeMillis())
          if (result == null) ancestor = focus.parent
        }
      } finally { focus.recycle() }
      if (result == null) scope = "composer"
      var depth = 0
      while (result == null && ancestor != null && depth++ < 3 && SystemClock.uptimeMillis() < deadline) {
        val node = ancestor!!
        ancestor = null
        if (node.packageName?.toString() != target || node.windowId != activeRoot.windowId) { node.recycle(); break }
        ancestor = node.parent
        val scan = scanner.scan(node,deadline,maxNodes = 240)
        visited += scan.visited
        if (!scan.bounded && (scan.ready || scan.stopped)) { result = scan; break }
        if (scan.bounded) break
      }
      if (result == null) {
        scope = "window"
        root = null // ownership passes to scanner
        result = scanner.scan(activeRoot,deadline)
        visited += result.visited
      }
      val scan = result
      // Even if a large outer scan was bounded, this candidate is not evidence:
      // a future complete local scan must confirm its state before counting.
      if (candidate != null) {
        clearComposer(); composer = candidate; candidate = null
        rememberComposer(key,SystemClock.uptimeMillis())
      }
      diagnostics.scan(visited,SystemClock.uptimeMillis()-lastProbe,scope)
      if (scan.bounded) { diagnostics.probe("bounded"); transition.clear(); return }
      diagnostics.probe(if (scan.stopped) "generating" else if (scan.ready) "ready" else "no_controls")
      val now = SystemClock.uptimeMillis()
      if (transition.observe(key,scan.ready,scan.stopped,now) && counter.transition(now,System.currentTimeMillis(),provider))
        save(provider,System.currentTimeMillis(),transition.lastDetection,key)
    } catch (e: Exception) {
      diagnostics.failure(when(e) { is SecurityException -> "access_denied"; is IllegalStateException -> "node_invalid"; else -> "scan_exception" })
      diagnostics.probe("unavailable"); transition.clear(); clearComposer()
    }
    finally { candidate?.recycle(); ancestor?.recycle(); root?.recycle() }
  }

  // Scheduled only by an explicit in-app action; existing count rules stay separate.
  private val diagnosticTask = object : Runnable {
    override fun run() {
      if (!allowed()) { cancelScreenDiagnostic(); return }
      val now = SystemClock.uptimeMillis()
      if (screenDiagnostic.tick(now)) inspectScreenMetadata()
      if (screenDiagnostic.pending()) handler.postDelayed(this,1000L)
    }
  }
  fun startScreenDiagnostic() {
    check(allowed()) { "AUTOMATIC_RECORDING_REQUIRED" }
    handler.removeCallbacks(diagnosticTask)
    screenDiagnostic.begin(SystemClock.uptimeMillis())
    handler.postDelayed(diagnosticTask,5000L)
  }
  fun cancelScreenDiagnostic() { handler.removeCallbacks(diagnosticTask); screenDiagnostic.cancel() }
  private fun inspectScreenMetadata() {
    var root: AccessibilityNodeInfo? = null
    var provider = "none"
    var editable = false; var readable = false; var nonempty = false
    var send = false; var stop = false
    try {
      val activeRoot = activeTargetRoot()
      root = activeRoot
      if (activeRoot == null) {
        screenDiagnostic.sample(provider,0,false,false,false,false,false,false,"root_missing"); return
      }
      val target = activeRoot.packageName?.toString() ?: ""
      provider = ExperimentRules.providerFor(target) ?: "none"
      if (provider == "none") {
        screenDiagnostic.sample(provider,0,false,false,false,false,false,false,"background"); return
      }
      val consent = inputConsent()
      val scan = ControlScanner<AccessibilityNodeInfo>(facts = { node ->
        if ((node.packageName != null && node.packageName?.toString() != target) || node.isPassword || !node.isVisibleToUser) ControlFacts(false,0)
        else if (node.isEditable) {
          editable = true
          if (consent && node.isFocused && node.packageName?.toString() == target) {
            // Same empty/nonempty scope as existing input-signal consent. No string copy.
            val content = node.text
            if (content != null && (android.os.Build.VERSION.SDK_INT < 26 || !node.isShowingHintText)) { readable = true; nonempty = nonempty || content.isNotEmpty() }
          }
          ControlFacts(false,0)
        } else {
          if (ExperimentRules.isControl(node.className?.toString() ?: "",node.isClickable,
              node.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK })) {
            send = send || (node.isEnabled && isSendControl(node,target))
            stop = stop || (node.isEnabled && isSendControl(node,target,true))
          }
          ControlFacts(true,node.childCount)
        }
      }, child = { node,index -> node.getChild(index) }, release = { it.recycle() }, time = { SystemClock.uptimeMillis() })
      root = null // scanner takes ownership and releases nodes on all exits
      val result = scan.scan(activeRoot,SystemClock.uptimeMillis()+80L,maxNodes=1000)
      screenDiagnostic.sample(provider,result.visited,result.bounded,editable,readable,nonempty,send,stop,if(consent) "none" else "input_consent_off")
    } catch (_: Exception) {
      screenDiagnostic.sample(provider,0,true,editable,readable,nonempty,send,stop,"scan_error")
    } finally { root?.recycle() }
  }

  private fun isSendControl(control: AccessibilityNodeInfo, target: String, stopControl: Boolean = false): Boolean {
    fun matches(label: String, id: String = "") = if (stopControl) ExperimentRules.isStop(label,id) else ExperimentRules.isSend(label,id)
    fun marked(node: AccessibilityNodeInfo) = matches(node.contentDescription?.toString() ?: "", node.viewIdResourceName ?: "")
    if (marked(control)) return true
    // A native Button's text is its label. Generic clickable message text is never read.
    if (control.className?.toString()?.contains("Button") == true && matches(control.text?.toString() ?: "")) return true
    var visited = 0
    fun iconLabel(node: AccessibilityNodeInfo, depth: Int): Boolean {
      if (depth > 2 || ++visited > 12 || !usable(node,target) || node.isClickable) return false
      if (marked(node)) return true
      for (i in 0 until minOf(node.childCount,12)) {
        if (visited >= 12) break
        val child = node.getChild(i) ?: continue
        try { if (iconLabel(child, depth+1)) return true } finally { child.recycle() }
      }
      return false
    }
    for (i in 0 until minOf(control.childCount,12)) {
      if (visited >= 12) break
      val child = control.getChild(i) ?: continue
      try { if (iconLabel(child, 1)) return true } finally { child.recycle() }
    }
    return false
  }
}
