package expo.modules.aiusage

/** Traverses metadata only. Frames acquire one child at a time so wide histories
 * cannot exhaust the budget before we even inspect a composer control. */
data class ControlFacts(val traverse: Boolean, val children: Int, val ready: Boolean = false, val stopped: Boolean = false)
data class ControlScan(val ready: Boolean, val stopped: Boolean, val visited: Int, val bounded: Boolean)
class ControlScanner<N : Any>(
  private val facts: (N) -> ControlFacts,
  private val child: (N, Int) -> N?,
  private val release: (N) -> Unit,
  private val time: () -> Long,
) {
  private data class Frame<N>(val node: N, val depth: Int, var next: Int = -1, var entered: Boolean = false)
  // Takes ownership of root, including on error and limit exits.
  fun scan(root: N, deadline: Long, maxNodes: Int = 800, maxDepth: Int = 48): ControlScan {
    val stack = java.util.ArrayDeque<Frame<N>>()
    stack.addLast(Frame(root, 0))
    var visited = 0; var ready = false; var stopped = false; var bounded = false
    try {
      while (stack.isNotEmpty()) {
        if (time() >= deadline) { bounded = true; break }
        val frame = stack.peekLast() ?: break
        if (!frame.entered) {
          if (visited >= maxNodes) { bounded = true; break }
          visited++
          val f = facts(frame.node)
          frame.entered = true
          if (f.traverse) {
            ready = ready || f.ready; stopped = stopped || f.stopped
            if (frame.depth >= maxDepth && f.children > 0) { bounded = true; break }
            frame.next = f.children - 1
          }
        }
        if (frame.next < 0) release(stack.removeLast().node)
        else child(frame.node, frame.next--)?.let { stack.addLast(Frame(it, frame.depth + 1)) }
      }
    } finally { while (stack.isNotEmpty()) release(stack.removeLast().node) }
    // Partial evidence must never arm or count a transition.
    return ControlScan(ready && !bounded, stopped && !bounded, visited, bounded)
  }
}
