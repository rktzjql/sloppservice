package expo.modules.aiusage

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.provider.Settings
import expo.modules.kotlin.functions.Queues
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class AiUsageModule : Module() {
  private val targets = setOf("com.openai.chatgpt", "com.google.android.apps.bard", "com.anthropic.claude")
  private fun context(): Context = requireNotNull(appContext.reactContext) { "Android context unavailable" }
  private fun permitted(): Boolean {
    val ctx = context()
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
  }
  override fun definition() = ModuleDefinition {
    Name("AiUsage")
    AsyncFunction("experimentStatus") {
      ChatGptExperimentService.counter.snapshot() + ChatGptExperimentService.diagnostics.snapshot() + mapOf(
        "screenDiagnostic" to ChatGptExperimentService.screenDiagnostic.snapshot(android.os.SystemClock.uptimeMillis()),
        "deviceModel" to android.os.Build.MODEL, "androidVersion" to android.os.Build.VERSION.RELEASE,
        "promptPreviewConsent" to context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).getBoolean("prompt_preview_consent",false),
        "inputSignalConsent" to context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).getBoolean("input_signal_consent",false),
        "connected" to (ChatGptExperimentService.instance != null),
        "accessibilityEnabled" to ((context().getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager)
          .getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
          .any { it.resolveInfo.serviceInfo.packageName == context().packageName &&
            it.resolveInfo.serviceInfo.name == ChatGptExperimentService::class.java.name }),
        "enabled" to context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).getBoolean("auto_send_enabled",false),
        "storageError" to context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).getBoolean("storage_error",false),
        "consent" to context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).getBoolean("automatic_v3_consent", false))
    }
    AsyncFunction("setPromptPreviewConsent") { enabled: Boolean ->
      val prefs = context().getSharedPreferences(ChatGptExperimentService.PREFS,Context.MODE_PRIVATE)
      if (enabled) check(prefs.getBoolean("automatic_v3_consent",false)) { "CONSENT_REQUIRED" }
      prefs.edit().putBoolean("prompt_preview_consent",enabled).apply()
      ChatGptExperimentService.instance?.clearPromptPreview()
      ChatGptExperimentService.promptPreview.clear()
    }.runOnQueue(Queues.MAIN)
    // Raw content is deliberately excluded from experimentStatus and shareable diagnostics.
    AsyncFunction("promptPreview") {
      val prefs = context().getSharedPreferences(ChatGptExperimentService.PREFS,Context.MODE_PRIVATE)
      if (!prefs.getBoolean("prompt_preview_consent",false) || !prefs.getBoolean("auto_send_enabled",false) || ChatGptExperimentService.instance == null)
        ChatGptExperimentService.promptPreview.clear()
      ChatGptExperimentService.promptPreview.snapshot(android.os.SystemClock.uptimeMillis())
    }.runOnQueue(Queues.MAIN)
    AsyncFunction("clearPromptPreview") {
      ChatGptExperimentService.instance?.clearPromptPreview()
      ChatGptExperimentService.promptPreview.clear()
    }.runOnQueue(Queues.MAIN)
    AsyncFunction("startScreenDiagnostic") {
      val service = checkNotNull(ChatGptExperimentService.instance) { "ACCESSIBILITY_NOT_CONNECTED" }
      service.startScreenDiagnostic()
    }.runOnQueue(Queues.MAIN)
    AsyncFunction("cancelScreenDiagnostic") {
      ChatGptExperimentService.instance?.cancelScreenDiagnostic()
      ChatGptExperimentService.screenDiagnostic.cancel()
    }.runOnQueue(Queues.MAIN)
    AsyncFunction("consentToExperiment") {
      context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).edit().putBoolean("automatic_v3_consent", true).putBoolean("auto_send_enabled",true).putBoolean("storage_error",false).apply()
      ChatGptExperimentService.instance?.resumeAutomatic()
      context().startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    AsyncFunction("setInputSignalConsent") { enabled: Boolean ->
      context().getSharedPreferences(ChatGptExperimentService.PREFS,Context.MODE_PRIVATE).edit()
        .putBoolean("input_signal_consent",enabled).apply()
      ChatGptExperimentService.instance?.stopReading()
      ChatGptExperimentService.instance?.resumeAutomatic()
    }
    AsyncFunction("reconnectExperiment") {
      check(context().getSharedPreferences(ChatGptExperimentService.PREFS,Context.MODE_PRIVATE).getBoolean("automatic_v3_consent",false)) { "CONSENT_REQUIRED" }
      context().startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    AsyncFunction("startExperiment") {
      check(ChatGptExperimentService.instance != null) { "ACCESSIBILITY_NOT_CONNECTED" }
      check(context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).getBoolean("automatic_v3_consent", false)) { "CONSENT_REQUIRED" }
      context().getSharedPreferences(ChatGptExperimentService.PREFS,Context.MODE_PRIVATE).edit().putBoolean("auto_send_enabled",true).putBoolean("storage_error",false).apply()
      ChatGptExperimentService.instance?.resumeAutomatic()
    }
    AsyncFunction("stopExperiment") {
      context().getSharedPreferences(ChatGptExperimentService.PREFS,Context.MODE_PRIVATE).edit().putBoolean("auto_send_enabled",false).apply()
      ChatGptExperimentService.instance?.stopReading(); ChatGptExperimentService.counter.stop()
    }
    AsyncFunction("querySendRecords") { AutoSendStore.get(context()).records() }
    AsyncFunction("deleteSendRecords") { AutoSendStore.get(context()).clear() }
    AsyncFunction("clearExperiment") {
      context().getSharedPreferences(ChatGptExperimentService.PREFS, Context.MODE_PRIVATE).edit().clear().apply()
      ChatGptExperimentService.instance?.stopReading()
      ChatGptExperimentService.counter.clear()
      ChatGptExperimentService.diagnostics.clear()
      ChatGptExperimentService.screenDiagnostic.clear()
      ChatGptExperimentService.promptPreview.clear()
      AutoSendStore.get(context()).clear()
      ChatGptExperimentService.instance?.disableSelf()
      Unit
    }
    AsyncFunction("isMonitoring") { UsageMonitorService.running }
    AsyncFunction("startMonitoring") {
      check(android.os.Build.VERSION.SDK_INT >= 26) { "ANDROID_8_REQUIRED" }
      check(permitted()) { "USAGE_ACCESS_REQUIRED" }
      val ctx = context()
      check(android.os.Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) { "NOTIFICATION_PERMISSION_REQUIRED" }
      ctx.startForegroundService(Intent(ctx, UsageMonitorService::class.java))
      Unit
    }
    AsyncFunction("stopMonitoring") {
      val ctx = context()
      ctx.stopService(Intent(ctx, UsageMonitorService::class.java))
      Unit
    }
    AsyncFunction("clearReminders") {
      val ctx = context()
      val manager = ctx.getSystemService(android.app.NotificationManager::class.java)
      manager.activeNotifications.filter { it.id == 2 }.forEach { manager.cancel(it.tag, it.id) }
    }
    AsyncFunction("dismissReminder") { sessionId: String ->
      context().getSystemService(android.app.NotificationManager::class.java).cancel(sessionId, 2)
    }
    AsyncFunction("hasPermission") { permitted() }
    AsyncFunction("openSettings") {
      val ctx = context()
      val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      try { ctx.startActivity(intent) }
      catch (_: android.content.ActivityNotFoundException) {
        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      }
    }
    AsyncFunction("queryEvents") { since: Double ->
      check(permitted()) { "USAGE_ACCESS_REQUIRED" }
      val now = System.currentTimeMillis()
      // Never query before the user's opt-in, or more than seven days back.
      val start = maxOf(since.toLong(), now - 7L * 24 * 60 * 60 * 1000)
      val manager = context().getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
      val events = manager.queryEvents(start, now)
      val event = UsageEvents.Event()
      val result = mutableListOf<Map<String, Any>>()
      while (events.hasNextEvent()) {
        events.getNextEvent(event)
        if (event.eventType == UsageEvents.Event.SCREEN_NON_INTERACTIVE || event.eventType == UsageEvents.Event.DEVICE_SHUTDOWN) {
          result.add(mapOf("packageName" to "", "timestamp" to event.timeStamp.toDouble(), "kind" to "stop"))
        } else if (targets.contains(event.packageName)) {
          val kind = when (event.eventType) {
            UsageEvents.Event.ACTIVITY_RESUMED -> "resume"
            UsageEvents.Event.ACTIVITY_PAUSED -> "pause"
            else -> null
          }
          if (kind != null) result.add(mapOf("packageName" to event.packageName, "timestamp" to event.timeStamp.toDouble(), "kind" to kind))
        }
      }
      result
    }
  }
}
