package expo.modules.aiusage

import android.Manifest
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.*
import android.os.Process

/** Explicitly started by the user; no boot receiver, no accessibility service, no content capture. */
class UsageMonitorService : Service() {
  companion object {
    @Volatile var running = false
    const val STOP = "expo.modules.aiusage.STOP"
    const val STATUS_CHANNEL = "ai_usage_status"
    const val QUESTION_CHANNEL = "ai_usage_questions"
    private val names = mapOf("com.openai.chatgpt" to "ChatGPT", "com.google.android.apps.bard" to "Gemini", "com.anthropic.claude" to "Claude")
  }
  private val handler = Handler(Looper.getMainLooper())
  private val opened = mutableMapOf<String, Long>()
  private val pendingEnds = mutableMapOf<String, Long>()
  private val seen = linkedSetOf<String>()
  private var lastRead = 0L
  private var started = 0L
  private val poll = object : Runnable {
    override fun run() {
      if (!running) return
      try { readEvents() } catch (_: Exception) { stopSelf(); return }
      if (running) handler.postDelayed(this, 5000)
    }
  }
  override fun onBind(intent: Intent?) = null
  override fun onCreate() {
    super.onCreate()
    val manager = getSystemService(NotificationManager::class.java)
    manager.createNotificationChannel(NotificationChannel(STATUS_CHANNEL, "AI 사용 감지 상태", NotificationManager.IMPORTANCE_LOW))
    manager.createNotificationChannel(NotificationChannel(QUESTION_CHANNEL, "질문 횟수 확인", NotificationManager.IMPORTANCE_DEFAULT))
  }
  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == STOP) { stopSelf(); return START_NOT_STICKY }
    if (running) return START_NOT_STICKY
    val stopIntent = PendingIntent.getService(this, 0, Intent(this, UsageMonitorService::class.java).setAction(STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val launch = packageManager.getLaunchIntentForPackage(packageName)!!
    val content = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val notification = Notification.Builder(this, STATUS_CHANNEL)
      .setSmallIcon(android.R.drawable.ic_menu_recent_history)
      .setContentTitle("AI 앱 사용을 감지하고 있어요")
      .setContentText("약 5초마다 확인 · 대화 내용은 읽지 않아요")
      .setOngoing(true).setContentIntent(content)
      .addAction(Notification.Action.Builder(null, "감지 중지", stopIntent).build()).build()
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    else startForeground(1, notification)
    started = System.currentTimeMillis(); lastRead = started; running = true
    handler.post(poll)
    return START_NOT_STICKY
  }
  private fun readEvents() {
    val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    if (ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) != AppOpsManager.MODE_ALLOWED) { stopSelf(); return }
    val now = System.currentTimeMillis()
    val usage = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val events = usage.queryEvents(maxOf(started, lastRead - 10000), now)
    val event = UsageEvents.Event()
    while (events.hasNextEvent()) {
      events.getNextEvent(event)
      val pkg = event.packageName ?: ""
      val type = event.eventType
      val isStop = type == UsageEvents.Event.SCREEN_NON_INTERACTIVE || type == UsageEvents.Event.DEVICE_SHUTDOWN
      if (!isStop && !names.containsKey(pkg)) continue
      if (!isStop && type != UsageEvents.Event.ACTIVITY_RESUMED && type != UsageEvents.Event.ACTIVITY_PAUSED) continue
      val key = "$pkg:$type:${event.timeStamp}"
      if (!seen.add(key)) continue
      if (isStop) { for (target in opened.keys.toList()) finishSession(target,pendingEnds[target] ?: event.timeStamp) }
      else if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
        val pending = pendingEnds[pkg]
        if (pending != null && event.timeStamp - pending > 1500) finishSession(pkg,pending)
        pendingEnds.remove(pkg)
        if (!opened.containsKey(pkg)) opened[pkg] = event.timeStamp
      } else if (opened.containsKey(pkg)) pendingEnds[pkg] = event.timeStamp
    }
    for ((pkg, end) in pendingEnds.toMap()) if (now - end > 1500) finishSession(pkg,end)
    lastRead = now
    // Only a ten-second overlap is read; bound in-memory deduplication state.
    while (seen.size > 2000) seen.remove(seen.first())
  }
  private fun finishSession(pkg: String, end: Long) {
    pendingEnds.remove(pkg)
    val start = opened.remove(pkg) ?: return
    if (end <= start) return
    // Automatically counted apps must not also ask for a manual count.
    if (ExperimentRules.providerFor(pkg) != null && ChatGptExperimentService.counter.snapshot()["active"] == true) return
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val uri = Uri.Builder().scheme("slopstop").authority("record")
      .appendQueryParameter("package",pkg).appendQueryParameter("start",start.toString()).appendQueryParameter("end",end.toString()).build()
    val intent = Intent(Intent.ACTION_VIEW, uri).setPackage(packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val seconds = maxOf(1,(end-start)/1000)
    val duration = if(seconds < 60) "${seconds}초" else "${seconds/60}분"
    val notification = Notification.Builder(this, QUESTION_CHANNEL)
      .setSmallIcon(android.R.drawable.ic_menu_edit)
      .setContentTitle("${names[pkg]}를 ${duration} 사용했어요")
      .setContentText("몇 번 질문했나요? 눌러서 영수증에 기록해요.")
      .setAutoCancel(true).setContentIntent(pending).build()
    getSystemService(NotificationManager::class.java).notify("$pkg:$start",2,notification)
  }
  override fun onDestroy() {
    running = false; handler.removeCallbacksAndMessages(null); opened.clear(); pendingEnds.clear(); seen.clear()
    stopForeground(STOP_FOREGROUND_REMOVE)
    super.onDestroy()
  }
}
