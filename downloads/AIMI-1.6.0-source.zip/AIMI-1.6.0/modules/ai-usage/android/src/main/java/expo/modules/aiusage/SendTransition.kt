package expo.modules.aiusage

/** Button-state heuristic, never an answer/content parser. State is local to one window.
 * A recently enabled Send followed by Stop generating suggests a new request.
 * Initial/opened streams, repeated streaming updates, and click+transition duplicates
 * must not produce additional receipts. Unknown/bounded scans reset the baseline.
 */
class SendTransition {
  var lastDetection = "button-transition"; private set
  private var hasText: Boolean? = null
  private var typedAt: Long? = null
  private var clearedAt: Long? = null
  private var idleAt: Long? = null
  private var inputAt = -1L
  private var missingAt: Long? = null
  private var window: String? = null
  private var armedAt: Long? = null
  private var directAt: Long? = null
  private var generationObserved = false
  private var generating = false
  private var inferredCycle = false
  private var observedAt = -1L

  @Synchronized fun clear() {
    missingAt = null; generationObserved = false; hasText = null; typedAt = null; clearedAt = null; idleAt = null; inputAt = -1L
    window = null; armedAt = null; directAt = null; generating = false
    inferredCycle = false; observedAt = -1L
  }
  private fun select(key: String, now: Long) {
    if (missingAt?.let { now - it > 750 } == true) clear()
    missingAt = null
    if (window != key) { clear(); window = key }
  }
  @Synchronized fun unavailable(now: Long): Boolean {
    val since = missingAt ?: now.also { missingAt = it }
    if (now - since > 750) { clear(); return false }
    return true
  }

  @Synchronized fun input(key: String, present: Boolean, now: Long) {
    select(key,now)
    if (now <= inputAt) return
    inputAt = now
    if (present) {
      if (!generating && hasText != true) { directAt = null; inferredCycle = false; generationObserved = false }
      typedAt = now; clearedAt = null
    }
    else if (hasText == true && !generating && typedAt?.let { now - it in 0..120000 } == true &&
      idleAt?.let { now - it in 0..3000 } == true) clearedAt = now
    hasText = present
  }

  @Synchronized fun pendingInput(now: Long): Boolean = clearedAt?.let { now - it in 0..2500 } == true

  @Synchronized fun direct(key: String, now: Long): Boolean {
    select(key,now)
    // A click delivered after its already-recorded state transition is the same send.
    if (inferredCycle) return false
    directAt = now; armedAt = null
    return true
  }

  @Synchronized fun observe(key: String, ready: Boolean, stopped: Boolean, now: Long): Boolean {
    select(key,now)
    if (now <= observedAt) return false
    observedAt = now
    if (stopped) {
      val inputEvidence = clearedAt?.let { now - it in 0..2500 } == true
      val inferred = !generating && (armedAt?.let { now - it in 0..3000 } == true || inputEvidence) &&
        directAt == null
      if (inferred) lastDetection = if (inputEvidence) "input-transition" else "button-transition"
      clearedAt = null
      generationObserved = true; generating = true; armedAt = null
      if (inferred) inferredCycle = true
      return inferred
    }
    idleAt = now
    generating = false
    if (ready) {
      if (generationObserved) { directAt = null; inferredCycle = false; generationObserved = false }
      armedAt = now
    } else if (armedAt?.let { now - it > 3000 } == true) armedAt = null
    return false
  }
}

/** Numeric/enum diagnostics only. No raw labels, content, window IDs or app history. */
class SignalDiagnostics {
  private var inputNonempty = 0
  private var inputClears = 0
  private var readyScans = 0
  private var generatingScans = 0
  private var unavailableScans = 0
  private var probeFailure = "none"
  private val trace = java.util.ArrayDeque<String>()
  private fun remember(value: String) { if (trace.peekLast() != value) trace.addLast(value); while (trace.size > 16) trace.removeFirst() }
  @Synchronized fun failure(value: String) { probeFailure = value; remember("scan:$value") }
  private var lifecycleState = "unknown"
  private var lifecycleAt = 0L
  private var scanNodes = 0
  private var scanMs = 0L
  private var scanScope = "none"
  @Synchronized fun lifecycle(value: String, time: Long) { lifecycleState = value; lifecycleAt = time }
  @Synchronized fun scan(nodes: Int, ms: Long, scope: String) { scanNodes = nodes; scanMs = ms; scanScope = scope }
  private var inputEvents = 0
  private var inputState = "unknown"
  @Synchronized fun input(present: Boolean) { inputEvents++
    if (present) inputNonempty++ else if (inputState == "nonempty") inputClears++
    inputState = if (present) "nonempty" else "empty"
    remember("input:$inputState") }
  private var events = 0
  private var changes = 0
  private var provider = "none"
  private var probe = "waiting"
  private var eventAt = 0L
  @Synchronized fun event(name: String, click: Boolean, time: Long) {
    events++; if (!click) changes++; provider = name; eventAt = time
  }
  @Synchronized fun shouldPoll(now: Long): Boolean = inputState != "unknown" &&
    now - eventAt in 0..120000 && probe in setOf("ready","generating","no_controls")
  @Synchronized fun probe(value: String) {
    probe = value
    if (value == "ready") readyScans++
    if (value == "generating") generatingScans++
    if (value == "unavailable") unavailableScans++
    if (value != "unavailable") probeFailure = "none"
    remember("probe:$value")
  }
  @Synchronized fun clear() { inputNonempty = 0; inputClears = 0; readyScans = 0; generatingScans = 0; unavailableScans = 0; probeFailure = "none"; trace.clear(); inputEvents = 0; inputState = "unknown"; scanNodes = 0; scanMs = 0L; scanScope = "none"; events = 0; changes = 0; provider = "none"; probe = "waiting"; eventAt = 0L }
  @Synchronized fun snapshot(): Map<String, Any> = mapOf(
    "inputNonemptyChecks" to inputNonempty, "inputClearTransitions" to inputClears,
    "readyScans" to readyScans, "generatingScans" to generatingScans, "unavailableScans" to unavailableScans,
    "probeFailure" to probeFailure, "recentStates" to trace.toList(),
    "inputEvents" to inputEvents, "inputState" to inputState,
    "lifecycleState" to lifecycleState, "lifecycleAt" to lifecycleAt.toDouble(),
    "scanNodes" to scanNodes, "scanMs" to scanMs.toDouble(), "scanScope" to scanScope,
    "receivedEvents" to events, "changeEvents" to changes, "lastProvider" to provider,
    "buttonState" to probe, "eventAt" to eventAt.toDouble())
}
