package expo.modules.aiusage

/** Opt-in, memory-only latest composer preview. Separate from shareable diagnostics. */
class PromptPreview {
  companion object { const val TTL = 600000L; const val MAX_PREVIEW_UNITS = 4000; const val MAX_COUNT_UNITS = 100000 }
  private var text = ""
  private var characters = 0
  private var countLimited = false
  private var truncated = false
  private var key = ""
  private var at = 0L
  private var inputState = "unknown"
  private var signal = "none"
  @Synchronized fun observe(window: String, content: CharSequence, now: Long) {
    expire(now)
    if (content.isEmpty()) { if (key == window) inputState = "empty"; return }
    var end = minOf(content.length,MAX_PREVIEW_UNITS)
    if (end < content.length && end > 0 && Character.isHighSurrogate(content[end-1])) end--
    var countEnd = minOf(content.length,MAX_COUNT_UNITS)
    if (countEnd < content.length && countEnd > 0 && Character.isHighSurrogate(content[countEnd-1])) countEnd--
    val next = content.subSequence(0,end).toString()
    val count = Character.codePointCount(content,0,countEnd)
    if (key != window || text != next || characters != count || inputState == "empty" || truncated || content.length > MAX_PREVIEW_UNITS) { signal = "none" }
    key = window; text = next; characters = count; at = now
    truncated = end < content.length; countLimited = countEnd < content.length; inputState = "nonempty"
  }
  @Synchronized fun mark(window: String, method: String, now: Long) {
    expire(now)
    // Conservative association: same window, fresh composer observation. Not server acknowledgement.
    if (key != window || text.isEmpty() || now-at !in 0..15000 || method !in setOf("click","input-transition","button-transition")) return
    signal = method
  }
  @Synchronized fun clear() { text = ""; characters = 0; countLimited = false; truncated = false; key = ""; at = 0; inputState = "unknown"; signal = "none" }
  @Synchronized fun expire(now: Long) { if (text.isNotEmpty() && now-at >= TTL) clear() }
  @Synchronized fun snapshot(now: Long): Map<String,Any> {
    expire(now)
    return mapOf("text" to text,"characters" to characters,"countLimited" to countLimited,"truncated" to truncated,
      "inputState" to inputState,"signal" to signal,"ageSeconds" to if(text.isEmpty()) 0 else ((now-at)/1000).coerceAtLeast(0))
  }
}
