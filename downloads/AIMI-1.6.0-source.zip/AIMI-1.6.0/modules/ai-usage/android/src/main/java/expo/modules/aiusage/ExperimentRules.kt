package expo.modules.aiusage

import java.util.Locale

/** Exact control labels/IDs only; no message text, screen geometry or answer inference. */
object ExperimentRules {
  // Compose can expose a button as a clickable View rather than android.widget.Button.
  fun isControl(className: String, clickable: Boolean, hasClickAction: Boolean): Boolean =
    className.endsWith("Button") || clickable || hasClickAction

  fun providerFor(packageName: String): String? = when(packageName) {
    "com.openai.chatgpt" -> "ChatGPT"
    "com.google.android.apps.bard" -> "Gemini"
    else -> null
  }
  fun isComposerField(label: String, resourceId: String = ""): Boolean =
    normalized(label) in setOf("message chatgpt", "ask anything", "메시지 chatgpt", "chatgpt에 메시지 보내기", "무엇이든 물어보세요", "메시지를 입력하세요") ||
      resourceId.substringAfterLast('/').lowercase(Locale.ROOT) in setOf("prompt_input", "prompt_textarea", "prompt-textarea", "composer_input", "message_input")

  private fun normalized(value: String) = value.trim().trimEnd(':', '：').lowercase(Locale.ROOT)
  fun isSend(label: String, resourceId: String = ""): Boolean =
    normalized(label) in setOf("send", "send message", "send prompt", "보내기", "메시지 보내기", "프롬프트 보내기", "전송", "메시지 전송") ||
    resourceId.substringAfterLast('/').lowercase(Locale.ROOT) in setOf("send_button", "send_message_button", "send_prompt_button")

  fun isStop(label: String, resourceId: String = ""): Boolean =
    normalized(label) in setOf("stop generating", "stop response", "stop responding", "응답 중지", "응답 생성 중지", "생성 중지", "답변 생성 중지") ||
      resourceId.substringAfterLast('/').lowercase(Locale.ROOT) in setOf("stop_generating_button", "stop_response_button")
}

class ExperimentCounter {
  var active = false; private set
  var sends = 0; private set
  var seenClicks = 0; private set
  var checkedAt = 0L; private set
  private val lastSend = mutableMapOf<String,Long>()
  private val counts = mutableMapOf<String,Int>()
  private var lastObserved = -1L
  private var lastMatch = "none"
  @Synchronized fun start() { clear(); active = true }
  @Synchronized fun resume() { active = true }
  @Synchronized fun stop() { active = false }
  @Synchronized fun clear() { active = false; sends = 0; seenClicks = 0; checkedAt = 0; lastSend.clear(); counts.clear(); lastObserved = -1; lastMatch = "none" }
  @Synchronized fun click(match: Boolean?, eventTime: Long, wallTime: Long, provider: String = "ChatGPT", countAllowed: Boolean = true): Boolean {
    if (!active || provider !in setOf("ChatGPT", "Gemini") || eventTime <= lastObserved) return false
    lastObserved = eventTime; seenClicks++; checkedAt = wallTime
    lastMatch = when(match) { true -> "send"; false -> "other"; null -> "unavailable" }
    if (match != true || !countAllowed || (lastSend[provider]?.let { eventTime - it < 700 } == true)) return false
    sends++; counts[provider] = (counts[provider] ?: 0) + 1; lastSend[provider] = eventTime
    return true
  }
  @Synchronized fun transition(eventTime: Long, wallTime: Long, provider: String): Boolean {
    if (!active || provider !in setOf("ChatGPT", "Gemini") ||
      lastSend[provider]?.let { eventTime - it < 700 } == true) return false
    sends++; counts[provider] = (counts[provider] ?: 0) + 1; lastSend[provider] = eventTime
    checkedAt = wallTime
    return true
  }
  @Synchronized fun snapshot(): Map<String, Any> = mapOf("active" to active, "sendCount" to sends, "chatgptCount" to (counts["ChatGPT"] ?: 0), "geminiCount" to (counts["Gemini"] ?: 0), "seenClicks" to seenClicks, "lastMatch" to lastMatch, "checkedAt" to checkedAt.toDouble())
}
