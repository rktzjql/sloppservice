package expo.modules.aiusage

/** Short, user-started metadata diagnostic. Never holds node handles or content. */
class ScreenDiagnostic {
  private var state = "idle"
  private var start = 0L
  private var end = 0L
  private var clicks = 0
  private var changes = 0
  private val samples = mutableListOf<Map<String, Any>>()
  @Synchronized fun begin(now: Long) { state = "waiting"; start = now + 5000L; end = start + 30000L; clicks = 0; changes = 0; samples.clear() }
  @Synchronized fun pending() = state == "waiting" || state == "running"
  @Synchronized fun tick(now: Long): Boolean {
    if (!pending()) return false
    if (now >= end) { state = "complete"; return false }
    if (now < start) return false
    state = "running"; return true
  }
  @Synchronized fun event(now: Long, click: Boolean) {
    if (!tick(now)) return
    if (click) clicks++ else changes++
  }
  @Synchronized fun sample(provider: String, nodes: Int, bounded: Boolean, editable: Boolean, readable: Boolean, nonempty: Boolean, send: Boolean, stop: Boolean, issue: String) {
    if (state != "running" || samples.size >= 30) return
    samples.add(mapOf("provider" to provider, "nodes" to nodes, "bounded" to bounded, "editable" to editable,
      "readable" to readable, "nonempty" to nonempty, "send" to send, "stop" to stop, "issue" to issue))
  }
  @Synchronized fun cancel() { if (pending()) state = "cancelled" }
  @Synchronized fun clear() { state = "idle"; start = 0; end = 0; clicks = 0; changes = 0; samples.clear() }
  @Synchronized fun snapshot(now: Long): Map<String, Any> {
    tick(now)
    return mapOf("state" to state, "remainingSeconds" to if (pending()) ((end-now+999)/1000).coerceAtLeast(0) else 0,
      "samples" to samples.toList(), "clickEvents" to clicks, "changeEvents" to changes,
      "editableSamples" to samples.count { it["editable"] == true }, "readableSamples" to samples.count { it["readable"] == true },
      "nonemptySamples" to samples.count { it["nonempty"] == true }, "sendSamples" to samples.count { it["send"] == true },
      "stopSamples" to samples.count { it["stop"] == true }, "boundedSamples" to samples.count { it["bounded"] == true })
  }
}
