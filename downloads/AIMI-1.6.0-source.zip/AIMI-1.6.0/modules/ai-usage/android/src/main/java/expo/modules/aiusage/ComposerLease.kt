package expo.modules.aiusage

/** A short-lived metadata handle is valid only in the same foreground window. */
class ComposerLease {
  private var key: String? = null
  private var seenAt = -1L
  fun remember(window: String, now: Long) { key = window; seenAt = now }
  fun valid(window: String, now: Long): Boolean = key == window && now - seenAt in 0..3500
  fun clear() { key = null; seenAt = -1L }
}
