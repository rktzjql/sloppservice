package expo.modules.aiusage

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

/** Local metadata only: no message text, button labels, window contents or network calls. */
class AutoSendStore private constructor(context: Context) : SQLiteOpenHelper(context.applicationContext,"auto_send_records.db",null,2) {
  companion object {
    @Volatile private var instance: AutoSendStore? = null
    fun get(context: Context): AutoSendStore = instance ?: synchronized(this) { instance ?: AutoSendStore(context).also { instance=it } }
  }
  override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE sends (id TEXT PRIMARY KEY, provider TEXT NOT NULL, created_at INTEGER NOT NULL, detection TEXT NOT NULL DEFAULT 'click')") }
  override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
    if (old < 2) db.execSQL("ALTER TABLE sends ADD COLUMN detection TEXT NOT NULL DEFAULT 'click'")
  }
  @Synchronized fun append(provider: String, time: Long, detection: String = "click") {
    require(provider == "ChatGPT" || provider == "Gemini")
    require(detection == "click" || detection == "button-transition" || detection == "input-transition")
    val values=ContentValues().apply { put("id",UUID.randomUUID().toString());put("provider",provider);put("created_at",time);put("detection",detection) }
    writableDatabase.insertOrThrow("sends",null,values)
  }
  @Synchronized fun records(): List<Map<String,Any>> {
    val rows=mutableListOf<Map<String,Any>>()
    readableDatabase.rawQuery("SELECT id,provider,created_at,detection FROM sends ORDER BY created_at DESC,id DESC",null).use { cursor ->
      while(cursor.moveToNext()) rows.add(mapOf("id" to cursor.getString(0),"provider" to cursor.getString(1),"createdAt" to cursor.getLong(2).toDouble(),"detection" to cursor.getString(3)))
    }
    return rows
  }
  @Synchronized fun clear() { writableDatabase.delete("sends",null,null) }
}
