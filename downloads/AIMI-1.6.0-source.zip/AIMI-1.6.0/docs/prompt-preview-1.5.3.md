# ChatGPT composer text and character preview — 1.5.3

User-requested experiment for the existing ChatGPT Android app. Requires existing automatic-recording consent/enabled service and a new, separate `prompt_preview_consent` opt-in (default false). No Gemini/OpenAI inference call is made by this feature.

Capture is restricted to the foreground com.openai.chatgpt window, visible focused editable non-password nodes, with a known composer hint/resource ID or a recognized send control in a nearby bounded subtree. Other apps, answer nodes, event.text and arbitrary editable nodes are not fallback capture sources. Unknown structure is rejected; these heuristics still require S24 testing. Placeholder/hint text is treated as empty, not as the user's prompt.

Only the last nonempty observed draft is retained, in process memory. It expires ten minutes after the last observation, and is cleared on preview disable, explicit clear, monitoring stop/disconnect or service destruction. UI state is also cleared on app backgrounding. This is not durable prompt history. No raw text is written to SharedPreferences, receipts, logs, files, network, AI API, or the diagnostic share payload.

Native content is returned by a dedicated `promptPreview()` method, separate from `experimentStatus()`. UI reports Unicode code-point count including whitespace, not tokens or grapheme clusters. Preview is capped at 4,000 UTF-16 units without splitting a surrogate pair; counting is bounded at 100,000 units. Truncation and lower-bound counts are labeled explicitly.

Typing or clearing does not increment send counts. Existing click/transition recording may annotate a recent preview only for the same window and within 15 seconds of its last observation. Labels say draft/unconfirmed, click signal, or inferred state transition; none means server acceptance. Native associations are conservative observations, not proof of submitted text or full capture.

Test path: 영수증 → 기존 영수증·Android 자동 기록 설정 → 자동 기록 설정 → ChatGPT 입력 문장 미리보기. Enable the new consent, type a harmless test phrase in a new ChatGPT conversation, wait 2–3 seconds and return to AIMI. Check content/count before testing sending. If empty, collect the 30-second metadata diagnostic; no real prompt needs to be shared with the developer.

Local checks cover Unicode, truncation, TTL, deletion, same-window/time association and explicit composer label rules. Actual ChatGPT accessibility exposure is not simulated as success; physical S24 verification remains necessary.
