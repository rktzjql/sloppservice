# 1.5.2: on-device accessibility exposure diagnostic

Purpose: determine which screen signals ChatGPT/Gemini actually expose on the user's S24 before changing counting heuristics. This is an explicit 30-second diagnostic, not a proven fix for missed sends.

Entry: 영수증 → 기존 영수증·Android 자동 기록 설정 → 자동 기록 설정 → 30초 화면 진단 시작. Existing accessibility consent, connection and enabled recording are required. Starting the diagnostic prompts an explanation; it waits five seconds for the user to switch apps, then scans once per second for thirty seconds. Stop/pause/disconnect/service destruction cancels it. Results live only in service-process memory until another run or deletion.

Only allowlisted foreground ChatGPT/Gemini application roots are scanned. Password/foreign nodes are excluded. Input text is inspected only for null/empty/nonempty when the existing input-signal consent is on and the field is focused. Hint text is excluded on Android 8+. No prompt strings, chat transcripts, screenshot pixels, arbitrary UI labels, or account identifiers are stored or shared. Provider, booleans, counts, issues, device model and Android version are returned to the app; the user can explicitly share this JSON.

Scan budget: 80 ms, 1,000 nodes, depth 48 per sample. Results say when a scan was incomplete. Partial positive observations are diagnostic only, never counted as sends. Counts of matched samples are observations, not prompt counts. Missing matches may reflect incomplete scans, timing, a different label, or unavailable accessibility data; they do not prove ChatGPT hides the information.

Existing send detection and receipt algorithms are unchanged. The diagnostic does not call an AI API or make a network request. Actual send success would still require evidence beyond a local button click; the ChatGPT app's server acknowledgement is not available through this diagnostic.

Verified locally: TypeScript/tests, native diagnostic duration/cancel/restart/bounded metadata tests and existing native detection tests. S24 end-to-end accessibility results must be collected by the user; no physical phone is attached to this workspace.

Reference: https://developer.android.com/guide/topics/ui/accessibility/views/service
