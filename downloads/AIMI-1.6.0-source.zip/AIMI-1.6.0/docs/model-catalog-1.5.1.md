# Model catalog refresh — 1.5.1

Checked 2026-11-09 (Korea). Replaces the design-only candidate list: Light 5, Medium 6, High 6. Removes Gemini 2.5 Pro, o3, Claude Sonnet 4 and other old design examples from recommendation candidates. Does not rename or migrate saved Gemini API connection settings.

Official sources checked:
- Google: https://firebase.google.com/docs/ai-logic/models — Gemini 4 Argon, 3.8 Flash, 3.5 Flash-Lite; Argon API billing requirement. Direct AI Studio docs could not be fetched by the web tool, so Firebase's official supported-model documentation was used.
- Argon release: https://blog.google/innovation-and-ai/models-and-research/gemini-models/introducing-gemini-4-argon/ — public release October 13, 2026.
- OpenAI: https://developers.openai.com/api/docs/models — GPT-6 Astra/Luna, GPT-6.1 Sol/Terra.
- Anthropic: https://platform.claude.com/docs/en/models/overview — Claude Haiku/Sonnet/Opus 5.5, Fable 5.1.
- Mistral: https://docs.mistral.ai/models — Ministral 3 3B/8B, Small 4, Large 4. Medium 3.5 is in deprecated/retired section and was excluded.
- DeepSeek: https://api-docs.deepseek.com/quick_start/pricing — V4 Pro and deepseek-flash served by V4.1 Flash 1017.

The tiers are AIMI editorial task-fit groupings, not provider rankings, benchmarks or carbon measurements. No claim that every listed model was released recently or is the latest model in every field. Excludes unreleased/restricted research announcements from the general candidate list. Does not pad tiers with the same model at different reasoning settings.

The AI response enum, request candidate descriptions, parsed result validation and displayed cards all share the same catalog. Search supports Argon and 아르곤. Detail view shows use cases, official links and verification date in place of old illustrative measurements. No unverified numeric cost or speed claims were copied to new models. All candidate browsing remains local and makes no extra inference calls.
