import {createServer} from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {createHash,randomUUID,timingSafeEqual} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const hash=v=>createHash('sha256').update(v).digest('hex');
export function createApi({dbPath='requests.sqlite',apiKey,appToken,model='gpt-4.1-mini',fetchApi=fetch,timeoutMs=60000}={}) {
 if(!appToken||appToken.length<24)throw Error('APP_API_TOKEN must contain at least 24 characters');
 const db=new DatabaseSync(dbPath);db.exec(`CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY, owner TEXT, state TEXT, created INTEGER, updated INTEGER, fingerprint TEXT, receipt TEXT); UPDATE requests SET state='unknown' WHERE state='processing';`);
 const answers=new Map();const expiryTimers=new Set();
 const get=id=>db.prepare('SELECT * FROM requests WHERE id=?').get(id);
 const update=(id,state,receipt=null)=>db.prepare('UPDATE requests SET state=?,updated=?,receipt=? WHERE id=?').run(state,Date.now(),receipt?JSON.stringify(receipt):null,id);
 const payload=row=>({id:row.id,state:row.state,createdAt:row.created,updatedAt:row.updated,receipt:row.receipt?JSON.parse(row.receipt):null,answer:answers.get(row.id)??null});
 const server=createServer(async(req,res)=>{
  const send=(code,value)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(value));};
  try{
   if(req.url==='/health'&&req.method==='GET')return send(200,{ok:true});
   const token=(req.headers.authorization??'').replace(/^Bearer /,'');
   if(!timingSafeEqual(Buffer.from(hash(token)),Buffer.from(hash(appToken))))return send(401,{error:'인증 코드를 확인해 주세요.'});
   const owner=hash(token);const id=req.url?.match(/^\/v1\/requests\/([a-f0-9-]{36})$/)?.[1];
   if(req.url==='/v1/config'&&req.method==='GET')return send(200,{ready:!!apiKey,model});
   if(req.url==='/v1/requests'&&req.method==='POST'){
    const now=Date.now();
    const count=db.prepare('SELECT COUNT(*) AS n FROM requests WHERE owner=? AND created>?').get(owner,now-86400000).n;
    if(count>=50)return send(429,{error:'테스트 서버의 하루 요청 한도(50회)에 도달했어요.'});
    const requestId=randomUUID();db.prepare('INSERT INTO requests VALUES(?,?,?,?,?,?,?)').run(requestId,owner,'created',now,now,null,null);
    return send(201,payload(get(requestId)));
   }
   const row=id?get(id):null;
   if(!row||row.owner!==owner)return send(404,{error:'요청을 찾을 수 없어요.'});
   if(req.method==='GET')return send(200,payload(row));
   if(req.method!=='POST')return send(405,{error:'지원하지 않는 요청이에요.'});
   const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>24000)return send(413,{error:'질문이 너무 길어요.'});chunks.push(chunk);}const raw=Buffer.concat(chunks).toString('utf8');
   let body;try{body=JSON.parse(raw)}catch{return send(400,{error:'질문 형식을 확인해 주세요.'})}
   const prompt=body?.prompt;
   if(typeof prompt!=='string'||!prompt.trim()||prompt.length>5000)return send(400,{error:'질문을 1~5,000자로 입력해 주세요.'});
   const fingerprint=hash(prompt);
   // Re-read after consuming the body: concurrent submissions may have already claimed it.
   const current=get(id);
   if(current.fingerprint&&current.fingerprint!==fingerprint)return send(409,{error:'같은 요청에 다른 질문을 보낼 수 없어요.'});
   if(current.state!=='created')return send(200,payload(current));
   if(!apiKey)return send(503,{error:'서버에 OpenAI API 키를 설정해야 해요.'});
   db.prepare("UPDATE requests SET state='processing',fingerprint=?,updated=? WHERE id=?").run(fingerprint,Date.now(),id);
   try{
    const upstream=await fetchApi('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},body:JSON.stringify({model,input:prompt,max_output_tokens:1024,store:false}),signal:AbortSignal.timeout(timeoutMs)});
    if(!upstream.ok){update(id,upstream.status>=500?'unknown':'failed');return send(200,payload(get(id)));}
    const data=await upstream.json();
    if(!data.id||data.status!=='completed'){update(id,'unknown');return send(200,payload(get(id)));}
    const answer=(data.output??[]).flatMap(o=>o.content??[]).filter(c=>c.type==='output_text'||c.type==='refusal').map(c=>c.text??c.refusal??'').join('\n');
    const u=data.usage;const valid=u&&[u.input_tokens,u.output_tokens,u.total_tokens].every(n=>Number.isSafeInteger(n)&&n>=0);
    const receipt={provider:'OpenAI API',model:data.model??model,responseId:data.id,completedAt:Date.now(),usage:valid?{inputTokens:u.input_tokens,outputTokens:u.output_tokens,totalTokens:u.total_tokens}:null};
    update(id,'completed',receipt);answers.set(id,answer);if(answers.size>50)answers.delete(answers.keys().next().value);const expiry=setTimeout(()=>{answers.delete(id);expiryTimers.delete(expiry)},600000);expiry.unref();expiryTimers.add(expiry);
    return send(200,payload(get(id)));
   }catch{update(id,'unknown');return send(200,payload(get(id)));}
  }catch{if(!res.headersSent)send(500,{error:'서버 처리 중 오류가 발생했어요. 요청 상태를 확인해 주세요.'});else res.end();}
 });
 server.requestTimeout=15000;server.headersTimeout=10000;
 return {server,close:()=>{for(const timer of expiryTimers)clearTimeout(timer);server.close();db.close()}};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const {server}=createApi({dbPath:process.env.REQUEST_DB_PATH??'requests.sqlite',apiKey:process.env.OPENAI_API_KEY,appToken:process.env.APP_API_TOKEN,model:process.env.OPENAI_MODEL??'gpt-4.1-mini'});
 server.listen(Number(process.env.PORT??8787),'0.0.0.0',()=>console.log('AI API server listening'));
}
