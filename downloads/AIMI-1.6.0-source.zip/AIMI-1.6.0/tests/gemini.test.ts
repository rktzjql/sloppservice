import test from 'node:test';
import assert from 'node:assert/strict';
import { checkKey, checkModel, GeminiConnectionError, httpError, improveWithGemini, listGeminiModels, parseImprovement, parseRecommendation, recommendWithGemini } from '../src/studio/gemini';

const config = { apiKey: 'AIza_FAKE_TEST_KEY_ONLY_00000000000000', model: 'gemini-3.5-flash-lite' };
const recommendation = { tier: 'Light', task: '발표 아이디어', reason: '방법 3가지를 제안하는 짧은 작업이므로 가벼운 모델을 추천해요.', modelIds: ['gpt-6-luna', 'gemini-3.5-flash-lite'] };
const improvement = { improved: '학교 발표에 사용할 재활용 방법 3개를 제안해 주세요.', expanded: '초등학생을 대상으로 학교 발표에 사용할 재활용 방법 3개를 제안해 주세요.', explanation: '발표 목적과 개수를 유지하고 요청을 분명히 했어요.', tips: [{ phrase: '초등학생', title: '설명 대상', explanation: '추가한 대상 예시이므로 내 상황에 맞게 바꾸세요.' }], recommendation };
function completed(value: unknown, finishReason = 'STOP') { return new Response(JSON.stringify({ candidates: [{ finishReason, content: { parts: [{ text: JSON.stringify(value) }] } }] })); }

test('key input accepts opaque punctuation and long credentials without truncation', () => {
  const opaque = 'AQ.test/+==' + 'x'.repeat(600);
  assert.equal(checkKey(opaque), opaque);
  assert.equal(checkKey(` \n“\u2066${opaque}\u2069”\u200B \n`), opaque);
  assert.equal(checkKey(`export GEMINI_API_KEY="${opaque}";`), opaque);
  assert.equal(checkKey(`GOOGLE_API_KEY='${opaque}'`), opaque);
  assert.equal(checkKey('abc.def/+='), 'abc.def/+=');
});
test('unsafe headers and incorrect paste types fail before network without revealing input', async () => {
  let calls = 0;
  for (const input of ['', '••••••', '<YOUR_API_KEY>', 'https://example.invalid/private-key', 'secret\r\nInjected: value', '키입니다', 'x'.repeat(4097)]) {
    await assert.rejects(() => listGeminiModels(input, { fetcher: async () => { calls++; return new Response('{}'); } }), error => {
      assert.ok(error instanceof GeminiConnectionError); assert.equal(error.stage, 'input');
      assert.match(error.message, /아직 전송하지/); assert.ok(!error.message.includes('private-key')); return true;
    });
  }
  assert.equal(calls, 0);
});
test('normalized keys reach Google unchanged in the header', async () => {
  const opaque = 'AQ.test/+==' + 'q'.repeat(400);
  const fetcher: typeof fetch = async (url, options) => {
    assert.equal((options?.headers as Record<string, string>)['x-goog-api-key'], opaque);
    assert.ok(!String(url).includes(opaque));
    return new Response(JSON.stringify({ models: [{ name: 'models/gemini-3.5-flash-lite', supportedGenerationMethods: ['generateContent'] }] }));
  };
  assert.equal((await listGeminiModels(`“${opaque}”`, { fetcher })).length, 1);
});
test('provider errors distinguish key validity and restrictions without echoing raw text', async () => {
  const secret = 'DO_NOT_ECHO_SECRET';
  const failure = httpError(403, { error: { message: secret, details: [{ reason: 'API_KEY_HTTP_REFERRER_BLOCKED', metadata: { secret } }] } });
  assert.equal(failure.stage, 'google'); assert.equal(failure.httpStatus, 403);
  assert.match(failure.message, /웹사이트 주소 제한/); assert.ok(!failure.message.includes(secret));
  const leaked = httpError(403, { error: { message: `Your API key was reported as leaked ${secret}` } });
  assert.equal(leaked.code, 'KEY_REPORTED_LEAKED'); assert.ok(!leaked.message.includes(secret));
  await assert.rejects(() => listGeminiModels(config.apiKey, { fetcher: async () => new Response(JSON.stringify({ error: { details: [{ reason: 'API_KEY_INVALID' }], message: secret } }), { status: 400 }) }), error => {
    assert.ok(error instanceof GeminiConnectionError); assert.equal(error.code, 'API_KEY_INVALID');
    assert.match(error.message, /Google HTTP 400/); assert.ok(!error.message.includes(secret)); return true;
  });
});

test('model list uses header auth, follows pagination and excludes non-text endpoints', async () => {
  const calls: string[] = [];
  const fetcher: typeof fetch = async (url, options) => {
    calls.push(String(url)); assert.ok(!String(url).includes(config.apiKey));
    assert.equal((options?.headers as Record<string, string>)['x-goog-api-key'], config.apiKey);
    return new Response(JSON.stringify(calls.length === 1 ? {
      models: [{ name: 'models/gemini-2.5-pro', supportedGenerationMethods: ['generateContent'] }, { name: 'models/gemini-tts', supportedGenerationMethods: ['generateContent'] }], nextPageToken: 'next/one',
    } : { models: [{ name: 'models/gemini-3.5-flash-lite', displayName: 'Flash Lite', supportedGenerationMethods: ['generateContent'] }] }));
  };
  const result = await listGeminiModels(config.apiKey, { fetcher });
  assert.equal(calls.length, 2); assert.match(calls[1], /pageToken=next%2Fone/);
  assert.deepEqual(result.map(item => item.name), ['gemini-3.5-flash-lite', 'gemini-2.5-pro']);
  assert.throws(() => checkModel('https://evil.invalid/?key='));
});
test('improvement comes from the structured Gemini response with exact original and candidate IDs', async () => {
  let count = 0;
  const result = await improveWithGemini(config, '학교 발표용 재활용 방법 3개 추천좀', { fetcher: async (url, options) => {
    count++; assert.match(String(url), /^https:\/\/generativelanguage.googleapis.com\/v1beta\/models\/gemini-3.5-flash-lite:generateContent$/);
    const body = JSON.parse(String(options?.body));
    assert.equal(body.generationConfig.responseMimeType, 'application/json');
    assert.equal(body.generationConfig.responseSchema.type, 'OBJECT');
    assert.equal(JSON.parse(body.contents[0].parts[0].text).userPrompt, '학교 발표용 재활용 방법 3개 추천좀');
    assert.ok(!String(options?.body).includes(config.apiKey));
    return completed(improvement);
  } });
  assert.equal(count, 1); assert.equal(result.improved, improvement.improved);
  assert.equal(result.original, '학교 발표용 재활용 방법 3개 추천좀');
  assert.deepEqual(result.recommendation.modelIds, recommendation.modelIds);
});
test('AI recommendation does not use the old keyword classifier', async () => {
  const high = { tier: 'High', task: '검증', reason: 'AI가 실제 요청을 분석한 테스트 응답입니다.', modelIds: ['gemini-4-argon'] };
  const result = await recommendWithGemini(config, '안녕', { fetcher: async () => completed(high) });
  assert.equal(result.tier, 'High'); assert.equal(result.reason, high.reason);
});
test('malformed output, unknown models, wrong tiers and removed numbers fail closed', () => {
  assert.throws(() => parseRecommendation({ ...recommendation, modelIds: ['invented'] }));
  assert.throws(() => parseRecommendation({ ...recommendation, modelIds: ['gemini-4-argon'] }));
  assert.throws(() => parseRecommendation({ ...recommendation, reason: '' }));
  assert.throws(() => parseImprovement({ ...improvement, improved: '방법 5개' }, '방법 3개'), /숫자/);
  assert.throws(() => parseImprovement({ ...improvement, tips: [{ phrase: '없는 구절', title: '대상', explanation: '설명' }] }, '방법 3개'));
});
test('quota errors do not retry, switch models, disclose upstream body or return local results', async () => {
  let calls = 0;
  await assert.rejects(() => recommendWithGemini(config, '요약해줘', { fetcher: async () => { calls++; return new Response(`private text ${config.apiKey}`, { status: 429 }); } }), error => {
    assert.ok(error instanceof Error); assert.match(error.message, /한도/); assert.ok(!error.message.includes(config.apiKey)); return true;
  });
  assert.equal(calls, 1);
});
test('truncated, blocked and non-JSON results never become successful AI results', async () => {
  await assert.rejects(() => recommendWithGemini(config, '요약', { fetcher: async () => completed(recommendation, 'MAX_TOKENS') }), /완성/);
  await assert.rejects(() => recommendWithGemini(config, '요약', { fetcher: async () => new Response(JSON.stringify({ promptFeedback: { blockReason: 'SAFETY' } })) }), /제한/);
  await assert.rejects(() => recommendWithGemini(config, '요약', { fetcher: async () => new Response('not-json') }), /형식/);
});
test('timeout cancels the request and never retries', async () => {
  let calls = 0;
  await assert.rejects(() => recommendWithGemini(config, '요약', { timeoutMs: 10, fetcher: async (_url, options) => {
    calls++; return new Promise((_resolve, reject) => options!.signal!.addEventListener('abort', () => reject(new Error('aborted'))));
  } }), /대기 시간/);
  assert.equal(calls, 1);
});

test('updated catalog reaches both recommendation schema and prompt with useful model notes', async () => {
  for (const [tier, id] of [['Medium', 'claude-sonnet-5-5'], ['High', 'gemini-4-argon']] as const) {
    const expected = { tier, modelIds: [id], task: '문서 분석', reason: '복잡한 조건을 검토하는 작업에 적합한 후보입니다.' };
    const result = await recommendWithGemini(config, '긴 문서의 상충하는 조건을 검토해줘', { fetcher: async (_url, options) => {
      const body = JSON.parse(String(options?.body));
      const { candidates } = JSON.parse(body.contents[0].parts[0].text);
      const ids = body.generationConfig.responseSchema.properties.modelIds.items.enum;
      assert.ok(candidates.some((m: any) => m.id === id && m.tier === tier && m.useCase));
      assert.ok(ids.includes(id));
      for (const retired of ['gemini-pro', 'o3', 'claude-sonnet', 'gpt-4-1']) {
        assert.ok(!ids.includes(retired)); assert.ok(!candidates.some((m: any) => m.id === retired));
      }
      return completed(expected);
    } });
    assert.deepEqual(result, expected);
  }
  assert.throws(() => parseRecommendation({tier: 'High', task: '검증', reason: '구버전 모델', modelIds: ['gemini-pro']}));
});
