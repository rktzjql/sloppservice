import {test} from 'node:test';
import assert from 'node:assert/strict';
import {claim,freshProgress,parseProgress,practice,purchase} from '../src/prototype/state.ts';
import {makeExample,modelLesson,buildPrompt,reviewPassed} from '../src/prototype/lesson.ts';
test('조건은 선택 사항이며 원문을 보존하고 선택한 조건의 이유만 설명한다',()=>{
 const result=buildPrompt('  환경보호 활동 알려줘.  ',{purpose:' 동아리 활동 ',constraints:'',format:'활동 3개'});
 assert.equal(result.original,'환경보호 활동 알려줘.');
 assert.equal(result.additions.length,2);
 assert.equal(result.additions[0].key,'purpose');
 assert.equal(result.suggestion,'환경보호 활동 알려줘.\n\n목적: 동아리 활동\n\n답변 형식·범위: 활동 3개');
 assert.equal(buildPrompt('원문',{purpose:'',constraints:' ',format:''}).suggestion,'원문');
 assert.throws(()=>buildPrompt('',{purpose:'',constraints:'',format:''}));
 assert.throws(()=>buildPrompt('질문',{purpose:'가'.repeat(201),constraints:'',format:''}));
});
test('복습은 도움이 되는 서로 다른 조건 두 개를 선택해야 통과한다',()=>{
 assert.equal(reviewPassed(['budget','format']),true);
 for(const answer of [[],['budget'],['budget','repeat'],['budget','format','long'],['budget','budget'],['unknown','format']])assert.equal(reviewPassed(answer),false);
});
test('같은 날 보상 중복 지급을 막고 다음 날은 새 보상을 준다',()=>{
 const s=claim(freshProgress(),'2026-11-06','attendance');
 assert.equal(s.ep,5);assert.strictEqual(claim(s,'2026-11-06','attendance'),s);
 const next=claim(s,'2026-11-07','attendance');assert.equal(next.ep,10);assert.equal(next.ledger.length,2);
});
test('연습은 하루 5회이며 최초 보상만 지급하고 재실행에도 보존한다',()=>{
 let s=freshProgress();for(let i=0;i<5;i++)s=practice(s,'2026-11-06');
 assert.equal(s.ep,5);assert.equal(s.practice['2026-11-06'],5);
 s=parseProgress(JSON.stringify(s));assert.throws(()=>practice(s,'2026-11-06'));
 assert.equal(practice(s,'2026-11-07').ep,10);
});
test('잔액 부족 구매는 거부하고 중복 구매는 EP를 차감하지 않는다',()=>{
 assert.throws(()=>purchase(freshProgress(),'2026-11-06','blue-pot'));
 let s=freshProgress();for(let i=1;i<=8;i++)s=claim(s,`2026-11-${String(i).padStart(2,'0')}`,'attendance');
 s=purchase(s,'2026-11-08','blue-pot');assert.equal(s.ep,0);assert.deepEqual(s.owned,['blue-pot']);
 assert.strictEqual(purchase(s,'2026-11-08','blue-pot'),s);
 assert.equal(s.ledger.reduce((sum,r)=>sum+r.delta,0),s.ep);
});
test('손상된 학습 저장값을 정상 초기 상태로 오인하지 않는다',()=>{
 assert.deepEqual(parseProgress(null),freshProgress());
 for(const raw of ['{}','null','invalid',JSON.stringify({...freshProgress(),ep:-1}),JSON.stringify({...freshProgress(),practice:{today:6}}),JSON.stringify({...freshProgress(),equipped:'fence'})])assert.throws(()=>parseProgress(raw));
});
test('개선 예시는 원문을 보존하고 사용자가 선택한 조건만 덧붙인다',()=>{
 const input='대학생 환경보호 아이디어 3개를 알려줘.';
 const r=makeExample(input,'steps','short');assert.equal(r.original,input);assert.ok(r.suggestion.startsWith(input));
 assert.match(r.suggestion,/단계/);assert.match(r.suggestion,/한 문장/);
 assert.equal(makeExample(input,'keep','normal').suggestion,input);
 assert.throws(()=>makeExample(' ','list','short'));assert.throws(()=>makeExample('가'.repeat(1001),'list','short'));
});
test('모델 학습은 명시적으로 선택한 작업 유형에 따라 설명한다',()=>{
 assert.match(modelLesson('simple').tier,/경량/);assert.match(modelLesson('reasoning').tier,/고성능/);
 assert.match(modelLesson('verification').tier,/출처/);
});
