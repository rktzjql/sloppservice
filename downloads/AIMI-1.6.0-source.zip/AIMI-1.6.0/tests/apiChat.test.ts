import {test} from 'node:test';
import assert from 'node:assert/strict';
import {apiSummary,mergeRequest,serverUrl,validRequest,type ApiRequest} from '../src/apiChat.ts';
const done:ApiRequest={id:'test',state:'completed',createdAt:1,updatedAt:2,answer:'답변 원문',receipt:{provider:'OpenAI API',model:'test',responseId:'resp_1',completedAt:2,usage:{inputTokens:2,outputTokens:3,totalTokens:5}}};
test('성공 응답만 집계하며 답변 원문을 기기에 저장하지 않는다',()=>{let rows=mergeRequest([],done);rows=mergeRequest(rows,done);assert.equal(rows.length,1);assert.equal(rows[0].answer,null);rows=mergeRequest(rows,{...done,id:'pending',state:'unknown',receipt:null});assert.deepEqual(apiSummary(rows),{completed:1,tokens:5,usageMissing:0});});
test('완료 응답의 사용량이 없으면 0 토큰 관측값으로 취급하지 않는다',()=>{assert.equal(apiSummary([{...done,receipt:{...done.receipt!,usage:null}}]).usageMissing,1);assert.equal(validRequest({...done,receipt:null}),false);});
test('서버 주소는 인증정보 없는 HTTPS origin만 받는다',()=>{assert.equal(serverUrl('https://example.com/'),'https://example.com');for(const url of ['http://example.com','https://secret@example.com','https://example.com/?key=secret','https://example.com/api'])assert.throws(()=>serverUrl(url));});
