import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sessionsFromEvents, type UsageEvent} from '../src/sessions.ts';
const event=(timestamp:number,kind:UsageEvent['kind'],packageName='com.openai.chatgpt'):UsageEvent=>({timestamp,kind,packageName});
test('정렬되지 않은 이벤트에서 완료된 세션만 복원',()=>{
 const result=sessionsFromEvents([event(300,'pause'),event(100,'resume'),event(400,'resume')],0);
 assert.equal(result.length,1);assert.equal(result[0].endedAt-result[0].startedAt,200);
});
test('중복 resume은 시작 시간을 덮어쓰지 않음',()=>assert.equal(sessionsFromEvents([event(100,'resume'),event(200,'resume'),event(300,'pause')],0)[0].startedAt,100));
test('잠금 화면에서 세션 종료',()=>assert.equal(sessionsFromEvents([event(100,'resume'),event(200,'stop','')],0)[0].endedAt,200));
test('동의 이전 및 다른 앱 이벤트 제외',()=>assert.deepEqual(sessionsFromEvents([event(100,'resume'),event(300,'pause'),event(400,'resume','other'),event(500,'pause','other')],200),[]));
test('반복 조회 시 동일한 세션 ID',()=>{const events=[event(100,'resume'),event(200,'pause')];assert.deepEqual(sessionsFromEvents(events,0),sessionsFromEvents(events,0));});
test('같은 앱 내부의 짧은 화면 전환은 한 세션으로 묶음',()=>{
 const sessions=sessionsFromEvents([event(100,'resume'),event(200,'pause'),event(300,'resume'),event(500,'pause')],0);
 assert.equal(sessions.length,1);assert.equal(sessions[0].startedAt,100);assert.equal(sessions[0].endedAt,500);
});
test('충분히 떨어진 재방문은 별도 세션',()=>assert.equal(sessionsFromEvents([event(100,'resume'),event(200,'pause'),event(3000,'resume'),event(4000,'pause')],0).length,2));
test('화면 잠금 전후 세션은 합치지 않음',()=>assert.equal(sessionsFromEvents([event(100,'resume'),event(200,'stop',''),event(300,'resume'),event(500,'pause')],0).length,2));
