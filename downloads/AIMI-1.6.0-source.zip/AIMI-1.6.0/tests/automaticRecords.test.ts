import {test} from 'node:test';
import assert from 'node:assert/strict';
import {automaticRecords} from '../src/automaticRecords.ts';
import {summarize} from '../src/records.ts';
const send={id:'one',provider:'ChatGPT' as const,createdAt:1700000000000};
test('자동 클릭은 별도 입력 없이 1회 기록으로 변환하며 재조회 중복을 방지',()=>{
 const records=automaticRecords([send,send],false);
 assert.equal(records.length,1);assert.equal(records[0].count,1);assert.equal(records[0].source,'automatic-send');
 assert.equal(summarize(records).count,1);assert.equal(summarize(records).energy,null);
});
test('텍스트 가정은 명시적으로 켰을 때만 자동 기록 에너지에 적용',()=>{
 assert.equal(summarize(automaticRecords([send],true)).energy,0.34);
 assert.equal(summarize(automaticRecords([{...send,provider:'Gemini'}],true)).energy,0.24);
});
test('자동 기록의 안정된 ID와 시각은 재조회해도 유지',()=>{
 assert.deepEqual(automaticRecords([send],false),automaticRecords([send],false));
 assert.equal(automaticRecords([send],false)[0].createdAt,new Date(send.createdAt).toISOString());
});
test('클릭과 버튼 상태 추정의 출처를 보존하고 오래된 기록은 클릭으로 유지',()=>{
 const rows=automaticRecords([send,{...send,id:'two',detection:'button-transition'}],true);
 assert.equal(rows[0].detection,'click');assert.equal(rows[1].detection,'button-transition');
 assert.equal(summarize(rows).count,2);assert.equal(summarize(rows).energy,0.68);
});
test('잘못된 시각 한 개가 전체 자동 영수증을 중단하지 않는다',()=>{
 assert.equal(automaticRecords([send,{...send,id:'bad',createdAt:1e30}],true).length,1);
});
test('입력 신호 추정 기록을 클릭으로 바꾸지 않고 보존한다',()=>{
 const rows=automaticRecords([{id:'input-signal',provider:'ChatGPT',createdAt:1793965502035,detection:'input-transition'}],true);
 assert.equal(rows[0].detection,'input-transition');
});
