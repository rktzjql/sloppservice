import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseReminder} from '../src/reminder.ts';
test('알림 링크는 지원 앱과 유효한 시각만 허용',()=>{
 assert.deepEqual(parseReminder('slopstop://record?package=com.openai.chatgpt&start=100&end=200'),{sessionId:'com.openai.chatgpt:100',start:100,end:200});
 for(const url of ['https://record?package=com.openai.chatgpt&start=100&end=200','slopstop://record?package=other&start=100&end=200','slopstop://record?package=com.openai.chatgpt&start=200&end=100','slopstop://record','invalid'])assert.equal(parseReminder(url),null);
});
