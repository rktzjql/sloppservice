import test from 'node:test';
import assert from 'node:assert/strict';
import { expandPrompt, improveLocally, MAX_PROMPT, recommend, SCHOOL_EXAMPLE } from '../src/studio/logic';
import { findModels, pricePer100 } from '../src/studio/catalog';

test('free rewriting handles unseen requests and protects quantities, negatives and source text', () => {
  for (const input of ['여행 추천좀', '이 내용 요약해줘', '생일 축하 문구 써줘', '자기소개서 작성좀', '환경보호']) {
    const result = improveLocally(input);
    assert.notEqual(result.improved, input, input);
    assert.ok(result.changes.length > 0);
    assert.equal(result.mode, 'local');
  }
  const constrained = improveLocally('예산 5만원, 대학생 4명. 카페는 제외하고 서울 여행지 3곳 추천좀');
  for (const token of ['5만원', '4명', '카페는 제외', '3곳']) assert.ok(constrained.improved.includes(token));
  assert.match(constrained.improved, /3곳을 추천해 주세요/);
  const quoted = improveLocally('“추천좀”을 영어로 번역해줘');
  assert.ok(quoted.improved.includes('“추천좀”'));
  assert.match(quoted.improved, /번역해 주세요/);
  const code = '다음 코드를 검토해줘.\n\ndef run():\n    return "a  b"';
  assert.equal(improveLocally(code).improved, code);
  assert.equal(improveLocally('재활용 방법 3개를 알려 주세요.').improved, '재활용 방법 3개를 알려 주세요.');
  assert.match(improveLocally(SCHOOL_EXAMPLE).improved, /학교 발표에 사용할/);
  assert.match(improveLocally(SCHOOL_EXAMPLE).improved, /3개를 추천해 주세요/);
  assert.equal(improveLocally('대학생에게 설명할 내용을 표로 정리해줘').audience, '');
  assert.equal(improveLocally('대학생에게 설명할 내용을 표로 정리해줘').format, '');
});
test('condition examples are optional and do not silently modify the base text', () => {
  const base = '여행 계획을 표로 정리해줘.';
  assert.equal(expandPrompt(base, '', ''), base);
  assert.equal(expandPrompt(base, '대학생', ''), `${base}\n설명 대상은 대학생입니다.`);
  assert.equal(expandPrompt(base, '', '준비물 목록'), `${base}\n준비물 목록`);
});
test('blank and over-limit inputs cannot be classified or improved', () => {
  for (const fn of [recommend, improveLocally]) {
    assert.throws(() => fn(' \n '));
    assert.throws(() => fn('가'.repeat(MAX_PROMPT + 1)));
  }
});
test('recommendation handles simple, compound and reasoning tasks without length-only High', () => {
  assert.equal(recommend('쉬운 말로 세 문장으로 요약해줘.').tier, 'Light');
  assert.equal(recommend('두 제품의 장단점을 비교 분석해줘.').tier, 'Medium');
  assert.equal(recommend('교착 상태를 방지하는 분산 시스템 아키텍처를 설계해줘.').tier, 'High');
  assert.equal(recommend('요약해줘. ' + '자료 '.repeat(700)).tier, 'Medium');
  assert.equal(recommend('오늘 뉴스의 출처를 알려줘.').needsSource, true);
  assert.equal(recommend('사진을 분석해줘.').needsImage, true);
});
test('catalog filters both provider and name, and pricing converts million to 100 tokens', () => {
  assert.equal(findModels('Light', ' OPENAI ').length, 1);
  assert.equal(findModels('Light', 'gemini')[0].provider, 'Google');
  assert.equal(findModels('High', 'no such model').length, 0);
  assert.equal(pricePer100(.1), '$0.00001');
  assert.equal(pricePer100(.4), '$0.00004');
});

test('everyday prompts no longer default to Medium, and task matters more than topic', () => {
  for (const prompt of ['안녕', '저녁 뭐 먹지?', '생일 축하 문구 써줘', '강아지 이름 골라줘', '광합성이 뭐야?', '아키텍처가 무슨 뜻이야?', '분산 시스템을 쉽게 설명해줘']) assert.equal(recommend(prompt).tier, 'Light', prompt);
  for (const prompt of ['두 제품의 장단점을 비교해줘', '파이썬 함수를 작성해줘', '예산 10만원 이내로 2박 3일 여행 계획을 짜줘']) assert.equal(recommend(prompt).tier, 'Medium', prompt);
  for (const prompt of ['이 정리를 수학적 귀납법으로 증명해줘', '분산 시스템의 동시성 문제를 해결하도록 설계해줘', '상충하는 조건을 분석하고 최적화해줘']) assert.equal(recommend(prompt).tier, 'High', prompt);
  assert.equal(recommend(expandPrompt(improveLocally('여행 추천좀').improved, '처음 여행하는 사람', '항목별로 정리해 주세요.')).tier, 'Light');
});

test('catalog has distinct candidates, official sources and Argon search aliases across balanced tiers', () => {
  const all = ['Light', 'Medium', 'High'].flatMap(tier => findModels(tier as 'Light' | 'Medium' | 'High', ''));
  assert.equal(new Set(all.map(m => m.id)).size, all.length);
  for (const tier of ['Medium', 'High'] as const) {
    const models = findModels(tier, '');
    assert.ok(models.length >= 6); assert.ok(new Set(models.map(m => m.provider)).size >= 4);
  }
  for (const model of all) {
    assert.ok(['firebase.google.com', 'developers.openai.com', 'platform.claude.com', 'docs.mistral.ai', 'api-docs.deepseek.com'].includes(new URL(model.source).hostname));
    assert.ok(model.note.length > 0);
  }
  assert.equal(findModels('High', '아르곤')[0].id, 'gemini-4-argon');
  assert.equal(findModels('High', ' ARGON ')[0].id, 'gemini-4-argon');
  assert.equal(findModels('High', '2.5 Pro').length, 0);
});
