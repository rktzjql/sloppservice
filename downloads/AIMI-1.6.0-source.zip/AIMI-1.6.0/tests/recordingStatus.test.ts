import {test} from 'node:test';
import assert from 'node:assert/strict';
import {recordingStatus,signalHint} from '../src/recordingStatus.ts';
import type {ExperimentStatus} from '../modules/ai-usage';
const connected: ExperimentStatus={connected:true,enabled:true,storageError:false,consent:true,active:true,sendCount:0,chatgptCount:0,geminiCount:0,seenClicks:0,lastMatch:'none',checkedAt:0,receivedEvents:0,changeEvents:0,lastProvider:'none',buttonState:'waiting',eventAt:0};
test('연결만 된 상태를 기록 성공으로 표시하지 않는다',()=>{
 assert.equal(recordingStatus(connected),'연결됨 · 전송 감지 대기');
 assert.match(signalHint(connected),/아직 AI 앱 신호를 받지 못/);
 assert.match(recordingStatus({...connected,sendCount:1}),/전송 감지됨/);
});
test('권한·일시 중지·저장 오류 상태는 과거 성공보다 우선한다',()=>{
 assert.equal(recordingStatus({...connected,sendCount:5,storageError:true}),'저장 오류 · 감지 중지');
 assert.equal(recordingStatus({...connected,sendCount:5,enabled:false}),'자동 기록 꺼짐');
 assert.equal(recordingStatus({...connected,connected:false}),'접근성 연결 필요');
});
test('신호 미수신과 버튼 정보 미노출을 구분한다',()=>{
 assert.match(signalHint({...connected,receivedEvents:2,buttonState:'no_controls'}),/식별하지 못/);
 assert.match(signalHint({...connected,receivedEvents:2,buttonState:'unavailable'}),/접근하지 못/);
});
test('접근성 설정은 켜졌어도 서비스가 끊기면 과거 신호보다 복구 안내를 우선한다',()=>{
 const disconnected={...connected,active:false,connected:false,accessibilityEnabled:true,receivedEvents:886,buttonState:'bounded' as const};
 assert.equal(recordingStatus(disconnected),'접근성 켜짐 · 서비스 연결 끊김');
 assert.match(signalHint(disconnected),/현재 서비스가 연결되지 않아/);
});
