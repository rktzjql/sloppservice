import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validCount, summarize, todayRecords, parseRecords, type UsageRecord } from '../src/records.ts';
const r = (kind: UsageRecord['kind'], count: number, createdAt = new Date(2026, 10, 4, 12).toISOString()): UsageRecord => ({ id: `${kind}-${createdAt}`, createdAt, provider: 'ChatGPT', kind, count, source: 'manual' });
test('입력 횟수는 1~999 사이 정수만 허용', () => {
  for (const value of ['0', '-1', '1.5', '1e2', '', '1000', 'abc']) assert.equal(validCount(value), null);
  assert.equal(validCount(' 12 '),12);
});
test('공개 기준이 있는 일반 텍스트만 합계에 포함하고 나머지는 누락 수를 표시', () => {
  const result=summarize([r('text',4),{...r('text',2),provider:'Gemini'},r('light',3),r('image',1),r('retry',3)]);
  assert.ok(Math.abs(result.energy!-1.84)<1e-9);
  assert.equal(result.count,13);assert.equal(result.estimatedCount,6);assert.equal(result.unknownCount,7);assert.equal(result.retryCount,3);
});
test('알 수 없는 에너지를 0으로 표현하지 않음',()=>{
 assert.equal(summarize([r('image',1)]).energy,null);
 assert.equal(summarize([{...r('text',1),provider:'Claude'}]).unknownCount,1);
});
test('기기 현지 날짜 기준으로 자정을 구분', () => {
  const before=r('text',1,new Date(2026,10,3,23,59).toISOString());
  const after=r('text',1,new Date(2026,10,4,0,0).toISOString());
  assert.deepEqual(todayRecords([before,after],new Date(2026,10,4,12)),[after]);
});
test('저장 데이터 복원 및 손상 데이터 거부', () => {
  assert.deepEqual(parseRecords(JSON.stringify([r('text',2)])),[r('text',2)]);
  assert.deepEqual(parseRecords(null),[]);
  assert.throws(()=>parseRecords('[{"kind":"invalid"}]'));
  assert.throws(()=>parseRecords('broken'));
});
test('빈 영수증은 0',()=>assert.deepEqual(summarize([]),{energy:0,estimatedCount:0,unknownCount:0,count:0,retryCount:0}));
test('자동 감지 후 확인한 기록은 출처와 세션 식별자를 보존',()=>{
 const record={...r('text',2),source:'usage-confirmed',sessionId:'com.openai.chatgpt:123'};
 assert.deepEqual(parseRecords(JSON.stringify([record])),[record]);
 assert.throws(()=>parseRecords(JSON.stringify([{...record,sessionId:undefined}])));
});
