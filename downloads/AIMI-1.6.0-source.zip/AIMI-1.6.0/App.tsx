import React, { useEffect, useState } from 'react';
import { BackHandler, Pressable, ScrollView, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import ReceiptApp from './ReceiptApp';
import AiUsage from './modules/ai-usage';
import { useUI, Card, Button } from './src/prototype/ui';
import PromptStudio from './src/studio/PromptStudio';
import PlanSurface from './src/studio/PlanSurface';
import {ThemeProvider,useTheme} from './src/theme/Theme';
import PlanHome from './src/studio/PlanHome';

type Tab = 'home' | 'receipt' | 'my';
type Route = 'main' | 'legacy' | 'studio' | 'models';
export default function App() { return <ThemeProvider><SafeAreaProvider><Application /></SafeAreaProvider></ThemeProvider>; }
function Application() {
  const {C,S}=useUI(); const theme=useTheme();
  const [tab, setTab] = useState<Tab>('home');
  const [route, setRoute] = useState<Route>('main');
  const [legacyWarning, setLegacyWarning] = useState('');
  useEffect(() => {
    if (!AiUsage) return;
    void (async () => {
      try { await AiUsage.stopMonitoring(); await AiUsage.clearReminders(); }
      catch { setLegacyWarning('이전 사용 시간 알림을 끄지 못했어요. 기존 기록 설정을 확인해 주세요.'); }
    })();
  }, []);
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (route === 'studio' || route === 'models') return false;
      if (route !== 'main') { setRoute('main'); return true; }
      if (tab !== 'home') { setTab('home'); return true; }
      return false;
    });
    return () => sub.remove();
  }, [route, tab]);

  if (route === 'legacy') return <ReceiptApp onClose={() => setRoute('main')} />;
  if (route === 'studio' || route === 'models') return <PromptStudio initialScreen={route === 'models' ? 'models' : 'input'} onExit={() => setRoute('main')} />;
  return <PlanSurface><SafeAreaView style={[S.screen, { backgroundColor: 'transparent' }]}>
    <StatusBar style={theme.isDark?"light":"dark"} />
    <View style={S.header}><Text style={S.brand}>AIMI</Text><Pressable accessibilityRole="button" accessibilityLabel="테마 전환" onPress={()=>theme.setMode(theme.isDark?'light':'night')} style={[S.pill,{backgroundColor:C.secondary,borderWidth:1,borderColor:C.line}]}><Text style={S.pillText}>{theme.isDark?'☀ Light':'☾ Night Glass'}</Text></Pressable></View>
    <ScrollView key={tab} contentContainerStyle={S.content}>
      {tab === 'home' && <PlanHome onImprove={() => setRoute('studio')} onModels={() => setRoute('models')} />}
      {tab === 'receipt' && <>
        <Text style={S.label}>AI USAGE RECEIPT</Text><Text style={S.h1}>AI 사용 영수증</Text>
        <Card><Text style={S.h2}>추후 개발 예정</Text><Text style={S.body}>AI 사용 기록을 돌아볼 수 있는 영수증을 준비하고 있어요. 지금은 프롬프트 개선과 모델 추천을 먼저 이용해 보세요.</Text></Card>
        <Card><Text style={S.h2}>기존 기록과 설정</Text><Text style={S.body}>이전에 저장한 영수증 기록과 Android 자동 기록 설정을 확인할 수 있어요.</Text>
          {!!legacyWarning && <Text style={S.error}>{legacyWarning}</Text>}
          <Button title="기존 영수증·Android 자동 기록 설정" secondary onPress={() => setRoute('legacy')} />
          <Text style={S.small}>자동 감지는 실기기 검증 중이에요. 프롬프트 개선·모델 추천의 사용량은 아직 영수증에 자동 연결되지 않아요.</Text>
        </Card>
      </>}
      {tab === 'my' && <>
        <Text style={S.label}>ABOUT AIMI</Text><Text style={S.h1}>앱 안내</Text>
        <Card><Text style={S.h2}>화면 테마</Text><View style={S.wrap}>{(['light','night'] as const).map(mode=><Pressable key={mode} accessibilityRole="radio" accessibilityLabel={mode==='light'?'Light Mode':'Night Glass Mode'} accessibilityState={{checked:theme.mode===mode}} aria-checked={theme.mode===mode} onPress={()=>theme.setMode(mode)} style={[S.choice,theme.mode===mode&&S.chosen]}><Text style={S.body}>{mode==='light'?'☀ Light Mode':'☾ Night Glass Mode'}</Text></Pressable>)}</View>{theme.storageError&&<Text style={S.error}>테마 설정을 저장하지 못했어요. 다음 실행 때 다시 선택해 주세요.</Text>}</Card>
        <Card><Text style={S.h2}>한 번에 원하는 답에 가까워지도록</Text><Text style={S.body}>질문을 명확하게 다듬고 작업에 맞는 모델을 찾아보세요. 반복 질문과 불필요한 고성능 모델 사용을 줄이는 것이 목표예요.</Text><Text style={S.small}>개선과 추천에도 AI가 사용돼요. 실제 사용량과 절약 효과는 질문에 따라 달라요.</Text></Card>
        <Card><Text style={S.h2}>Gemini 연결</Text><Text style={S.body}>개선기와 모델 추천 화면 위의 Gemini 연결에서 본인의 API 키를 설정할 수 있어요. 키는 휴대폰 보안 저장소에 보관하고, 질문은 실행 버튼을 누를 때 Google로 전송돼요.</Text><Text style={S.small}>Gemini API에는 연결한 Google 프로젝트의 한도와 요금이 적용돼요. 모델 추천 분류는 작업 선택을 돕는 참고 정보예요. 공식 성능 순위나 에너지 측정 등급은 아니에요.</Text></Card>
        <Button title="영수증 개발 안내" secondary onPress={() => setTab('receipt')} />
        <Text style={S.small}>AIMI · 1.6.0</Text>
      </>}
    </ScrollView>
    <View style={S.nav}>{([['home', '⌂', '홈'], ['receipt', '▤', '영수증'], ['my', '○', '마이']] as const).map(([id, icon, label]) => <Pressable key={id} accessibilityRole="tab" accessibilityLabel={label} accessibilityState={{ selected: tab === id }} style={S.navItem} onPress={() => setTab(id)}><View style={{width:38,height:38,borderRadius:19,alignItems:'center',justifyContent:'center',backgroundColor:tab===id?'#F4F6F1':'transparent'}}><Text style={[S.navIcon,{color:tab===id?'#263E34':C.muted}]}>{icon}</Text></View><Text style={[S.navText, tab === id && { color: C.green, fontWeight: '700' }]}>{label}</Text></Pressable>)}</View>
  </SafeAreaView></PlanSurface>;
}
