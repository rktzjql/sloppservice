# AIMI 1.6.0 소스 안내

App.tsx가 앱 진입 화면입니다. src/studio는 개선기·모델 추천, src/theme은 테마, modules/ai-usage는 Android 자동 기록 기능입니다.

## 화면 실행
Node.js 22 이상과 npm을 설치한 후 이 폴더에서:
```
npm ci
npm run web
```
브라우저 화면에서 테마와 개선기·추천을 확인할 수 있습니다. Android 접근성 기능은 실기기가 필요합니다. Gemini 키는 앱의 연결 화면에 직접 입력합니다.

## 검사
```
npm run typecheck
npm test
```

## Android 개발
Android Studio, SDK와 JDK 21을 준비하고 ANDROID_HOME을 설정하거나 android/local.properties에 본인의 SDK 경로를 설정하세요. android 폴더에는 수정한 네이티브 파일과 아이콘이 포함되어 있으므로 prebuild --clean으로 덮어쓰지 마세요.
기존 앱 서명 키는 포함하지 않았습니다. 테스트용 키가 없다면 프로젝트 루트에서 새 키를 만들 수 있습니다:
```
keytool -genkeypair -v -storetype JKS -keystore android/app/debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
npm run android
```
새 키로 빌드한 앱은 배포된 기존 APK 위에 덮어 설치할 수 없습니다. 별도 테스트 기기나 에뮬레이터를 사용하세요.

API 키·서명 키·로컬 환경 설정·node_modules·빌드 결과는 제외한 소스 사본입니다. README.md에는 이전 버전의 개발 기록도 있습니다.
