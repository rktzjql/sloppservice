import { energyFor } from './energy';
export type UsageKind = 'text' | 'light' | 'image' | 'retry' | 'unknown';
export type Provider = 'ChatGPT' | 'Claude' | 'Gemini' | '기타';
export type UsageRecord = { id: string; createdAt: string; provider: Provider; kind: UsageKind; count: number; source: 'manual' | 'usage-confirmed' | 'automatic-send'; sessionId?: string; detection?: 'click' | 'button-transition' | 'input-transition' };
export const LABELS: Record<UsageKind, string> = { text: '일반 텍스트', light: '경량 텍스트', image: '이미지 생성', retry: '다시 생성', unknown: '전송(유형 미확인)' };
export function validCount(value: string): number | null {
  if (!/^\d+$/.test(value.trim())) return null;
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= 1 && n <= 999 ? n : null;
}
export function dayKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
export function summarize(records: UsageRecord[]) {
  let sum = 0, estimatedCount = 0, unknownCount = 0;
  for (const record of records) {
    const energy = energyFor(record);
    if (energy === null) unknownCount += record.count;
    else { sum += energy; estimatedCount += record.count; }
  }
  return { energy: estimatedCount===0 && unknownCount>0 ? null : sum, estimatedCount, unknownCount,
    count: records.reduce((n,r)=>n+r.count,0), retryCount: records.filter(r=>r.kind==='retry').reduce((n,r)=>n+r.count,0) };
}
export function todayRecords(records: UsageRecord[], now = new Date()) {
  return records.filter(r => dayKey(new Date(r.createdAt)) === dayKey(now));
}
export function parseRecords(raw: string | null): UsageRecord[] {
  if (!raw) return [];
  const parsed: unknown = JSON.parse(raw);
  if (!Array.isArray(parsed) || !parsed.every(r => r && typeof r.id === 'string' && typeof r.createdAt === 'string' && Number.isFinite(Date.parse(r.createdAt)) && ['ChatGPT','Claude','Gemini','기타'].includes(r.provider) && Object.hasOwn(LABELS, r.kind) && Number.isInteger(r.count) && r.count >= 1 && r.count <= 999 && (r.source === 'manual' || (r.source === 'usage-confirmed' && typeof r.sessionId === 'string' && r.sessionId.length > 0)))) throw new Error('저장된 기록 형식을 읽을 수 없습니다.');
  return parsed;
}
