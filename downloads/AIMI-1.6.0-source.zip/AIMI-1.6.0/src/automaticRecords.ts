import type { UsageRecord } from './records';
export type AutomaticSend = {id:string;provider:'ChatGPT'|'Gemini';createdAt:number;detection?:'click'|'button-transition'|'input-transition'};
export function automaticRecords(rows: AutomaticSend[], assumeText: boolean): UsageRecord[] {
 const unique=new Map<string,UsageRecord>();
 for(const row of rows){
  if(!row.id || !['ChatGPT','Gemini'].includes(row.provider) || !Number.isFinite(row.createdAt) || row.createdAt<=0 || !Number.isFinite(new Date(row.createdAt).getTime()))continue;
  unique.set(row.id,{id:`auto:${row.id}`,createdAt:new Date(row.createdAt).toISOString(),provider:row.provider,kind:assumeText?'text':'unknown',count:1,source:'automatic-send',detection:row.detection==='input-transition'?'input-transition':row.detection==='button-transition'?'button-transition':'click'});
 }
 return [...unique.values()];
}
