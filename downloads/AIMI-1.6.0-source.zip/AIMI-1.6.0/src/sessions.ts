export const TRACKED_APPS = {
  'com.openai.chatgpt': 'ChatGPT',
  'com.google.android.apps.bard': 'Gemini',
  'com.anthropic.claude': 'Claude',
} as const;
export type UsageEvent = { packageName: string; timestamp: number; kind: 'resume' | 'pause' | 'stop' };
export type Session = { id: string; provider: string; startedAt: number; endedAt: number };
// Sessions are foreground intervals, never question counts. Unclosed intervals are omitted.
export function sessionsFromEvents(events: UsageEvent[], since: number): Session[] {
  const active = new Map<string, number>();
  const sessions: Session[] = [];
  function close(pkg: string, end: number) {
    const start = active.get(pkg); active.delete(pkg);
    if (start === undefined || end <= start) return;
    sessions.push({id:`${pkg}:${start}`,provider:TRACKED_APPS[pkg as keyof typeof TRACKED_APPS],startedAt:start,endedAt:end});
  }
  for (const event of [...events].sort((a,b)=>a.timestamp-b.timestamp)) {
    if (!Number.isFinite(event.timestamp) || event.timestamp < since) continue;
    if (event.kind === 'stop') { for (const pkg of active.keys()) close(pkg,event.timestamp); continue; }
    if (!Object.hasOwn(TRACKED_APPS,event.packageName)) continue;
    if (event.kind === 'resume' && !active.has(event.packageName)) active.set(event.packageName,event.timestamp);
    if (event.kind === 'pause') close(event.packageName,event.timestamp);
  }
  // Join brief same-app activity transitions so they do not become separate prompts.
  const merged: Session[] = [];
  const latest = new Map<string, Session>();
  for (const session of sessions.sort((a,b)=>a.startedAt-b.startedAt)) {
    const previous = latest.get(session.provider);
    if (previous && session.startedAt-previous.endedAt <= 1500 && !events.some(e=>e.kind==='stop' && e.timestamp>=previous.endedAt && e.timestamp<=session.startedAt)) previous.endedAt=session.endedAt;
    else { merged.push({...session});latest.set(session.provider,merged[merged.length-1]); }
  }
  return merged.sort((a,b)=>b.startedAt-a.startedAt);
}
