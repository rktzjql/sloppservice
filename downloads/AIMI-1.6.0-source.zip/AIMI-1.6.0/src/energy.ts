import type { Provider, UsageKind } from './records';
// Historical public disclosures, not per-device or per-model measurements.
// Live re-verification was blocked by this environment's HTTP policy on 2026-11-05.
export const ENERGY_REFERENCES = [
 { provider: 'ChatGPT', wh: 0.34, statistic: '평균', published: '2025-06-10', title: 'Sam Altman · The Gentle Singularity', url: 'https://blog.samaltman.com/the-gentle-singularity', scope: '평균 ChatGPT 질의 공개값을 일반 텍스트 요청의 참고값으로 사용. 모델·길이별 계수가 아님.' },
 { provider: 'Gemini', wh: 0.24, statistic: '중앙값', published: '2025-08', title: 'Google · Measuring the Environmental Impact of Delivering AI at Google Scale', url: 'https://arxiv.org/abs/2508.15734', scope: '2025년 5월 Gemini Apps 텍스트 프롬프트의 중앙값. 이미지·음성·영상에는 적용하지 않음.' },
] as const;
export const ENERGY_NOTE = '2025 공개 참고값: ChatGPT 평균 0.34 Wh/질의 · Gemini 텍스트 중앙값 0.24 Wh/요청. 통계·범위가 달라 효율 순위로 비교할 수 없고, 실제 사용량 측정값이 아닙니다. 이미지·경량·재생성·Claude·기타는 산정하지 않습니다.';
export function energyFor(record: {provider: Provider;kind:UsageKind;count:number}): number | null {
 if(record.kind!=='text')return null;
 const reference=ENERGY_REFERENCES.find(r=>r.provider===record.provider);
 return reference ? reference.wh*record.count : null;
}
export function energyLabel(value: number|null): string { return value===null?'산정 불가':`${value.toFixed(2)} Wh`; }
