import type { Tier } from './logic';

export const CATALOG_CHECKED_AT = '2026-11-09';
export const TIER_NOTE = 'Light·Medium·High는 작업에 맞춰 나눈 AIMI의 추천 분류예요. 공식 성능 순위나 에너지 측정 등급은 아니에요.';
export type Model = { id: string; name: string; provider: string; tier: Tier; note: string; source: string; aliases?: string[] };
const google = 'https://firebase.google.com/docs/ai-logic/models';
const openai = 'https://developers.openai.com/api/docs/models';
const anthropic = 'https://platform.claude.com/docs/en/models/overview';
const mistral = 'https://docs.mistral.ai/models';
const deepseek = 'https://api-docs.deepseek.com/quick_start/pricing';

// Official public catalog snapshot, not a live availability or measured performance feed.
// IDs are version-specific recommendation identifiers, not connection settings.
export const MODELS: Model[] = [
  { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash-Lite', provider: 'Google', tier: 'Light', note: '짧은 요약·분류·문장 다듬기처럼 반복되는 가벼운 작업의 후보예요.', source: google },
  { id: 'gpt-6-luna', name: 'GPT-6 Luna', provider: 'OpenAI', tier: 'Light', note: '간단한 질문과 대량의 짧은 작업에서 비용과 응답 시간을 우선할 때 고려해요.', source: openai },
  { id: 'claude-haiku-5-5', name: 'Claude Haiku 5.5', provider: 'Anthropic', tier: 'Light', note: '분류·정보 추출·짧은 응답처럼 빠른 처리가 필요한 작업의 후보예요.', source: anthropic },
  { id: 'ministral-3-8b', name: 'Ministral 3 8B', provider: 'Mistral AI', tier: 'Light', note: '가벼운 텍스트·이미지 이해 작업에 고려하는 소형 공개 가중치 모델이에요. 실행 환경에 따라 결과와 비용이 달라요.', source: mistral },
  { id: 'ministral-3-3b', name: 'Ministral 3 3B', provider: 'Mistral AI', tier: 'Light', note: '작은 모델로 처리할 수 있는 단순 작업의 후보예요. 직접 실행하려면 별도 환경이 필요해요.', source: mistral },
  { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', provider: 'Google', tier: 'Medium', note: '여러 조건이 있는 질문과 문서·이미지 이해에서 속도와 품질의 균형을 고려해요.', source: google },
  { id: 'gpt-6.1-sol', name: 'GPT-6.1 Sol', provider: 'OpenAI', tier: 'Medium', note: '비교 분석·코딩·일반 업무에서 성능과 비용의 균형을 고려하는 후보예요.', source: openai },
  { id: 'gpt-6.1-terra', name: 'GPT-6.1 Terra', provider: 'OpenAI', tier: 'Medium', note: '글쓰기·시각적 추론·컴퓨터 사용 관련 작업의 후보예요. 도구 실행에는 해당 서비스의 지원이 필요해요.', source: openai },
  { id: 'claude-sonnet-5-5', name: 'Claude Sonnet 5.5', provider: 'Anthropic', tier: 'Medium', note: '여러 단계의 일반 업무와 코딩에서 속도와 추론 능력의 균형을 고려해요.', source: anthropic },
  { id: 'deepseek-v4.1-flash-1017', name: 'DeepSeek V4.1 Flash 1017', provider: 'DeepSeek', tier: 'Medium', note: '긴 문맥을 다루는 코딩·문서 분석의 후보예요. 공식 API의 deepseek-flash가 이 버전을 제공해요.', source: deepseek },
  { id: 'mistral-small-4', name: 'Mistral Small 4', provider: 'Mistral AI', tier: 'Medium', note: '일반 지시·추론·코딩을 함께 다루는 공개 가중치 모델이에요. 작업에 따라 추론 설정을 선택해요.', source: mistral },
  { id: 'gemini-4-argon', name: 'Gemini 4 Argon', provider: 'Google', tier: 'High', note: '복잡한 다단계 추론·코드 검토·전문적인 분석의 후보예요. Gemini API 사용에는 결제 연결이 필요해요.', source: google, aliases: ['Argon', '아르곤', '아르곤 모델'] },
  { id: 'gpt-6-astra', name: 'GPT-6 Astra', provider: 'OpenAI', tier: 'High', note: '어려운 추론·복잡한 코딩처럼 깊이 있는 검토가 필요한 작업의 후보예요.', source: openai },
  { id: 'claude-opus-5-5', name: 'Claude Opus 5.5', provider: 'Anthropic', tier: 'High', note: '긴 작업 흐름의 코딩·지식 업무와 복잡한 분석의 후보예요.', source: anthropic },
  { id: 'claude-fable-5-1', name: 'Claude Fable 5.1', provider: 'Anthropic', tier: 'High', note: '난도가 높은 추론과 장시간 이어지는 에이전트 작업의 후보예요. 간단한 질문에는 과할 수 있어요.', source: anthropic },
  { id: 'deepseek-v4-pro', name: 'DeepSeek V4 Pro', provider: 'DeepSeek', tier: 'High', note: '복합적인 분석·추론 작업에 비교할 수 있는 DeepSeek의 Pro 후보예요. 실제 품질은 내 질문으로 확인하세요.', source: deepseek },
  { id: 'mistral-large-4', name: 'Mistral Large 4', provider: 'Mistral AI', tier: 'High', note: '복합적인 텍스트·이미지 이해와 일반 추론 작업에 고려하는 대형 공개 가중치 모델이에요.', source: mistral },
];

export function findModels(tier: Tier, search: string) {
  const query = search.trim().toLocaleLowerCase();
  return MODELS.filter(model => model.tier === tier && `${model.name} ${model.provider} ${(model.aliases ?? []).join(' ')}`.toLocaleLowerCase().includes(query));
}
export function pricePer100(perMillion: number) {
  return `$${(perMillion / 10000).toFixed(5)}`;
}
