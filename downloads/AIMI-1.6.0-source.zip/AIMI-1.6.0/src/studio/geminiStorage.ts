import { Platform } from 'react-native';
import { checkKey, checkModel, type GeminiConfig } from './gemini';

const STORAGE_KEY = 'aimi.gemini.personal.v1';
let session: GeminiConfig | null = null;
export async function loadGeminiConfig(): Promise<GeminiConfig | null> {
  if (Platform.OS === 'web') return session;
  const secure = await import('expo-secure-store');
  const raw = await secure.getItemAsync(STORAGE_KEY);
  if (!raw) return null;
  try { const data = JSON.parse(raw); return { apiKey: checkKey(data.apiKey), model: checkModel(data.model) }; }
  catch { throw new Error('저장한 Gemini 연결 정보를 읽지 못했어요. 연결 설정에서 다시 저장해 주세요.'); }
}
export async function saveGeminiConfig(config: GeminiConfig) {
  const value = { apiKey: checkKey(config.apiKey), model: checkModel(config.model) };
  if (Platform.OS === 'web') { session = value; return; }
  const secure = await import('expo-secure-store');
  await secure.setItemAsync(STORAGE_KEY, JSON.stringify(value), { keychainAccessible: secure.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
}
export async function removeGeminiConfig() {
  if (Platform.OS === 'web') { session = null; return; }
  const secure = await import('expo-secure-store');
  await secure.deleteItemAsync(STORAGE_KEY);
}
