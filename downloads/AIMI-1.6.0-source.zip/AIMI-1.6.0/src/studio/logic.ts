export type Tier = 'Light' | 'Medium' | 'High';
export const MAX_PROMPT = 4000;
export const SCHOOL_EXAMPLE = '학교 발표용 재활용 방법 3개 추천좀';
export const TIERS: { id: Tier; subtitle: string }[] = [
  { id: 'Light', subtitle: '가벼운 요약·변환' },
  { id: 'Medium', subtitle: '복합 조건·분석' },
  { id: 'High', subtitle: '복잡한 추론' },
];
export function validatePrompt(value: string) {
  if (!value.trim()) throw new Error('먼저 질문을 입력해 주세요.');
  if (value.length > MAX_PROMPT) throw new Error('질문은 4,000자 이내로 입력해 주세요.');
  return value.trim();
}
// Replace prose only; preserve quoted source material and code verbatim.
function mapProse(value: string, transform: (part: string) => string) {
  return value.split(/(```[\s\S]*?(?:```|$)|`[^`\n]*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|“[^”]*”|「[^」]*」)/g)
    .map((part, index) => index % 2 ? part : transform(part)).join('');
}
const actions = '추천|요약|정리|번역|설명|비교|분석|작성|검토|계산|증명|소개';
export function improveLocally(value: string) {
  const original = validatePrompt(value);
  const changes = new Set<string>();
  const code = /```|^\s*(def |class |function |import |from .+ import |const |let |SELECT |\{\s*$)/m.test(original);
  let improved = code ? original : mapProse(original, part => {
    let next = part;
    const replace = (pattern: RegExp, replacement: string, reason: string) => {
      const after = next.replace(pattern, replacement);
      if (after !== next) changes.add(reason);
      next = after;
    };
    replace(/(학교 |수업 |회사 |팀 )?발표용\s*/g, '$1발표에 사용할 ', '사용 목적을 자연스러운 문장으로 풀었어요.');
    replace(new RegExp(`(${actions})\\s*(?:좀|부탁(?:해)?|해\\s*줘(?:요)?|해주세요)(?=[.!?。！？,，\\n]|\\s*$)`, 'g'), '$1해 주세요', '짧게 줄인 부탁을 분명한 요청으로 바꿨어요.');
    replace(/(알려|만들어|적어|써|고쳐|골라|찾아|풀어|바꿔|보여)\s*줘(?:요)?(?=[.!?。！？,，\n]|\s*$)/g, '$1 주세요', '요청 표현을 읽기 쉽게 정리했어요.');
    replace(/(문구|멘트|인사말|편지|이메일|코드)\s*좀(?=[.!?。！？]|\s*$)/g, '$1 작성해 주세요', '줄여 쓴 요청을 작성 요청으로 정리했어요.');
    replace(/\s*뭐야\??(?=\s*$)/g, ' 무엇인지 설명해 주세요', '질문을 설명 요청으로 정리했어요.');
    replace(new RegExp(`(${actions})(?=[.!?。！？]*\\s*$)`), '$1해 주세요', '작업 이름을 실행할 요청으로 바꿨어요.');
    replace(/(\d+\s*(?:개|가지))\s+(추천|소개)해 주세요/g, '$1를 $2해 주세요', '요청한 개수는 유지하고 문장을 연결했어요.');
    replace(/(\d+\s*곳)\s+(추천|소개)해 주세요/g, '$1을 $2해 주세요', '요청한 개수는 유지하고 문장을 연결했어요.');
    if (next !== part && /주세요$/.test(next)) next += '.';
    return next;
  });
  if (!code && improved === original && /^[가-힣A-Za-z0-9 ]{2,60}$/.test(original)
      && !/(주세요|합니다|이다|해요|말고|제외|금지|없이|않|말아|하지|요청|조건|답변|지|까|니|야|죠|해|줘|요)$/.test(original)
      && !/(줘|해줘|해 줘|주세요|하지|말고|제외|금지|없이)/.test(original)) {
    improved = `${original}에 대해 설명해 주세요.`;
    changes.add('짧은 주제를 설명 요청으로 바꿨어요.');
  }
  if (improved.length > MAX_PROMPT) { improved = original; changes.clear(); }
  const hasAudience = /학생|어린이|초보|전문가|직장인|고객|대상|독자|세\s*(?:아이|어린이)/.test(original);
  const hasFormat = /표로|목록|리스트|문장|문단|단계|JSON|마크다운|형식|줄로|글자|자\s*이내|코드만|예시.{0,4}(빼|없이|제외)/i.test(original);
  return { original, improved, mode: 'local' as const, changes: [...changes],
    audience: hasAudience || code ? '' : /학교|교실/.test(original) ? '학생' : '이 주제를 처음 접하는 사람',
    format: hasFormat || code ? '' : '핵심 내용을 항목별로 정리해 주세요.',
    explanation: changes.size ? [...changes].join(' ') + ' 숫자와 나머지 조건은 그대로 두었어요.'
      : code ? '코드와 들여쓰기는 그대로 유지했어요. 필요한 조건은 확장 예시에서 추가할 수 있어요.'
      : '적용할 표현 수정 규칙이 없어 원문을 유지했어요. 필요한 조건은 확장 예시에서 추가해 보세요.',
  };
}
export function expandPrompt(base: string, audience: string, format: string) {
  return [base, audience.trim() && `설명 대상은 ${audience.trim()}입니다.`, format.trim()].filter(Boolean).join('\n');
}
export type Recommendation = { tier: Tier; task: string; reason: string; signals: string[]; needsSource: boolean; needsImage: boolean };
export function recommend(value: string): Recommendation {
  const prompt = validatePrompt(value);
  const p = prompt.split(/```/)[0] || prompt;
  const signals: string[] = [];
  const simple = /요약|번역|맞춤법|말투|영어로|한국어로|쉬운 말|쉽게 설명|무슨 뜻|뭐야|뜻.{0,5}(알려|설명)|summari[sz]|translat|spell.?check/i.test(p);
  const hardSystem = /분산\s*시스템|동시성|교착|암호\s*설계|복잡도.{0,10}증명|정확성.{0,10}증명|수학적.{0,10}증명|distributed|deadlock/i.test(p);
  const designAction = /설계|구현|해결|최적화|증명|검증|분석|design|implement|prove|optimi[sz]/i.test(p);
  const explicitReasoning = /(?:정리|명제|가설|수식|부등식|알고리즘|정확성|안정성|귀납법).{0,30}증명|증명해|증명해 주세요|prove\b|\bproof\b/i.test(p);
  const complex = /복잡한|심층|여러 단계|다단계|상충|반례|아키텍처|architecture|multi.stage/i.test(p);
  const code = /코드.{0,12}(짜|작성|만들|수정|검토)|코딩|디버깅|함수.{0,12}(작성|만들|구현)|리팩[터토]링|\b(debug|refactor|coding)\b/i.test(p);
  const analysis = /비교|분석|장단점|기획|보고서|전략|compare|analy[sz]|strategy/i.test(p);
  const planning = /계획|일정|코스|커리큘럼|plan|itinerary/i.test(p);
  const constraints = [/(예산|budget|비용.{0,5}이내)/i, /(제외|금지|없이|않|하지 말|without)/i, /(반드시|필수|must)/i, /(\d+\s*(일|박|시간|분)|일정|기간)/i, /(근거|출처|제약|조건)/i].filter(re => re.test(p)).length;
  let tier: Tier = 'Light';
  let task = /요약|summari/i.test(p) ? '요약' : /번역|영어로|한국어로|translat/i.test(p) ? '번역' : '간단한 질문·작성';
  if ((!simple && explicitReasoning) || (hardSystem && designAction && !simple) || (complex && designAction && !simple)) {
    tier = 'High'; task = '복잡한 추론·설계'; signals.push('증명 또는 복잡한 설계·검증을 요청했어요.');
  } else if ((!simple && (code || analysis)) || constraints >= 3 || (planning && constraints >= 2) || prompt.length > 1800) {
    tier = 'Medium'; task = code ? '코드 작성·검토' : analysis ? '비교·분석' : planning ? '조건을 맞추는 계획' : '여러 조건·긴 자료 처리';
    if (code) signals.push('코드를 작성하거나 검토하는 작업이에요.');
    if (analysis) signals.push('여러 정보를 비교하거나 분석해요.');
    if (constraints >= 2) signals.push('여러 종류의 조건을 함께 맞춰야 해요.');
    if (prompt.length > 1800) signals.push('자료가 길어 맥락을 유지해야 해요.');
  } else signals.push('짧은 질문·작성·변환은 가벼운 모델부터 시작할 수 있어요.');
  return { tier, task, reason: `${task}에는 ${tier}를 추천해요.`, signals,
    needsSource: /최신|오늘|현재|출처|실시간|뉴스|시세|current|latest|news/i.test(p),
    needsImage: /이미지|사진|그림|스크린샷|image|photo|screenshot/i.test(p),
  };
}
