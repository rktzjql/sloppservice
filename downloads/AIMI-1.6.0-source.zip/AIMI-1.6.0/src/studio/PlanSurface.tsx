import React from 'react';
import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../theme/Theme';

export default function PlanSurface({ children }: { children: React.ReactNode }) {
  const { colors: c, isDark } = useTheme();
  return <View style={[styles.outer,{backgroundColor:c.bg}]}><View style={[styles.phone,{backgroundColor:c.bg}]}>
    <LinearGradient pointerEvents="none" colors={isDark ? ['#8BA6BD99','#2857B2B3','#1C1C1E00'] : ['#90BA53E6','#C5D7A199','#F2F1EB00']} locations={[0,.4,1]} start={{x:.5,y:0}} end={{x:.5,y:1}} style={styles.top}/>
    <LinearGradient pointerEvents="none" colors={isDark ? ['#ACCCE477','#2E58A6CC','#1C1C1E00'] : ['#355F4DE6','#AAC48BAA','#F2F1EB00']} locations={[0,.4,1]} start={{x:.5,y:1}} end={{x:.5,y:0}} style={styles.bottom}/>
    {children}
  </View></View>;
}
const styles = StyleSheet.create({ outer:{flex:1}, phone:{flex:1,width:'100%',maxWidth:480,alignSelf:'center',overflow:'hidden'}, top:{position:'absolute',top:0,left:0,right:0,height:350}, bottom:{position:'absolute',bottom:0,left:0,right:0,height:370} });
