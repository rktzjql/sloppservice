import {useTheme,type ThemeColors} from '../theme/Theme';
import React, { useMemo, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { checkKey, normalizeKey, listGeminiModels, type GeminiConfig, type GeminiModel } from './gemini';
import { removeGeminiConfig, saveGeminiConfig } from './geminiStorage';
import PlanSurface from './PlanSurface';

export default function GeminiSettings({ current, onSave, onClose }: { current: GeminiConfig | null; onSave: (value: GeminiConfig | null) => void; onClose: () => void }) {
 const {colors:c,isDark}=useTheme(); const s=useMemo(()=>createStyles(c),[c]);
  const [key, setKey] = useState('');
  const [models, setModels] = useState<GeminiModel[]>([]);
  const [model, setModel] = useState(current?.model ?? '');
  const [verifiedKey, setVerifiedKey] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [query, setQuery] = useState('');
  const controller = useRef<AbortController | null>(null);
  const active = useRef(true);
  useEffect(() => { active.current = true; return () => { active.current = false; controller.current?.abort(); }; }, []);
  async function check() {
    if (busy) return;
    setBusy(true); setError(''); setNotice(''); setModels([]); setVerifiedKey('');
    const abort = new AbortController(); controller.current = abort;
    try {
      const raw = key || current?.apiKey || '';
      const candidateKey = checkKey(raw);
      if (raw !== candidateKey) { setKey(candidateKey); setNotice('복사할 때 붙은 바깥 공백·따옴표·보이지 않는 문자를 정리했어요. 키 값은 화면에 표시하지 않아요.'); }
      const choices = await listGeminiModels(candidateKey, { signal: abort.signal });
      if (!active.current) return;
      setModels(choices); setVerifiedKey(candidateKey);
      setModel(choices.some(item => item.name === model) ? model : choices[0].name);
    } catch (e) { if (active.current) setError((e as Error).message); }
    finally { if (active.current) setBusy(false); controller.current = null; }
  }
  async function save() {
    if (busy || !verifiedKey || !models.some(item => item.name === model)) return;
    setBusy(true); setError('');
    try {
      const config = { apiKey: verifiedKey, model };
      await saveGeminiConfig(config); if (!active.current) return;
      setKey(''); setVerifiedKey(''); onSave(config); onClose();
    } catch { if (active.current) setError('키를 안전하게 저장하지 못했어요. 다시 시도해 주세요.'); }
    finally { if (active.current) setBusy(false); }
  }
  async function remove() {
    if (busy) return;
    setBusy(true); setError('');
    try { await removeGeminiConfig(); if (active.current) { onSave(null); onClose(); } }
    catch { if (active.current) setError('저장된 키를 삭제하지 못했어요. 다시 시도해 주세요.'); }
    finally { if (active.current) setBusy(false); }
  }
  const choices = models.filter(item => `${item.name} ${item.displayName}`.toLowerCase().includes(query.toLowerCase()));
  return <Modal visible animationType="slide" onRequestClose={onClose}><PlanSurface><SafeAreaView style={s.fill}><KeyboardAvoidingView style={s.fill} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
    <View style={s.header}><Text style={s.title}>Gemini 연결</Text><Pressable accessibilityRole="button" accessibilityLabel="연결 설정 닫기" onPress={onClose} style={s.close}><Text style={s.body}>✕</Text></Pressable></View>
    <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <Text style={s.body}>본인의 Google AI Studio API 키로 연결해요. 연결 후 질문을 보내면 Gemini가 문장을 개선하고 모델을 추천해요.</Text>
      <View style={s.card}><Text style={s.label}>API 키</Text><TextInput accessibilityLabel="Gemini API 키" placeholder={current ? '저장된 키 사용 · 바꾸려면 새 키 입력' : 'Google AI Studio에서 만든 키 붙여넣기'} placeholderTextColor={c.placeholder} value={key} onChangeText={value => { setKey(value); setModels([]); setVerifiedKey(''); setError(''); setNotice(''); }} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="off" textContentType="none" editable={!busy} style={s.input}/><Text style={s.small}>{key ? `입력 ${normalizeKey(key).length.toLocaleString()}자 · 키는 숨겨져 있어요` : current ? '저장된 키가 있어요. 빈칸이면 저장된 키로 확인해요.' : 'AI Studio의 복사 버튼으로 키 전체를 붙여넣어 주세요.'}</Text><Text style={s.small}>{Platform.OS === 'web' ? '웹에서는 키를 저장하지 않아요. 새로고침하면 다시 입력해야 해요.' : '키는 이 휴대폰의 보안 저장소에 보관해요. APK·깃허브에 포함되지 않아요.'}</Text>
        {!!notice && <Text accessibilityLiveRegion="polite" style={s.small}>{notice}</Text>}
        {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
        <Pressable accessibilityRole="button" disabled={busy || (!key.trim() && !current)} onPress={() => void check()} style={[s.button,busy&&s.disabled]}><Text style={s.buttonText}>{busy ? '확인 중…' : '키 확인 · 모델 목록 불러오기'}</Text></Pressable>
      </View>
      {busy && <ActivityIndicator color={c.green}/>}
      {!!models.length && <View style={s.card}><Text style={s.label}>호출할 AI 모델 선택</Text><Text style={s.small}>모델 목록 조회는 완료됐어요. 실제 생성 권한·무료 한도는 첫 요청에서 확인돼요. 가격은 Google 프로젝트 설정에 따라 달라져요.</Text><TextInput accessibilityLabel="연결 모델 검색" placeholder="모델 이름 검색" value={query} onChangeText={setQuery} style={s.input}/>
        {choices.map(item => <Pressable accessibilityRole="radio" accessibilityState={{ checked: model === item.name }} key={item.name} onPress={() => setModel(item.name)} disabled={busy} style={[s.option, model === item.name && s.selected]}><Text style={s.label}>{model === item.name ? '● ' : '○ '}{item.displayName}</Text><Text style={s.small}>{item.name}</Text></Pressable>)}
        {!choices.length && <Text style={s.body}>검색 결과가 없어요.</Text>}
      </View>}
      <View style={s.notice}><Text style={s.label}>질문은 Google로 전송돼요</Text><Text style={s.body}>개선·추천 버튼을 누르면 입력한 문장이 Google Gemini로 전송돼요. 무료 구간에서는 입력·응답이 Google 제품 개선에 사용될 수 있어요.</Text><Text style={s.small}>앱은 유료 플랜으로 전환하지 않지만, 이미 결제를 연결한 Google 프로젝트는 사용료가 생길 수 있어요. AI Studio에서 결제 상태와 한도를 확인해 주세요. 한도 초과 시 자동으로 재시도하지 않아요.</Text></View>
      <Pressable accessibilityRole="button" disabled={busy || !verifiedKey || !model} onPress={() => void save()} style={[s.button,(busy || !verifiedKey || !model)&&s.disabled]}><Text style={s.buttonText}>선택한 모델로 연결하기</Text></Pressable>
      {!!current && <Pressable accessibilityRole="button" disabled={busy} style={s.close} onPress={() => void remove()}><Text style={s.error}>연결 해제 · 저장한 키 삭제</Text></Pressable>}
      <Text style={s.small}>개인 테스트용 연결이에요. 다른 사람에게 API 키를 공유하지 마세요.</Text>
    </ScrollView>
  </KeyboardAvoidingView></SafeAreaView></PlanSurface></Modal>;
}
const createStyles=(c:ThemeColors)=>StyleSheet.create({ fill: { flex: 1 }, header: { paddingHorizontal: 24, paddingTop: 10, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, title: { color: c.ink, fontSize: 20, fontWeight: '800' }, content: { padding: 24, gap: 18 }, body: { color: c.muted, fontSize: 14, lineHeight: 23 }, small: { color: c.muted, fontSize: 11, lineHeight: 19 }, label: { color: c.ink, fontWeight: '700', fontSize: 13, lineHeight: 22 }, card: { borderWidth:1,borderColor:c.line,padding: 18, borderRadius: 18, backgroundColor: c.paper, gap: 12 }, input: { padding: 13, borderRadius: 12, backgroundColor: c.input, color: c.ink, fontSize: 13, minHeight: 48 }, button: { backgroundColor: c.primary, borderRadius: 14, padding: 16, minHeight: 50, alignItems: 'center' }, buttonText: { color: c.primaryText, fontSize: 14, fontWeight: '700' }, disabled: { opacity: .4 }, close: { padding: 12, minHeight: 44, justifyContent: 'center' }, option: { padding: 12, borderRadius: 12, borderWidth: 1, borderColor: c.line }, selected: { backgroundColor: c.selected, borderColor: c.green }, notice: { backgroundColor: c.paper, padding: 16, gap: 8, borderRadius: 16 }, error: { color: c.error, fontSize: 13, lineHeight: 22 } });
