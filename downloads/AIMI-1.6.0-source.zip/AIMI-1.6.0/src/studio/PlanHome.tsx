import React, {useMemo} from 'react';
import {useTheme,type ThemeColors} from '../theme/Theme';
import { Pressable, StyleSheet, Text, View } from 'react-native';

export default function PlanHome({ onImprove, onModels }: {
  onImprove: () => void; onModels: () => void;
}) {
  const {colors:c}=useTheme(); const h=useMemo(()=>createStyles(c),[c]);
  return <>
    <View style={h.hero}>
      <Text style={h.eyebrow}>ASK CLEARLY, CHOOSE WISELY</Text>
      <Text style={h.title}>한 번에 원하는 답에{ '\n'}가까워지도록</Text>
      <Text style={h.intro}>질문은 더 명확하게,{ '\n'}AI는 필요한 만큼 알맞게.</Text>
    </View>
    {[
      { title: '프롬프트 개선기', subtitle: '내 의도가 잘 전달되도록 질문을 다듬어요.', detail: '질문 입력 → 개선안 확인 → 내 상황에 맞게 편집', action: onImprove, number: '01' },
      { title: 'AI 모델 추천', subtitle: '질문의 목적과 난이도에 맞는 모델을 찾아요.', detail: '질문 입력 → AI 추천 → 모델 비교', action: onModels, number: '02' },
    ].map(item => <Pressable key={item.title} accessibilityRole="button" accessibilityLabel={item.title} onPress={item.action} style={({ pressed }) => [h.link, pressed && { opacity: .7 }]}>
      <View style={h.row}><Text style={h.number}>{item.number}</Text><Text style={h.linkTitle}>{item.title}</Text><Text style={h.chevron}>›</Text></View>
      <Text style={h.body}>{item.subtitle}</Text><Text style={h.small}>{item.detail}</Text>
    </Pressable>)}
    <View style={h.note}><Text style={h.noteTitle}>필요할 때, 한 번 더 분명하게</Text><Text style={h.body}>이미 명확한 질문은 그대로 사용해도 좋아요. 조건이 복잡하거나 원하는 답이 잘 나오지 않을 때 개선기를 이용해 보세요.</Text></View>
  </>;
}
const createStyles=(c:ThemeColors)=>StyleSheet.create({
  hero: { borderWidth:1,borderColor:c.line,borderRadius: 22, padding: 24, backgroundColor: c.hero, gap: 14 },
  eyebrow: { color: c.heroText, fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  title: { color: c.heroText, fontSize: 27, lineHeight: 38, fontWeight: '800' },
  intro: { color: c.heroText, fontSize: 15, lineHeight: 25 },
  link: { backgroundColor: c.paper, borderWidth:1,borderColor:c.line,borderRadius: 32, padding: 20, gap: 8 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  number: { color: c.green, fontSize: 13, fontWeight: '700' },
  linkTitle: { color: c.ink, fontSize: 20, fontWeight: '700', flex: 1 },
  chevron: { color: c.green, fontSize: 25 },
  body: { color: c.muted, fontSize: 14, lineHeight: 24 },
  small: { color: c.muted, fontSize: 11, lineHeight: 19 },
  note: { padding: 16, gap: 8, backgroundColor:c.paper, borderRadius:20, borderWidth:1, borderColor:c.line },
  noteTitle: { color: c.ink, fontSize: 15, fontWeight: '700' },
});
