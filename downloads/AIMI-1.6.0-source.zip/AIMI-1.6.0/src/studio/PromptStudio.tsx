import {useTheme,type ThemeColors} from '../theme/Theme';
import React, { useMemo, useEffect, useRef, useState } from 'react';
import { BackHandler, Linking, Keyboard, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as Clipboard from 'expo-clipboard';
import { MAX_PROMPT, SCHOOL_EXAMPLE, TIERS, validatePrompt, type Tier } from './logic';
import { improveWithGemini, recommendWithGemini, type GeminiConfig, type AiImprovement, type AiRecommendation } from './gemini';
import { loadGeminiConfig } from './geminiStorage';
import GeminiSettings from './GeminiSettings';
import { CATALOG_CHECKED_AT, TIER_NOTE, findModels, type Model } from './catalog';
import PlanSurface from './PlanSurface';

type Screen = 'input' | 'result' | 'models' | 'detail';
type Result = AiImprovement;
type Variant = 'improved' | 'expanded';

function Action({ title, onPress, secondary = false, disabled = false }: { title: string; onPress: () => void; secondary?: boolean; disabled?: boolean }) {
 const {colors:c,isDark}=useTheme(); const s=useMemo(()=>createStyles(c),[c]);
  return <Pressable accessibilityRole="button" accessibilityState={{ disabled }} disabled={disabled} onPress={onPress} style={({ pressed }) => [s.action, secondary && s.secondary, (pressed || disabled) && { opacity: .45 }]}><Text style={[s.actionText, secondary && { color: c.ink }]}>{title}</Text></Pressable>;
}
function Chip({ title, selected, onPress }: { title: string; selected: boolean; onPress: () => void }) {
 const {colors:c,isDark}=useTheme(); const s=useMemo(()=>createStyles(c),[c]);
  return <Pressable accessibilityRole="button" accessibilityState={{ selected }} onPress={onPress} style={[s.chip, selected && s.chipSelected]}><Text style={s.chipText}>{title}</Text></Pressable>;
}
/** Personal Gemini connection. Prompts/results stay in memory; no local-result fallback. */
export default function PromptStudio({ onExit, initialScreen = 'input' }: { onExit: () => void; initialScreen?: 'input' | 'models' }) {
 const {colors:c,isDark}=useTheme(); const s=useMemo(()=>createStyles(c),[c]);
  const [screen, setScreen] = useState<Screen>(initialScreen);
  const [input, setInput] = useState('');
  const [result, setResult] = useState<Result | null>(null);
  const [variant, setVariant] = useState<Variant>('improved');
  const [improved, setImproved] = useState('');
  const [expanded, setExpanded] = useState('');
  const [tip, setTip] = useState<number | null>(null);
  const [editing, setEditing] = useState(false);
  const [direct, setDirect] = useState('');
  const [imported, setImported] = useState('');
  const [source, setSource] = useState<'direct' | 'imported'>('direct');
  const [recommendation, setRecommendation] = useState<AiRecommendation | null>(null);
  const [evaluated, setEvaluated] = useState('');
  const [tier, setTier] = useState<Tier>('Light');
  const [search, setSearch] = useState('');
  const [model, setModel] = useState<Model | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [help, setHelp] = useState(false);
  const [config, setConfig] = useState<GeminiConfig | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [settings, setSettings] = useState(false);
  const [busy, setBusy] = useState<'improve' | 'recommend' | null>(null);
  const [improvementModel, setImprovementModel] = useState('');
  const [recommendationModel, setRecommendationModel] = useState('');
  const pending = useRef<AbortController | null>(null);
  useEffect(() => {
    let alive = true;
    loadGeminiConfig().then(value => { if (alive) setConfig(value); }).catch(() => { if (alive) setError('저장된 연결을 읽지 못했어요. Gemini 연결에서 다시 설정해 주세요.'); }).finally(() => { if (alive) setLoaded(true); });
    return () => { alive = false; pending.current?.abort(); pending.current = null; };
  }, []);
  function cancelPending() { const request = pending.current; pending.current = null; request?.abort(); setBusy(null); }
  function exit() { cancelPending(); onExit(); }

  const currentText = variant === 'improved' ? improved : expanded;
  const modelPrompt = source === 'direct' ? direct : imported;
  const fresh = recommendation !== null && modelPrompt === evaluated;
  const editedExpansion = !!result && expanded !== result.expanded;

  function go(next: Screen) { Keyboard.dismiss(); setError(''); setMessage(''); setScreen(next); }
  function back() {
    cancelPending();
    if (screen === 'detail') go('models');
    else if (screen === 'models' && result) go('result');
    else if (screen === 'result') go('input');
    else onExit();
  }
  useEffect(() => { const subscription = BackHandler.addEventListener('hardwareBackPress', () => { back(); return true; }); return () => subscription.remove(); }, [screen, result, onExit]);
  useEffect(() => { setMessage(''); setError(''); }, [variant, currentText, source, modelPrompt]);
  async function improve() {
    if (pending.current || !loaded) return;
    if (!config) { setSettings(true); return; }
    let text: string;
    try { text = validatePrompt(input); } catch (e) { setError((e as Error).message); return; }
    const controller = new AbortController(); pending.current = controller; setBusy('improve'); setError(''); Keyboard.dismiss();
    try {
      const next = await improveWithGemini(config, text, { signal: controller.signal });
      if (pending.current !== controller || controller.signal.aborted) return;
      setResult(next); setImproved(next.improved); setExpanded(next.expanded); setImprovementModel(config.model);
      setVariant('improved'); setEditing(false); setTip(null); go('result');
    } catch (e) { if (pending.current === controller) setError((e as Error).message); }
    finally { if (pending.current === controller) { pending.current = null; setBusy(null); } }
  }
  async function evaluate(text: string) {
    if (pending.current || !loaded) return;
    if (!config) { setSettings(true); return; }
    try { validatePrompt(text); } catch (e) { setError((e as Error).message); return; }
    const controller = new AbortController(); pending.current = controller; setBusy('recommend'); setError(''); Keyboard.dismiss();
    try {
      const next = await recommendWithGemini(config, text, { signal: controller.signal });
      if (pending.current !== controller || controller.signal.aborted) return;
      setRecommendation(next); setEvaluated(text); setTier(next.tier); setSearch(''); setRecommendationModel(config.model);
    } catch (e) { if (pending.current === controller) setError((e as Error).message); }
    finally { if (pending.current === controller) { pending.current = null; setBusy(null); } }
  }
  function toModels() {
    if (pending.current) return;
    try { validatePrompt(currentText); } catch (e) { setError((e as Error).message); return; }
    setImported(currentText); setSource('imported'); go('models');
    if (result && currentText === result.improved) {
      setRecommendation(result.recommendation); setEvaluated(currentText); setTier(result.recommendation.tier); setSearch(''); setRecommendationModel(improvementModel);
    } else { setRecommendation(null); void evaluate(currentText); }
  }
  async function copy(text: string) {
    if (!text.trim()) return;
    try {
      const copied = await Clipboard.setStringAsync(text);
      if (!copied) throw new Error('Clipboard unavailable');
      setMessage('문장을 복사했어요. 원하는 AI에 붙여넣어 보세요.'); setError('');
    } catch { setError('복사 권한을 확인해 주세요. 문장을 길게 눌러 직접 복사할 수도 있어요.'); }
  }
  const models = findModels(tier, search).sort((a, b) => {
    const rank = (id: string) => { const i = fresh ? recommendation?.modelIds.indexOf(id) ?? -1 : -1; return i < 0 ? 99 : i; };
    return rank(a.id) - rank(b.id);
  });
  return <PlanSurface><SafeAreaView style={s.safe}><StatusBar style={isDark?"light":"dark"}/><KeyboardAvoidingView style={s.shell} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
    <View style={s.top}><Pressable accessibilityRole="button" accessibilityLabel="이전 화면" onPress={back} style={s.back}><Text style={s.backText}>‹</Text></Pressable><View style={s.topTools}><Pressable accessibilityRole="button" accessibilityLabel="기능 안내" onPress={() => setHelp(true)} style={s.tool}><Text style={s.toolText}>···</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="홈으로 닫기" onPress={exit} style={s.tool}><Text style={s.toolText}>✕</Text></Pressable></View></View>
    <View style={s.connection}><Text style={s.small}>{!loaded ? '연결 정보 확인 중…' : config ? '● Gemini 연결됨' : 'Gemini 연결이 필요해요'}</Text><Pressable accessibilityRole="button" accessibilityLabel="Gemini 연결 설정" disabled={!!busy || !loaded} style={s.tool} onPress={() => setSettings(true)}><Text style={s.toolText}>{config ? '연결 관리' : 'Gemini 연결'}</Text></Pressable></View>
    <ScrollView key={screen} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets>
      {screen === 'input' && <>
        <Text style={s.title}>내 질문 다듬기</Text><Text style={s.lead}>어떻게 질문할까요?</Text>
        <View style={s.inputGap}/>
        <View style={[s.card,s.inputCard]}><TextInput accessibilityLabel="나의 질문" placeholder="학교 발표용 재활용 방법 3개 추천좀" placeholderTextColor={c.placeholder} value={input} editable={!busy} onChangeText={setInput} multiline maxLength={MAX_PROMPT} style={s.input}/><Text style={s.counter}>{input.length.toLocaleString()} / {MAX_PROMPT.toLocaleString()}</Text></View>
        <View style={s.row}><View style={s.chip}><Text style={s.chipText}>Gemini AI 다듬기</Text></View><Pressable accessibilityRole="button" accessibilityLabel="예시 넣기" disabled={!!busy} style={s.tool} onPress={() => setInput(SCHOOL_EXAMPLE)}><Text style={s.small}>예시 넣기</Text></Pressable></View>
        <Text style={[s.body,{marginTop:14}]}>평소 쓰는 질문을 입력하세요.{ '\n'}기존 의도를 다듬은 개선안과{ '\n'}조건을 추가한 예시를 볼 수 있어요.</Text>
        <Text style={s.small}>버튼을 누르면 질문을 Google Gemini로 보내요. 연결한 계정의 API 한도·요금이 적용돼요.</Text>
      </>}

      {screen === 'result' && result && <>
        <Text style={s.title}>개선 결과</Text>
        <View style={s.tabs}>{([{ id: 'improved', title: '개선안' }, { id: 'expanded', title: '확장 예시' }] as const).map(tab => <Pressable key={tab.id} accessibilityRole="tab" disabled={!!busy} accessibilityState={{ selected: variant === tab.id }} style={[s.tab, variant === tab.id && s.tabSelected]} onPress={() => { setVariant(tab.id); setEditing(false); setTip(null); }}><Text style={[s.tabText, variant === tab.id && s.tabTextSelected]}>{tab.title}</Text></Pressable>)}</View>
        <Text style={[s.lead,{marginTop:20,marginBottom:14}]}>{variant === 'improved' ? 'AI가 질문을 다듬었어요' : '이렇게 더 구체화해보세요'}</Text>
        <View style={s.card}>
          {variant === 'expanded' && !editedExpansion && <View style={s.wrap}>{result.tips.map((item, index) => <Chip key={index} title={item.phrase} selected={tip === index} onPress={() => setTip(tip === index ? null : index)}/>)}</View>}
          {editing ? <TextInput accessibilityLabel="최종 문장 편집" value={currentText} editable={!busy} onChangeText={variant === 'improved' ? setImproved : setExpanded} multiline maxLength={MAX_PROMPT} autoFocus style={[s.input, s.resultInput]}/> : <Text selectable style={s.quote}>{currentText || '문장이 비어 있어요. 수정 버튼으로 입력해 주세요.'}</Text>}
          <View style={s.tools}><Pressable accessibilityRole="button" onPress={() => { setEditing(!editing); Keyboard.dismiss(); }} style={s.tool}><Text style={s.toolText}>{editing ? '✓ 수정 완료' : '✎ 수정'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="결과 문장 복사" disabled={!currentText.trim()} onPress={() => void copy(currentText)} style={s.tool}><Text style={s.toolText}>▣ 복사</Text></Pressable></View>
        </View>
        {variant === 'improved' ? <View style={s.notice}><Text style={s.label}>이렇게 바꿨어요</Text><Text style={s.body}>{improved === result.improved ? result.explanation : '직접 수정한 문장이에요. 목적과 조건이 원래 의도에 맞는지 확인해 주세요.'}</Text></View> : <>
          {tip !== null && result.tips[tip] && !editedExpansion && <View style={s.tip}><Text style={s.label}>{result.tips[tip].title}</Text><Text style={s.body}>{result.tips[tip].explanation}</Text></View>}
          <Text style={s.body}>{editedExpansion ? '직접 편집한 문장에는 기존 구절 팁을 표시하지 않아요.' : '구절을 누르면 AI가 설명한 작성 팁을 볼 수 있어요. 추가한 조건은 내 상황에 맞게 바꿔주세요.'}</Text>
        </>}
        <Text style={s.small}>작성: {improvementModel} · 숫자·대상·제외 조건이 맞는지 확인해 주세요.</Text><Text selectable style={s.small}>원문: {result.original}</Text>
        <Text style={[s.small,{marginTop:12}]}>필요하면 문장을 직접 수정하세요.{ '\n'}수정한 최종 문장으로 모델을 추천해요.</Text>
        {currentText.length > MAX_PROMPT && <Text accessibilityRole="alert" style={s.error}>추가 조건을 포함하면 4,000자를 넘어요. 문장을 줄인 뒤 추천받아 주세요.</Text>}
      </>}

      {screen === 'models' && <>
        <Text style={s.title}>AI 모델 추천</Text>
        <View style={s.tabs}>{([{ id: 'direct', title: '직접 입력' }, { id: 'imported', title: '개선문 가져오기' }] as const).map(tab => <Pressable key={tab.id} accessibilityRole="tab" disabled={!!busy} accessibilityState={{ selected: source === tab.id }} style={[s.tab, source === tab.id && s.tabSelected]} onPress={() => { setSource(tab.id); setRecommendation(null); }}><Text style={[s.tabText, source === tab.id && s.tabTextSelected]}>{tab.title}</Text></Pressable>)}</View>
        {source === 'imported' && !imported && <View style={s.notice}><Text style={s.body}>아직 가져올 개선문이 없어요. 먼저 질문을 다듬어보세요.</Text><Action title="질문 다듬으러 가기" secondary onPress={() => go('input')}/></View>}
        <View style={s.promptRow}><TextInput accessibilityLabel="모델을 추천받을 문장" placeholder="아래 글을 쉬운 말로 세 문장으로 요약해줘." placeholderTextColor={c.placeholder} value={modelPrompt} editable={!busy} onChangeText={source === 'direct' ? setDirect : setImported} multiline maxLength={MAX_PROMPT} style={s.promptInput}/><Pressable accessibilityRole="button" accessibilityLabel="이 문장으로 추천받기" disabled={!modelPrompt.trim() || !!busy || !loaded} style={s.send} onPress={() => void evaluate(modelPrompt)}><Text style={s.sendText}>{busy === 'recommend' ? '…' : '➜'}</Text></Pressable></View>
        {fresh && recommendation ? <View accessibilityLiveRegion="polite" style={s.recommendation}><Text style={s.recommendationText}>AI 추천 · {recommendation.tier}</Text><Text style={s.body}>{recommendation.reason}</Text><Text style={s.small}>분석한 작업: {recommendation.task} · {recommendationModel}</Text></View> : <Text style={s.small}>{busy === 'recommend' ? 'Gemini가 질문에 맞는 모델을 고르고 있어요…' : modelPrompt.trim() ? '화살표를 누르면 이 문장을 AI가 분석해 추천해요.' : '질문을 입력하고 화살표를 눌러주세요.'}</Text>}
        <Text style={s.small}>{TIER_NOTE}</Text><View style={s.tierList}>{TIERS.map(item => <Pressable accessibilityRole="radio" accessibilityState={{ checked: tier === item.id }} key={item.id} style={[s.tier, tier === item.id && s.tierSelected]} onPress={() => { setTier(item.id); setSearch(''); }}><Text style={s.tierName}>{item.id}</Text><Text style={s.tierDescription}>{item.subtitle}</Text><Text style={s.arrow}>{fresh && recommendation?.tier === item.id ? '추천' : '›'}</Text></Pressable>)}</View>
        <View style={s.catalog}><View style={s.handle}/><View style={s.row}><Text style={s.lead}>{tier} 모델</Text><Text style={s.small}>{models.length}개</Text></View><TextInput accessibilityLabel="모델명·제공사 검색" placeholder="모델명·제공사 검색" placeholderTextColor={c.placeholder} value={search} onChangeText={setSearch} style={s.search}/>
          {models.map(item => <Pressable accessibilityRole="button" accessibilityLabel={`${item.name} 상세 보기`} disabled={!!busy} key={item.id} style={s.modelRow} onPress={() => { setModel(item); go('detail'); }}><View style={s.modelInfo}><Text style={s.modelName}>{item.name}</Text><Text style={s.small}>{item.provider}{fresh && recommendation?.modelIds.includes(item.id) ? ' · AI 추천' : ''}</Text></View><Text style={s.arrow}>›</Text></Pressable>)}
          {!models.length && <View style={s.notice}><Text style={s.body}>이 등급에서 일치하는 모델이 없어요.</Text><Action title="검색 지우기" secondary onPress={() => setSearch('')}/></View>}
        </View>
        <Text style={s.small}>공식 목록 확인: {CATALOG_CHECKED_AT}. Gemini가 이 후보 안에서 추천해요. 실제 이용 가능 여부는 서비스·계정에 따라 달라요.</Text>
      </>}

      {screen === 'detail' && model && <>
        <Text style={s.title}>모델 상세</Text><View style={s.wrap}><View style={s.chip}><Text style={s.chipText}>{model.tier} · AIMI 추천 분류</Text></View></View>
        <Text style={s.modelTitle}>{model.name}</Text><Text style={s.body}>{model.provider}</Text>
        <View style={s.notice}><Text style={s.lead}>이럴 때 고려해 보세요</Text><Text style={s.body}>{model.note}</Text></View>
        <View style={s.notice}><Text style={s.lead}>선택할 때 알아두세요</Text><Text style={s.body}>{TIER_NOTE}</Text><Text style={s.small}>추천 목록은 다른 서비스에서 사용할 모델을 고르는 데 도움을 줘요. 이 모델을 선택한다고 앱의 Gemini 연결 모델이 바뀌거나 새 API 호출이 실행되지는 않아요.</Text></View>
        <View style={s.notice}><Text style={s.small}>공식 모델명·제공 정보 확인: {CATALOG_CHECKED_AT}</Text><Text style={s.small}>가격·한도·이용 조건은 공식 안내에서 확인해 주세요. 속도·성능·에너지 절약량을 직접 측정한 목록은 아니에요.</Text>
          <Pressable accessibilityRole="link" accessibilityLabel="공식 모델 안내 열기" style={s.tool} onPress={() => void Linking.openURL(model.source).catch(() => setError('공식 안내를 열지 못했어요. 인터넷 연결을 확인해 주세요.'))}><Text style={s.toolText}>공식 모델 안내 ↗</Text></Pressable>
        </View>
        {!modelPrompt.trim() && <Text style={s.small}>추천 화면에 질문을 입력하면 문장을 복사할 수 있어요.</Text>}
      </>}
      {!!busy && <View accessibilityLiveRegion="polite" style={s.notice}><Text style={s.body}>{busy === 'improve' ? '문장 다듬는 중…' : 'Gemini 응답을 기다리고 있어요…'}</Text><Action title="요청 취소" secondary onPress={() => { cancelPending(); setMessage('요청 대기를 취소했어요. 이미 전송된 요청은 Google에서 처리될 수 있어요.'); }}/></View>}
      {!!message && <View accessibilityLiveRegion="polite" style={s.tip}><Text style={s.body}>{message}</Text></View>}
      {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
    </ScrollView>
    {screen !== 'models' && <View style={s.bottom}>{screen === 'input' ? <Action title={busy === 'improve' ? '문장 다듬는 중…' : '개선안·예시 보기'} disabled={!input.trim() || !!busy || !loaded} onPress={() => void improve()}/> : screen === 'result' ? <Action title="모델 추천받기" disabled={!currentText.trim() || currentText.length > MAX_PROMPT || !!busy} onPress={toModels}/> : <View style={s.metricRow}><View style={s.grow}><Action title="다른 모델 보기" secondary onPress={() => go('models')}/></View><View style={s.grow}><Action title="문장 복사" disabled={!modelPrompt.trim()} onPress={() => void copy(modelPrompt)}/></View></View>}</View>}
    <Modal transparent visible={help} animationType="fade" onRequestClose={() => setHelp(false)}><View style={s.shade}><View style={s.help}><Text style={s.lead}>Gemini AI 기능 안내</Text><Text style={s.body}>연결한 본인 키로 Google Gemini를 호출해요. AI가 개선안·확장 예시·작성 팁을 만들고, 후보 모델 중 적합한 등급과 모델을 추천해요.</Text><Text style={s.body}>버튼을 누를 때만 요청해요. 오류가 나면 자동 재호출하거나 규칙 결과로 대체하지 않아요. 질문·응답은 기기에 영구 저장하지 않지만 Google의 데이터 처리 정책이 적용돼요.</Text><Action title="확인" onPress={() => setHelp(false)}/></View></View></Modal>
    {settings && <GeminiSettings current={config} onSave={value => { setConfig(value); setError(''); setMessage(value ? 'Gemini 연결을 저장했어요. 질문을 보내보세요.' : '저장한 키를 삭제했어요.'); }} onClose={() => setSettings(false)}/>}
  </KeyboardAvoidingView></SafeAreaView></PlanSurface>;
}

const createStyles=(c:ThemeColors)=>StyleSheet.create({
  safe: { flex: 1, backgroundColor: 'transparent' }, shell: { flex: 1 },
  connection: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 25, minHeight: 36 },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, height: 48 }, back: { minWidth: 44, minHeight: 44, justifyContent: 'center' }, backText: { color: c.ink, fontSize: 31 }, topTools: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.paper, borderRadius: 25 },
  content: { paddingHorizontal: 25, paddingTop: 6, paddingBottom: 22, gap: 12, flexGrow: 1 }, title: { fontSize: 19, fontWeight: '800', color: c.ink }, lead: { fontSize: 17, fontWeight: '700', color: c.ink, lineHeight: 25 }, body: { fontSize: 13, lineHeight: 22, color: c.muted }, small: { fontSize: 11, lineHeight: 18, color: c.muted }, label: { color: c.ink, fontSize: 13, lineHeight: 21, fontWeight: '700' },
  inputGap: { height: 25 }, inputCard: { minHeight: 215 }, card: { borderWidth:1,borderColor:c.line,backgroundColor: c.paper, borderRadius: 16, padding: 17, gap: 12 }, input: { minHeight: 160, flex: 1, color: c.ink, fontSize: 14, lineHeight: 25, textAlignVertical: 'top', padding: 0 }, resultInput: { minHeight: 150, borderBottomWidth: 1, borderColor: c.line }, counter: { fontSize: 10, color: c.muted, textAlign: 'right' }, quote: { fontSize: 15, lineHeight: 27, color: c.ink, minHeight: 100 },
  notice: { backgroundColor: c.paper, borderRadius: 15, padding: 15, gap: 7 }, tip: { backgroundColor: c.selected, borderRadius: 15, padding: 16, gap: 8 },
  action: { minHeight: 49, paddingHorizontal: 14, paddingVertical: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary, borderRadius: 14 }, secondary: { backgroundColor: c.secondary }, actionText: { color: c.primaryText, fontSize: 14, fontWeight: '700', textAlign: 'center' }, bottom: { paddingHorizontal: 25, paddingTop: 10, paddingBottom: 24 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }, wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 }, chip: { backgroundColor: c.secondary, borderRadius: 20, paddingVertical: 5, paddingHorizontal: 12, maxWidth: '100%' }, chipSelected: { backgroundColor: c.selected }, chipText: { fontSize: 10, fontWeight: '700', color: c.green, lineHeight: 17 },
  tabs: { flexDirection: 'row', gap: 10 }, tab: { flex: 1, justifyContent: 'center', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 10, borderWidth: 1, borderColor: 'transparent', backgroundColor: c.paper }, tabSelected: { backgroundColor: c.selected, borderColor: c.green }, tabText: { color: c.muted, fontSize: 12 }, tabTextSelected: { color: c.ink, fontWeight: '700' },
  tools: { flexDirection: 'row', justifyContent: 'flex-end', gap: 4 }, tool: { paddingHorizontal: 9, minHeight: 40, justifyContent: 'center' }, toolText: { color: c.green, fontSize: 12, fontWeight: '600' }, field: { backgroundColor: c.input, borderRadius: 10, padding: 12, color: c.ink, fontSize: 14, minHeight: 46 },
  promptRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.input, padding: 10, borderRadius: 12, gap: 10 }, promptInput: { flex: 1, minHeight: 30, maxHeight: 130, color: c.ink, fontSize: 12, lineHeight: 20, padding: 2 }, send: { width: 30, height: 30, alignItems: 'center', justifyContent: 'center', borderRadius: 20, backgroundColor: c.primary }, sendText: { color: c.primaryText, fontSize: 19 }, recommendation: { gap: 5, marginTop: 12 }, recommendationText: { color: c.green, fontSize: 12, lineHeight: 20, fontWeight: '700' },
  tierList: { gap: 7 }, tier: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.paper, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: 'transparent', gap: 8, minHeight: 44 }, tierSelected: { borderColor: c.green, backgroundColor: c.selected }, tierName: { color: c.ink, fontSize: 16, fontWeight: '700', width: 76 }, tierDescription: { color: c.muted, fontSize: 11, flex: 1 }, arrow: { color: c.primary, fontSize: 11, fontWeight: '700' },
  catalog: { borderWidth:1,borderColor:c.line,backgroundColor: c.paper, borderRadius: 20, padding: 16, gap: 6 }, handle: { alignSelf: 'center', width: 34, height: 3, borderRadius: 2, backgroundColor: c.line, marginBottom: 6 }, search: { borderBottomWidth: 1, borderColor: c.line, paddingVertical: 10, fontSize: 11, color: c.ink, minHeight: 38 }, modelRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 7, paddingHorizontal: 4, minHeight: 44 }, modelInfo: { flex: 1 }, modelName: { fontSize: 13, color: c.ink, fontWeight: '600' }, modelTitle: { fontSize: 22, fontWeight: '800', color: c.ink, lineHeight: 30, marginTop: 8 },
  metricRow: { flexDirection: 'row', gap: 10 }, grow: { flex: 1 }, metric: { flex: 1, backgroundColor: c.paper, padding: 15, borderRadius: 14, gap: 5 }, metricValue: { color: c.green, fontSize: 21, fontWeight: '800' }, error: { color: c.error, fontSize: 13, lineHeight: 22 }, shade: { flex: 1, backgroundColor: c.shade, alignItems: 'center', justifyContent: 'center', padding: 28 }, help: { backgroundColor: c.modal, borderRadius: 22, padding: 24, gap: 20, maxWidth: 380 },
});
