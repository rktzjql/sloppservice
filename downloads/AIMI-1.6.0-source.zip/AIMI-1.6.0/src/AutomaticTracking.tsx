import React,{useEffect,useState} from 'react';
import {AppState,PermissionsAndroid,Platform,Pressable,StyleSheet,Text,View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AiUsage from '../modules/ai-usage';
import {sessionsFromEvents,type Session} from './sessions';
const CONSENT_KEY='@slopstop/usage-consent/v1';
export default function AutomaticTracking({onRecord,recordedIds}:{onRecord:(session:Session)=>void;recordedIds:Set<string>}){
 const [since,setSince]=useState<number|null>(null);
 const [loaded,setLoaded]=useState(false);const [error,setError]=useState('');
 const [monitoring,setMonitoring]=useState(false);
 const [permitted,setPermitted]=useState(false);const [sessions,setSessions]=useState<Session[]>([]);
 const [busy,setBusy]=useState(false);const [revision,setRevision]=useState(0);const [checked,setChecked]=useState<Date|null>(null);
 const available=Platform.OS==='android'&&Number(Platform.Version)>=26&&AiUsage!==null;
 useEffect(()=>{let active=true;AsyncStorage.getItem(CONSENT_KEY).then(raw=>{if(!active)return;const value=raw===null?null:Number(raw);if(value!==null&&(!Number.isFinite(value)||value<=0))throw Error();setSince(value);setLoaded(true)}).catch(()=>{if(active)setError('자동 기록 설정을 읽지 못했어요. 앱을 다시 실행해 주세요.')});return()=>{active=false}},[]);
 useEffect(()=>{
  if(!available||!loaded||since===null){setSessions([]);return}
  let active=true;let querying=false;
  async function sync(){if(querying)return;querying=true;setBusy(true);try{
   const permission=await AiUsage!.hasPermission();const running=await AiUsage!.isMonitoring();if(active)setMonitoring(running);if(!active)return;setPermitted(permission);
   if(!permission){setSessions([]);setError('사용 정보 접근 권한을 허용해 주세요.');return}
   const events=await AiUsage!.queryEvents(since!);if(!active)return;
   setSessions(sessionsFromEvents(events,since!));setChecked(new Date());setError('');
  }catch{if(active)setError('사용 기록을 읽지 못했어요. 권한을 확인한 뒤 다시 시도해 주세요.')}finally{querying=false;if(active)setBusy(false)}}
  void sync();const subscription=AppState.addEventListener('change',state=>{if(state==='active')void sync()});
  const timer=setInterval(()=>{AiUsage!.isMonitoring().then(value=>{if(active)setMonitoring(value)}).catch(()=>{})},3000);
  return()=>{active=false;subscription.remove();clearInterval(timer)};
 },[available,loaded,since,revision]);
 async function enable(){setBusy(true);try{const start=Date.now();await AsyncStorage.setItem(CONSENT_KEY,String(start));setSince(start);setError('');await AiUsage!.openSettings()}catch{setError('설정을 열지 못했어요. Android 설정에서 이 앱의 사용 정보 접근을 허용해 주세요.')}finally{setBusy(false)}}
 async function disable(){setBusy(true);try{await AiUsage!.stopMonitoring();await AiUsage!.clearReminders();setMonitoring(false);await AsyncStorage.removeItem(CONSENT_KEY);setSince(null);setSessions([]);setChecked(null);setError('')}catch{setError('설정을 저장하지 못했어요. 다시 시도해 주세요.')}finally{setBusy(false)}}
 async function toggleMonitoring(){setBusy(true);try{
 if(monitoring){await AiUsage!.stopMonitoring();setMonitoring(false)}else{
 if(Number(Platform.Version)>=33){const result=await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);if(result!==PermissionsAndroid.RESULTS.GRANTED){setError('사용 후 알림을 보내려면 알림 권한이 필요해요. Android 앱 설정에서 허용해 주세요.');return}}
 await AiUsage!.startMonitoring();setError('');
 }
 }catch{setError('감지를 시작하거나 중지하지 못했어요. 사용 정보 접근과 알림 권한을 확인해 주세요.')}finally{setBusy(false)}}
 async function settings(){try{await AiUsage!.openSettings()}catch{setError('Android 설정 → 앱 → 특별한 앱 접근 → 사용 정보 접근에서 변경해 주세요.')}}
 return <View style={s.card}><Text style={s.title}>기존 AI 앱 자동 기록</Text><Text style={s.copy}>ChatGPT · Gemini · Claude</Text>
 {!available?<><Text style={s.copy}>Expo Go에서는 자동 기록을 사용할 수 없어요. Android 8 이상이 필요해요. 사용 정보 접근 기능이 포함된 Android 개발 빌드를 설치하면 연결할 수 있어요.</Text><View style={s.note}><Text style={s.copy}>현재 연결되지 않음 · 실제 사용 데이터를 표시하지 않아요.</Text></View></>:<>
 <Text style={s.copy}>동의 이후의 앱 사용 시간을 이 기기에서만 확인해요. 대화 내용과 질문 횟수는 읽지 않아요. 앱에 돌아오거나 새로고침할 때 최근 7일 이내의 완료된 세션을 불러와요.</Text>
 {since===null?<Action label="동의하고 사용 정보 접근 설정" onPress={()=>void enable()} disabled={!loaded||busy}/>:<>
 {permitted&&<View style={s.note}><Text style={s.title}>{monitoring?'● 실시간 감지 실행 중':'사용 후 질문 횟수 알림'}</Text><Text style={s.copy}>감지를 켜면 상시 알림을 표시하고 약 5초마다 앱 사용을 확인해요. 사용이 끝나면 질문 횟수 입력 알림을 보내요. 절전 설정에 따라 늦어질 수 있어요.</Text><Action label={monitoring?'실시간 감지 중지':'알림 허용하고 실시간 감지 시작'} onPress={()=>void toggleMonitoring()} disabled={busy}/><Text style={s.small}>휴대폰 재시작·강제 종료 후에는 직접 다시 켜 주세요. 상시 알림에서도 중지할 수 있어요.</Text></View>}
 <Text style={s.state}>{permitted?'● 사용 정보 접근 허용됨':'○ 사용 정보 접근 권한 필요'}</Text>
 <Action label={busy?'확인 중…':'사용 기록 새로고침'} onPress={()=>setRevision(v=>v+1)} disabled={busy}/>
 <Action label="Android 권한 설정 열기" onPress={()=>void settings()}/>
 {!!checked&&<Text style={s.small}>마지막 확인 {checked.toLocaleTimeString('ko-KR')}</Text>}
 {!sessions.length&&permitted&&<Text style={s.copy}>아직 감지된 세션이 없어요. AI 앱을 사용한 뒤 이 앱으로 돌아와 주세요. 기기에서 기록을 제공하지 않으면 표시되지 않을 수 있어요.</Text>}
 {sessions.slice(0,20).map(session=><View key={session.id} style={s.session}><View><Text style={s.title}>{session.provider}</Text><Text style={s.small}>{new Date(session.startedAt).toLocaleString('ko-KR')}</Text></View><View style={{gap:8}}><Text style={s.state}>{Math.max(1,Math.round((session.endedAt-session.startedAt)/1000))}초</Text><Action label={recordedIds.has(session.id)?'입력 완료':'질문 횟수 입력'} disabled={recordedIds.has(session.id)} onPress={()=>onRecord(session)}/></View></View>)}
 {sessions.length>20&&<Text style={s.small}>최근 20개 세션을 표시하고 있어요.</Text>}
 <Text style={s.small}>앱 내부 화면 이동으로 세션이 나뉠 수 있어요. Gemini가 Google 앱·시스템 도우미로 실행되거나 브라우저를 사용하면 감지되지 않을 수 있어요. 이 시간은 질문 수 또는 에너지 사용량이 아니에요.</Text>
 <Action label="자동 기록 중지 · 연결 설정 삭제" onPress={()=>void disable()} disabled={busy}/>
 <Text style={s.small}>중지하면 이 앱의 조회를 멈춰요. Android 권한 자체는 위 권한 설정에서 해제할 수 있어요.</Text>
 </>}
 </>}
 {!!error&&<Text accessibilityRole="alert" style={s.error}>{error}</Text>}
 </View>
}
function Action({label,onPress,disabled=false}:{label:string;onPress:()=>void;disabled?:boolean}){return <Pressable accessibilityRole="button" onPress={onPress} disabled={disabled} style={[s.button,disabled&&{opacity:0.5}]}><Text style={s.state}>{label}</Text></Pressable>}
const s=StyleSheet.create({card:{padding:22,borderRadius:24,backgroundColor:'#FFFFFF',gap:14},title:{fontSize:16,fontWeight:'700',color:'#29323B'},copy:{fontSize:14,lineHeight:23,color:'#53616C'},small:{fontSize:12,lineHeight:20,color:'#75808B'},button:{backgroundColor:'#E4F2EA',padding:16,borderRadius:12,alignItems:'center'},state:{color:'#087F50',fontWeight:'700'},error:{color:'#B33B3B',fontSize:13,lineHeight:20},note:{backgroundColor:'#F2F4F5',padding:14,borderRadius:12},session:{flexDirection:'row',justifyContent:'space-between',gap:8,paddingVertical:10,borderBottomWidth:1,borderBottomColor:'#EDF0F2'}});
