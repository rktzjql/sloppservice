import { TRACKED_APPS } from './sessions';
export function parseReminder(url: string): {sessionId:string;start:number;end:number} | null {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'slopstop:' || parsed.hostname !== 'record') return null;
    const pkg = parsed.searchParams.get('package') ?? '';
    const start = Number(parsed.searchParams.get('start'));
    const end = Number(parsed.searchParams.get('end'));
    if (!Object.hasOwn(TRACKED_APPS,pkg) || !Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start<=0 || end<=start || end>Date.now()+1000) return null;
    return {sessionId:`${pkg}:${start}`,start,end};
  } catch { return null; }
}
