import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
export type ThemeMode = 'light' | 'night';
const light = {
  bg: '#F2F1EB', paper: '#FFFFFF80', ink: '#202C28', muted: '#40564A', green: '#315F4C', line: '#FFFFFFB3', lime: '#C7D9A8',
  input: '#F7F8F1D9', selected: '#A8C78980', primary: '#315F4C', primaryText: '#FFFFFF', secondary: '#E2EBD7B3', error: '#9D3838',
  hero: '#789B58C9', heroText: '#20372A', nav: '#FFFFFF99', modal: '#F2F3EB', shade: '#10231C66', accent: '#355F4B', placeholder: '#68796B',
};
export type ThemeColors = typeof light;
const night: ThemeColors = {
  bg: '#1C1C1E', paper: '#FFFFFF0D', ink: '#F4F6F9', muted: '#D3DEEA', green: '#AECBE4', line: '#FFFFFF24', lime: '#3B5688',
  input: '#0B142075', selected: '#335CA66B', primary: '#AACBE4', primaryText: '#0A1930', secondary: '#FFFFFF12', error: '#FFB3AD',
  hero: '#294C8252', heroText: '#F5F8FE', nav: '#101828B3', modal: '#1D2737', shade: '#030817BB', accent: '#C8E0F3', placeholder: '#9DAFC3',
};
const KEY = '@aimi/theme/v1';
const ThemeContext = createContext({ mode: 'light' as ThemeMode, colors: light, isDark: false, setMode: (_mode: ThemeMode) => {}, storageError: false });
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, update] = useState<ThemeMode>('light');
  const [storageError, setStorageError] = useState(false);
  const touched = useRef(false); const writes = useRef(Promise.resolve());
  useEffect(() => { let alive = true; AsyncStorage.getItem(KEY).then(saved => { if (alive && !touched.current && (saved === 'light' || saved === 'night')) update(saved); }).catch(() => { if (alive) setStorageError(true); }); return () => { alive = false; }; }, []);
  function setMode(next: ThemeMode) {
    touched.current = true; update(next); setStorageError(false);
    writes.current = writes.current.then(() => AsyncStorage.setItem(KEY, next)).catch(() => setStorageError(true));
  }
  return <ThemeContext.Provider value={{ mode, colors: mode === 'night' ? night : light, isDark: mode === 'night', setMode, storageError }}>{children}</ThemeContext.Provider>;
}
export function useTheme() { return useContext(ThemeContext); }
export const lightColors = light;
