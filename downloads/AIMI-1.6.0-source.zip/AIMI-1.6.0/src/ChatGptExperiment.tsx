import {useTheme,type ThemeColors} from './theme/Theme';
import React,{useMemo,useEffect,useState} from 'react';
import {Alert,AppState,Platform,Pressable,Share,StyleSheet,Switch,Text,View} from 'react-native';
import AiUsage,{type ExperimentStatus,type PromptPreview} from '../modules/ai-usage';
import {recordingStatus,signalHint} from './recordingStatus';
import type {UsageRecord} from './records';
export default function ChatGptExperiment({automaticRecords,assumeText,onAssumeText}:{automaticRecords:UsageRecord[];assumeText:boolean;onAssumeText:(v:boolean)=>void}){
 const {colors:c,isDark}=useTheme(); const s=useMemo(()=>createStyles(c),[c]);
 const [status,setStatus]=useState<ExperimentStatus|null>(null);const [error,setError]=useState('');const [busy,setBusy]=useState(false);
 const [preview,setPreview]=useState<PromptPreview|null>(null);
 const available=Platform.OS==='android'&&AiUsage!==null;
 useEffect(()=>{if(!available)return;let alive=true;let reading=false;
 const refresh=async()=>{if(reading||AppState.currentState!=='active')return;reading=true;try{const value=await AiUsage!.experimentStatus();const content=value.promptPreviewConsent?await AiUsage!.promptPreview():null;if(alive&&AppState.currentState==='active'){setStatus(value);setPreview(content)}}catch{if(alive)setError('자동 기록 상태를 불러오지 못했어요.')}finally{reading=false}};
 void refresh();const timer=setInterval(()=>void refresh(),1500);const sub=AppState.addEventListener('change',v=>{if(v==='active')void refresh();else setPreview(null)});return()=>{alive=false;clearInterval(timer);sub.remove()}},[available]);
 async function action(kind:'connect'|'resume'|'pause'|'disconnect'|'reconnect'|'inputOn'|'inputOff'|'diagnose'|'cancelDiagnostic'|'previewOn'|'previewOff'|'previewClear'){setBusy(true);setError('');try{if(kind==='previewOn'||kind==='previewOff'){setPreview(null);await AiUsage!.setPromptPreviewConsent(kind==='previewOn')}if(kind==='previewClear'){setPreview(null);await AiUsage!.clearPromptPreview()}if(kind==='pause'||kind==='disconnect')setPreview(null);if(kind==='diagnose')await AiUsage!.startScreenDiagnostic();if(kind==='cancelDiagnostic')await AiUsage!.cancelScreenDiagnostic();if(kind==='reconnect')await AiUsage!.reconnectExperiment();if(kind==='inputOn'||kind==='inputOff')await AiUsage!.setInputSignalConsent(kind==='inputOn');if(kind==='connect')await AiUsage!.consentToExperiment();if(kind==='resume')await AiUsage!.startExperiment();if(kind==='pause')await AiUsage!.stopExperiment();if(kind==='disconnect')await AiUsage!.clearExperiment();setStatus(await AiUsage!.experimentStatus())}catch{setError('접근성 설정에서 ‘AIMI · AI 자동 기록’을 켜 주세요.')}finally{setBusy(false)}}
 const button=(label:string,onPress:()=>void)=><Pressable accessibilityRole="button" disabled={busy} style={s.button} onPress={onPress}><Text style={s.green}>{label}</Text></Pressable>;
 const connect=()=>Alert.alert('전송을 자동 기록할까요?','ChatGPT·Gemini의 전송 클릭 또는 전송 가능 → 생성 중지 버튼 변화를 감지합니다. 기본 감지는 UI 구조와 버튼 정보만 확인해요. 입력창의 비어 있음 상태를 이용하는 보완 감지는 아래에서 별도로 켤 수 있어요. 앱 이름·시각·감지 방식을 저장하며 상태 변화는 추정 감지로 표시합니다. Android가 접근성 서비스를 연결하면 별도 시작 버튼 없이 기록하며, 기록은 삭제하기 전까지 기기에 남습니다.',[{text:'취소',style:'cancel'},{text:'동의하고 연결',onPress:()=>void action('connect')}]);
 return <View style={s.card}><Text style={s.title}>ChatGPT · Gemini 자동 기록</Text><Text style={s.copy}>전송 클릭과 버튼 상태 변화로 질문 전송을 감지해요. 인식한 기록은 알림 없이 영수증에 쌓이며, 버튼 상태로 추정한 기록은 따로 표시해요.</Text>
 {!available?<Text style={s.copy}>Android APK에서 사용할 수 있어요.</Text>:<>
 {(!status?.consent||!status.connected)?button('자동 기록 연결',connect):button(status.enabled?'자동 기록 잠시 끄기':'자동 기록 다시 켜기',()=>void action(status.enabled?'pause':'resume'))}
 <Text style={s.green}>{recordingStatus(status)}</Text>
 {!status?.connected&&status?.consent&&button('끊긴 연결 설정 열기',()=>void action('reconnect'))}
 <View style={s.metrics}><Text style={s.title}>ChatGPT 입력 문장·글자 수</Text>
 <Text style={s.copy}>ChatGPT가 접근성에 공개한 입력창에서 최근 문장을 읽어 보여줘요. 검색창 등과 구분할 수 있을 때만 읽으며, 입력창 정보가 없으면 표시할 수 없어요.</Text>
 <Switch accessibilityLabel="ChatGPT 입력 문장 미리보기" value={status?.promptPreviewConsent??false} disabled={busy} onValueChange={value=>value?Alert.alert('입력 문장과 글자 수를 확인할까요?','ChatGPT 입력창의 원문을 읽어 최근 문장 하나를 이 앱에 표시합니다. 원문은 휴대폰 메모리에 최대 10분 보관하며 파일·서버·AI API·감지 상태 공유에는 넣지 않습니다. 검색창·비밀번호·답변·다른 앱의 입력은 수집하지 않도록 입력창 구조를 확인합니다. 전송 완료를 보장하지 않습니다. 끄기·지우기·자동 기록 중지 시 미리보기를 삭제합니다.',[{text:'취소',style:'cancel'},{text:'동의하고 켜기',onPress:()=>void action('previewOn')}]):void action('previewOff')}/>
 <Text style={s.copy}>{status?.promptPreviewConsent?'켜짐 · ChatGPT 새 대화에 테스트 문장을 입력하고 돌아와 보세요.':'꺼짐 · 원문 미리보기는 별도 동의 후 사용할 수 있어요.'}</Text>
 {status?.promptPreviewConsent&&<>{preview?.text?<>
 <Text style={s.title}>{preview.countLimited?'최소 ':''}{preview.characters.toLocaleString()}자 · 마지막으로 읽은 입력문</Text>
 <Text style={s.copy}>{preview.signal==='click'?'전송 버튼 클릭 신호와 연결됨 · 서버 수신 미확인':preview.signal!=='none'?'전송 상태 변화로 추정 · 서버 수신 미확인':'초안 · 전송 여부 미확인'}{preview.inputState==='empty'?' · 이후 입력창 비움':''}</Text>
 <Text selectable style={[s.copy,{backgroundColor:c.input,padding:12,borderRadius:8}]}>{preview.text}</Text>
 {preview.truncated&&<Text style={s.copy}>긴 문장은 앞부분만 표시해요.</Text>}
 <Text style={s.copy}>공백·줄바꿈 포함. 이모지 조합은 여러 글자로 셀 수 있어요. {preview.ageSeconds}초 전 확인 · 이 내용은 감지 상태 공유에서 제외돼요.</Text>
 {button('미리보기 지우기',()=>void action('previewClear'))}
 </>:<Text style={s.copy}>아직 읽은 문장이 없어요. 자동 기록 연결을 켜고 ChatGPT의 새 대화 입력창에서 입력해 주세요. 10분이 지나거나 기록을 중지하면 문장은 지워져요.</Text>}</>}
 </View>
 <View style={s.metrics}><Text style={s.title}>입력 신호 보완 감지</Text><Text style={s.copy}>입력창이 비워지고 곧 답변 생성이 시작될 때 전송으로 추정해요. 글자를 쓰거나 지우는 것만으로는 기록하지 않아요.</Text>
 <Switch accessibilityLabel="입력 신호 보완 감지" value={status?.inputSignalConsent??false} onValueChange={value=>value?Alert.alert('입력 상태를 함께 확인할까요?','ChatGPT·Gemini의 입력창이 비어 있는지 확인하기 위해 접근성이 제공하는 입력 텍스트를 잠시 참조합니다. 내용은 저장·로그·전송하지 않고 비어 있음 상태만 사용해요. 답변 생성 시작 신호와 함께 전송을 추정하며 오인식·누락이 있을 수 있어요.',[{text:'취소',style:'cancel'},{text:'동의하고 켜기',onPress:()=>void action('inputOn')}]):void action('inputOff')} disabled={busy}/>
 <Text style={s.copy}>{status?.inputSignalConsent?'보완 감지 켜짐':'보완 감지 꺼짐'} · 입력 상태 확인 {status?.inputEvents??0}회 · {status?.inputState==='nonempty'?'작성 중':status?.inputState==='empty'?'입력창 비어 있음':'입력창 확인 대기'}</Text></View>
 {status?.connected&&button('접근성 설정 다시 열기',()=>void action('connect'))}
 <View style={s.metrics}><Text style={s.title}>30초 화면 정보 진단</Text>
 <Text style={s.copy}>진단 시작 후 5초 안에 ChatGPT로 이동하세요. 새 대화에서 짧은 테스트 문장을 입력하고 3초 기다린 뒤 전송해 주세요. 답변이 나오는 화면에서 10초 정도 기다렸다가 돌아오세요.</Text>
 <Text style={s.copy}>입력창·전송·생성 중지 버튼이 접근성에 보이는지 확인해요. 입력 내용의 비어 있음 확인은 위의 보완 감지를 켰을 때만 해요. 이 진단 결과에는 원문을 포함하지 않아요. 위의 입력 문장 미리보기는 별도 설정이에요.</Text>
 {status?.screenDiagnostic?.state==='running'||status?.screenDiagnostic?.state==='waiting'?<><Text style={s.green}>진단 진행 중 · 약 {status.screenDiagnostic.remainingSeconds}초 남음</Text>{button('화면 진단 취소',()=>void action('cancelDiagnostic'))}</>:button('30초 화면 진단 시작',()=>{if(!status?.connected||!status.enabled||!status.consent){setError('자동 기록을 연결하고 켠 뒤 진단을 시작해 주세요.');return}Alert.alert('화면 정보 진단','5초 뒤부터 30초 동안 ChatGPT·Gemini 화면의 요소 제공 여부만 확인합니다. 진단 횟수는 전송 횟수가 아니에요. 진단 결과에는 원문이나 화면 이미지를 포함하지 않습니다.',[{text:'취소',style:'cancel'},{text:'진단 시작',onPress:()=>void action('diagnose')}])})}
 {!!status?.screenDiagnostic&&status.screenDiagnostic.state!=='idle'&&<>
 <Text style={s.copy}>상태: {status.screenDiagnostic.state==='complete'?'완료':status.screenDiagnostic.state==='cancelled'?'중단됨':'진행 중'} · 확인 화면 {status.screenDiagnostic.samples.length}회</Text>
 <Text style={s.copy}>입력창 발견 {status.screenDiagnostic.editableSamples}회 · 입력 내용 참조 가능 {status.screenDiagnostic.readableSamples}회 · 내용 있음 {status.screenDiagnostic.nonemptySamples}회</Text>
 <Text style={s.copy}>전송 버튼 {status.screenDiagnostic.sendSamples}회 · 생성 중지 버튼 {status.screenDiagnostic.stopSamples}회 · 클릭 신호 {status.screenDiagnostic.clickEvents}회</Text>
 <Text style={s.copy}>탐색 범위 제한 {status.screenDiagnostic.boundedSamples}회. 0회는 이번 진단에서 찾지 못했다는 뜻이며, 앱이 정보를 제공하지 않는다고 단정할 수는 없어요. 아래 ‘감지 상태 공유하기’에 이 결과가 포함돼요.</Text>
 </>}
 </View>
 <Text style={s.copy}>연결됨은 Android 서비스가 연결됐다는 뜻이에요. 전송 감지 성공 여부는 아래 신호·클릭 수와 자동 기록에서 확인하세요. 연결이 끊겼거나 업데이트 후 신호가 0이면 접근성 설정에서 이 서비스를 껐다 켜고 ChatGPT 앱으로 돌아가 다시 전송해 주세요.</Text>
 {button('감지 상태 공유하기',()=>void Share.share({message:JSON.stringify({version:'1.6.0',...status},null,2)}).catch(()=>setError('감지 상태를 공유하지 못했어요.')))}

 {status?.storageError&&<Text style={s.error}>기록 저장에 실패해 감지를 중지했어요. 저장 공간을 확인한 뒤 자동 기록을 껐다 켜 주세요.</Text>}
 <View style={s.metrics}><Text style={s.title}>오늘 감지한 프롬프트 {automaticRecords.length}건</Text><Text style={s.copy}>ChatGPT {automaticRecords.filter(r=>r.provider==='ChatGPT').length}회 · Gemini {automaticRecords.filter(r=>r.provider==='Gemini').length}회</Text></View>
 <View style={s.metrics}><Text style={s.title}>감지 상태 · 1.6.0</Text><Text style={s.copy}>{signalHint(status)}</Text><Text style={s.copy}>AI 앱 신호 {status?.receivedEvents??0}회 · 화면 변화 {status?.changeEvents??0}회 · 클릭 {status?.seenClicks??0}회</Text><Text style={s.copy}>최근 앱: {status?.lastProvider==='none'||!status?.lastProvider?'아직 없음':status.lastProvider}</Text><Text style={s.copy}>추정 감지 {automaticRecords.filter(r=>r.detection==='button-transition'||r.detection==='input-transition').length}회 포함 · 생성 중인 대화를 처음 열기만 한 경우에는 세지 않아요. 전송 버튼 상태 또는 동의한 입력 상태와 생성 시작을 함께 확인해 추정하며 재생성 등과 혼동할 수 있어요.</Text></View>
 <View style={s.metrics}><Text style={s.title}>어디까지 확인됐나요?</Text><Text style={s.copy}>내용 있음 확인 {status?.inputNonemptyChecks??0}회 → 입력창 비움 {status?.inputClearTransitions??0}회 → 생성 상태 확인 {status?.generatingScans??0}회</Text><Text style={s.copy}>이 숫자는 감지 과정의 확인 횟수예요. 프롬프트 수와 다르며, 입력만으로는 전송 기록을 만들지 않아요.</Text><Text style={s.copy}>화면 확인 실패 {status?.unavailableScans??0}회 · {status?.probeFailure==='root_missing'?'현재 화면 정보 일시 미제공':status?.probeFailure==='access_denied'?'화면 접근 거부':status?.probeFailure==='node_invalid'?'화면 요소 갱신 중':status?.probeFailure==='scan_exception'?'화면 검사 오류':'최근 검사 오류 없음'}</Text></View>
 <Text style={s.copy}>최근 버튼 탐색: {status?.scanScope==='cached_composer'?'찾아둔 전송 버튼 주변':status?.scanScope==='composer'?'입력창 주변':status?.scanScope==='window'?'전체 창':'아직 없음'} · {status?.scanNodes??0}개 요소 · {status?.scanMs??0}ms</Text>
 <View style={s.metrics}><Text style={s.title}>전력량 추정 기준</Text><View style={{flexDirection:'row',gap:12,alignItems:'center'}}><Switch accessibilityLabel="자동 기록을 일반 텍스트 요청으로 가정" value={assumeText} onValueChange={onAssumeText}/><Text style={[s.copy,{flex:1}]}>자동 기록을 모두 일반 텍스트 요청으로 가정</Text></View><Text style={s.copy}>기본으로 켜져 있으며, 이전에 끈 설정은 유지해요. 켜면 ChatGPT 평균 0.34 Wh·Gemini 중앙값 0.24 Wh 공개 참고값을 홈과 영수증에 적용해요. 끄면 횟수만 집계하고 에너지는 산정 제외해요. 이미지·음성 요청을 섞어 쓴다면 꺼 주세요. 버튼만으로 요청 종류나 전송 성공은 알 수 없고, 이 설정은 기존 자동 기록에도 적용돼요.</Text></View>
 <Text style={s.copy}>앱 버전에 따라 버튼 정보가 노출되지 않으면 감지가 누락될 수 있어요. 상태 변화 감지는 실기기 검증이 필요한 보완 방식이며 실제 전송 성공·답변 완료를 확인하는 기능은 아니에요. Google 앱·시스템 도우미 안의 Gemini는 제외합니다. Android에서 강제 종료·접근성 해제 시 기록이 멈추며, 누락된 전송을 소급해서 복원하지 않아요.</Text>
 <Text style={s.copy}>현재 연결의 클릭 신호: {status?.seenClicks??0}회 · {status?.lastMatch==='send'?'전송 확인':status?.lastMatch==='other'?'다른 버튼 또는 이름 미인식':status?.lastMatch==='unavailable'?'버튼 정보 없음':'입력 대기'}</Text>
 {button('연결 해제 및 자동 기록 삭제',()=>Alert.alert('연결을 해제하고 삭제할까요?','자동 기록을 삭제하고 접근성 연결을 해제합니다. 직접 입력한 기록은 유지됩니다.',[{text:'취소',style:'cancel'},{text:'해제 및 삭제',style:'destructive',onPress:()=>void action('disconnect')}]))}
 </>}{!!error&&<Text accessibilityRole="alert" style={s.error}>{error}</Text>}</View>
}
const createStyles=(c:ThemeColors)=>StyleSheet.create({card:{borderWidth:1,borderColor:c.line,padding:22,borderRadius:24,backgroundColor:c.input,gap:14},title:{fontSize:17,fontWeight:'700',color:c.ink},copy:{fontSize:13,lineHeight:22,color:c.muted},button:{backgroundColor:c.secondary,padding:16,borderRadius:12,alignItems:'center'},green:{color:c.green,fontWeight:'700'},error:{color:c.error,lineHeight:22},metrics:{padding:18,backgroundColor:c.paper,borderRadius:12,gap:12}});
