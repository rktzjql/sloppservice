export type ApiReceipt={provider:'OpenAI API';model:string;responseId:string;completedAt:number;usage:{inputTokens:number;outputTokens:number;totalTokens:number}|null};
export type ApiRequest={id:string;state:'created'|'processing'|'completed'|'failed'|'unknown';createdAt:number;updatedAt:number;receipt:ApiReceipt|null;answer:string|null};
export const API_LABELS:Record<ApiRequest['state'],string>={created:'접수 대기',processing:'서버 처리 중',completed:'응답 완료',failed:'API 요청 실패',unknown:'결과 확인 필요'};
export function serverUrl(value:string){const url=new URL(value.trim());if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||url.pathname!=='/')throw Error('https://로 시작하는 서버 주소를 입력해 주세요.');return url.origin;}
export function validRequest(value:unknown):value is ApiRequest {
 const v=value as ApiRequest;
 if(!v||typeof v.id!=='string'||!Object.hasOwn(API_LABELS,v.state)||!Number.isFinite(v.createdAt)||!Number.isFinite(v.updatedAt))return false;
 if(v.state==='completed'){
  const r=v.receipt;if(!r||r.provider!=='OpenAI API'||typeof r.responseId!=='string'||typeof r.model!=='string'||!Number.isFinite(r.completedAt))return false;
  if(r.usage&&![r.usage.inputTokens,r.usage.outputTokens,r.usage.totalTokens].every(n=>Number.isSafeInteger(n)&&n>=0))return false;
 }
 return v.answer===null||typeof v.answer==='string';
}
export function receiptOnly(request:ApiRequest):ApiRequest{return {...request,answer:null};}
export function mergeRequest(rows:ApiRequest[],request:ApiRequest){return [receiptOnly(request),...rows.filter(r=>r.id!==request.id)].slice(0,50);}
export function apiSummary(rows:ApiRequest[]){const completed=rows.filter(r=>r.state==='completed'&&r.receipt);return {completed:completed.length,tokens:completed.reduce((sum,r)=>sum+(r.receipt!.usage?.totalTokens??0),0),usageMissing:completed.filter(r=>!r.receipt!.usage).length};}
