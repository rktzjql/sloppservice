export type Task = 'simple'|'reasoning'|'verification';
export type Output = 'keep'|'list'|'steps';
export type Length = 'short'|'normal'|'long';
export type PromptDetails = {purpose:string;constraints:string;format:string};
export function buildPrompt(input:string,details:PromptDetails){
 const original=input.trim();
 if(!original||original.length>1000)throw new Error('질문을 1~1,000자로 입력해 주세요.');
 const fields=[{key:'purpose' as const,label:'목적',why:'무엇에 쓸 답인지 알려주면 필요한 내용에 집중하기 쉬워요.'},{key:'constraints' as const,label:'상황·제약',why:'예산·기간·대상을 알려주면 실행하기 어려운 제안을 줄이는 데 도움이 돼요.'},{key:'format' as const,label:'답변 형식·범위',why:'항목 수와 설명 범위를 정하면 원하는 모양으로 답을 받기 쉬워요.'}];
 const additions=fields.flatMap(field=>{
  const value=details[field.key].trim();
  if(value.length>200)throw new Error('추가 조건은 각각 200자 이내로 입력해 주세요.');
  return value?[{...field,value}]:[];
 });
 return {original,additions,suggestion:[original,...additions.map(a=>`${a.label}: ${a.value}`)].join('\n\n')};
}
export const REVIEW_OPTIONS=[
 {id:'budget',label:'1인당 예산과 여행 기간',correct:true,feedback:'실제로 갈 수 있는 코스의 범위를 정해 줘요.'},
 {id:'format',label:'하루별 일정과 이동 방법으로 정리',correct:true,feedback:'답변을 어떻게 활용할지 분명해져요.'},
 {id:'repeat',label:'“좋은 답을 줘”를 세 번 반복',correct:false,feedback:'반복만으로는 목적이나 필요한 조건이 구체화되지 않아요.'},
 {id:'long',label:'내용과 관계없이 무조건 길게 답하기',correct:false,feedback:'길이 자체보다 여행 계획에 필요한 정보가 중요해요.'},
] as const;
export function reviewPassed(selected:readonly string[]){return selected.length===2&&new Set(selected).size===2&&selected.every(id=>REVIEW_OPTIONS.some(o=>o.id===id&&o.correct));}
export function makeExample(input:string,output:Output,length:Length){
 const original=input.trim();if(!original||original.length>1000)throw new Error('질문을 1~1,000자로 입력해 주세요.');
 const additions:string[]=[];
 if(output==='list')additions.push('답변을 항목별 목록으로 정리해 주세요.');
 if(output==='steps')additions.push('답변을 순서가 있는 단계로 정리해 주세요.');
 if(length==='short')additions.push('각 항목의 핵심을 한 문장으로 간결하게 설명해 주세요.');
 if(length==='long')additions.push('필요한 근거와 예시를 함께 설명해 주세요.');
 return {original,suggestion:[original,...additions].join('\n\n'),reasons:[
  '원문의 내용을 그대로 유지했어요. 질문의 의미나 사실관계를 자동으로 판단하지는 않아요.',
  ...(output==='keep'?[]:['선택한 출력 형식을 추가했어요. 원래 질문의 형식 조건과 충돌하면 수정하거나 빼 주세요.']),
  ...(length==='normal'?[]:['선택한 설명 길이를 제안 조건으로 추가했어요. 질문이 길어져도 더 명확해질 수 있어요.']),
 ]};
}
export function modelLesson(task:Task){
 if(task==='simple')return {tier:'경량 모델부터 검토',reason:'직접 선택한 작업이 간단한 문장 정리·아이디어 목록이기 때문이에요.',caution:'답변이 조건을 놓치거나 정확성이 중요해지면 더 강한 모델과 별도 검증을 검토하세요.'};
 if(task==='reasoning')return {tier:'고성능 모델을 검토',reason:'직접 선택한 작업에 여러 조건의 비교·추론이 포함되기 때문이에요.',caution:'모델 등급만으로 정답이나 품질을 보장할 수 없어요.'};
 return {tier:'출처 확인을 우선',reason:'사실 확인이 필요한 작업은 모델 크기보다 검증 가능한 근거가 중요해요.',caution:'공식 자료·최신 출처를 직접 확인하세요. 이 화면은 모델을 호출하거나 답을 검증하지 않아요.'};
}
