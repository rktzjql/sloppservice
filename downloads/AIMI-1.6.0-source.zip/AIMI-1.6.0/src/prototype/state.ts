export type Reward = 'attendance'|'tip'|'learning';
export type ItemId = 'blue-pot'|'fence';
export const ITEMS = [{id:'blue-pot' as const,name:'파란 화분',price:40,icon:'🪴'},{id:'fence' as const,name:'나무 울타리',price:60,icon:'🪵'}];
export type Ledger = {id:string;day:string;label:string;delta:number};
export type Progress = {version:1;ep:number;claims:string[];practice:Record<string,number>;owned:ItemId[];equipped:ItemId|null;ledger:Ledger[]};
export const freshProgress=():Progress=>({version:1,ep:0,claims:[],practice:{},owned:[],equipped:null,ledger:[]});
export const REWARDS:Record<Reward,{amount:number;label:string}>={attendance:{amount:5,label:'출석'},tip:{amount:3,label:'오늘의 팁'},learning:{amount:5,label:'첫 질문 개선 연습'}};
export function claim(s:Progress,day:string,kind:Reward):Progress {
 const id=`${day}:${kind}`;if(s.claims.includes(id))return s;
 const r=REWARDS[kind];return {...s,ep:s.ep+r.amount,claims:[...s.claims,id],ledger:[{id,day,label:r.label,delta:r.amount},...s.ledger]};
}
export function practice(s:Progress,day:string):Progress {
 const used=s.practice[day]??0;if(used>=5)throw new Error('오늘 연습 5회를 모두 사용했어요.');
 return claim({...s,practice:{...s.practice,[day]:used+1}},day,'learning');
}
export function purchase(s:Progress,day:string,id:ItemId):Progress {
 const item=ITEMS.find(i=>i.id===id);if(!item)throw new Error('아이템을 찾지 못했어요.');
 if(s.owned.includes(id))return s;
 if(s.ep<item.price)throw new Error('EP가 부족해요. 출석과 질문 연습으로 모아 보세요.');
 return {...s,ep:s.ep-item.price,owned:[...s.owned,id],ledger:[{id:`buy:${id}`,day,label:item.name,delta:-item.price},...s.ledger]};
}
export function parseProgress(raw:string|null):Progress {
 if(raw===null)return freshProgress();
 const s=JSON.parse(raw);const ids=ITEMS.map(i=>i.id);
 if(!s||s.version!==1||!Number.isSafeInteger(s.ep)||s.ep<0||!Array.isArray(s.claims)||!s.claims.every((x:unknown)=>typeof x==='string')||!s.practice||Array.isArray(s.practice)||typeof s.practice!=='object'||!Object.values(s.practice).every(v=>Number.isInteger(v)&&Number(v)>=0&&Number(v)<=5)||!Array.isArray(s.owned)||!s.owned.every((v:ItemId)=>ids.includes(v))||(s.equipped!==null&&!s.owned.includes(s.equipped))||!Array.isArray(s.ledger)||!s.ledger.every((r:Ledger)=>r&&typeof r.id==='string'&&typeof r.day==='string'&&typeof r.label==='string'&&Number.isSafeInteger(r.delta)))throw new Error('저장한 학습 기록을 읽지 못했어요.');
 return s;
}
