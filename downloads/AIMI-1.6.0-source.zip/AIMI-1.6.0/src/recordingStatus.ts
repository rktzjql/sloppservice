import type {ExperimentStatus} from '../modules/ai-usage';
export function recordingStatus(s: ExperimentStatus|null): string {
 if(!s)return '연결 상태 확인 중';
 if(!s.consent)return '연결 전';
 if(!s.connected)return s.accessibilityEnabled?'접근성 켜짐 · 서비스 연결 끊김':'접근성 연결 필요';
 if(s.storageError)return '저장 오류 · 감지 중지';
 if(!s.enabled)return '자동 기록 꺼짐';
 if(!s.active)return '서비스 연결 확인 필요';
 return s.sendCount>0?'이번 연결에서 전송 감지됨 · 대기 중':'연결됨 · 전송 감지 대기';
}
export function signalHint(s: ExperimentStatus|null): string {
 if(s?.enabled&&!s.connected)return '현재 서비스가 연결되지 않아 기록할 수 없어요. 접근성 설정에서 AI 자동 기록을 껐다 켜 주세요.';
 if(!s?.active)return '자동 기록 연결 상태를 먼저 확인해 주세요.';
 if(!s.receivedEvents)return '아직 AI 앱 신호를 받지 못했어요. ChatGPT 앱에서 질문을 한 번 보내고 돌아와 주세요.';
 const labels: Record<ExperimentStatus['buttonState'],string> = {
  waiting:'AI 앱 신호 수신 · 버튼 확인 대기',
  ready:'전송 가능한 버튼 확인 · 생성 중지 버튼으로 바뀌는지 대기',
  generating:'생성 중지 버튼 확인 · 앞선 전송 상태와 연결될 때만 추정 기록',
  no_controls:'화면 신호는 받았지만 전송·생성 중지 버튼을 식별하지 못했어요.',
  unavailable:'화면 신호는 받았지만 버튼 정보에 접근하지 못했어요.',
  background:'현재 AI 앱 화면이 아니어서 버튼 확인을 중지했어요.',
  bounded:'확인 가능한 화면 구조 범위를 넘어 추정 감지를 건너뛰었어요.',
 };
 return labels[s.buttonState]??'AI 앱 신호 수신 · 버튼 상태 확인 중';
}
